% simulate Differential Pulse Code Modulation
clear, clf

T=0.01; nmax=200; t=[0:nmax-1]*T;  
%b0=min(x); bN=max(x); xmax=max(abs([b0 bN]))
b0=-0.4; bN=0.4; N=8; %left/rightmost boundary  & # of bits/sample
delta=(bN-b0)/N;  %the width of the quantization interval
b=b0+[0:N]*delta; %the boundary vector
c=b(1:N)+delta/2; %quantization level vector
M=2;  M1=M+1; % dimension of predictor
% initialize the parameters of the predictor
P=eye(M1,M1); a=zeros(M1,1); alpha=1;  
%initialize the (memory) buffers of predictor
xqs=[1; zeros(M,1)];  xqhn=0; en=0; eqn=0;
%initialize the (memory) buffers of predictor
yqs=[1; zeros(M,1)]; 

for n=1:nmax
   x(n)= sin(6*(n-1)*T);
   xqs= [1; xqs(3:M1); xqhn+eqn]; %the predictor output history
   if n<40 %training period for adaptive predictor
     [xqh(n),P,a]=prdctr(en,xqs,M,P,a,alpha); %adaptive predictor
    else    
      xqh(n)= a'*xqs;  %non-adaptive predictor
   end
   e(n)=x(n)-xqh(n); %prediction error
   eq(n)=adc(e(n),b,c); %quantizer at encoder
   en=e(n); eqn=eq(n); xqhn=xqh(n); %store/delay
   yq(n)=a'*yqs +eqn; %the output of predictor at decoder
   yqs=[1; yqs(3:M1); yq(n)];  %store/delay
end

subplot(311), plot(t,x,'k-'), hold on
stairs(t,yq,'m-'), title('Original and reconstructed signals')
axis([0 2 -1.15 1.15]), set(gca,'fontsize',9)

subplot(312), stairs(t,e,'b-'), hold on
stairs(t,eq,'r-'), title('Predicted and quantized errors')
axis([0 2 -0.5 0.5]), set(gca,'fontsize',9)

subplot(313), plot(t,x-yq,'r-'), title('Reconstructed difference')
axis([0 2 -0.13 0.13]), set(gca,'fontsize',9)
