% Simulation to verify SQNR for sinusoidal
% probability density function.
b = 8; % 8-bit quantized signals
q = 1/10000; % make sampled signal with interval size 1/10001
seq = [0 : q : 1];
x = sin(2*pi*seq); % analog signal --> 10001 samples
% Now quantize:
x8bit = round(2^(b-1)*x) / 2^(b-1); % in [-128,128]/128=[-1,+1]
quanterror = x - x8bit;
%
SQNR = 20*log10( sqrt(mean(x.^2))/sqrt(mean(quanterror.^2)) ) %
% 50.0189dB
SQNRtheory = 6.02*b + 1.76 % 1.76=20*log10(sqrt(3/2))
% 49.9200dB