﻿/*
 * - 已实现功能: 
 * - (1) 绘制棋盘
 * - (2) 绘制 L 、O 、I 、Z 、S 、J 、T 型方块
 * - (3) 随机生成方块的种类和颜色
 * - (4) 键盘左 / 右 / 下键控制方块的移动, 上键旋转方块
 * - (5) 方块自动下落
 * - (6) 键盘空格键加速方块下落
 * - (7) 方块间、方块与边界间的碰撞检测
 * - (8) 棋盘填满一行时清除, 终端展示当前分数和游戏难度
 * - (9) 超过一定得分后游戏难度增加, 方块下落速度加快
 * - (10) 初始时终端展示欢迎信息和操作教程
 * - (11) 按 P 键可暂停 / 继续游戏
 * - (12) 窗口被拉伸时自动重绘画面
 */

#include "Angel.h"

#include <cstdlib>
#include <iostream>
#include <string>
#include <time.h>
#include <Windows.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

int xSize = 400, ySize = 720;  // 窗口大小

clock_t startTime;  // 方块上次下落的时间戳
int rotation = 0;  // 当前方块的旋转
glm::vec2 tile[4];  // 当前的方块

int score = 0;  // 游戏积分
int difficulty = 1;  // 游戏难度
int fallingSpeed = 1000; // 下落速度, 每 1000 ms 下落一格

bool gameOver = false;  // 游戏结束标记
bool gaming = true;  // 时间流动标记, 用于暂停
bool accelerating = false;  // 方块加速下落标记

const int colorCnt = 9;  // 颜色种数
const int tileTypeCnt = 7;  // 方块种数
int tileType;  // 当前方块的类型
int tileColor;  // 当前方块的颜色

int tileSize = 33;  // 单个网格大小
const int boardWidth = 10, boardHeight = 20;  // 网格大小
const int pointsCnt = boardHeight * boardWidth * 6;  // 网格的三角面片的顶点数
// 画直线绘制网格, 包含 (boardWidth + 1) 条竖线, (boardHeight + 1) 条横线, 一条线包含 2 个顶点
const int boardLineCnt = (boardWidth + 1) + (boardHeight + 1);  // 网格线数

glm::vec2 allRotationsLshape[7][4][4] = {  // 方块和不同的方向
    {   // 1. L
        { glm::vec2(0, 0), glm::vec2(-1, 0), glm::vec2(1, 0), glm::vec2(-1, -1) }, 
        { glm::vec2(0, 1), glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(1, -1) }, 
        { glm::vec2(1, 1), glm::vec2(-1, 0), glm::vec2(0, 0), glm::vec2(1, 0) }, 
        { glm::vec2(-1, 1), glm::vec2(0, 1), glm::vec2(0, 0), glm::vec2(0, -1) } 
    },
    {   // 2. O
        { glm::vec2(0, 0), glm::vec2(-1, 0), glm::vec2(0, -1), glm::vec2(-1, -1) },
        { glm::vec2(0, 0), glm::vec2(-1, 0), glm::vec2(0, -1), glm::vec2(-1, -1) },
        { glm::vec2(0, 0), glm::vec2(-1, 0), glm::vec2(0, -1), glm::vec2(-1, -1) },
        { glm::vec2(0, 0), glm::vec2(-1, 0), glm::vec2(0, -1), glm::vec2(-1, -1) }
    },
    {   // 3. I
        { glm::vec2(1, 0), glm::vec2(0, 0), glm::vec2(-1, 0), glm::vec2(-2, 0) },
        { glm::vec2(0, 1), glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(0, -2) },
        { glm::vec2(1, 0), glm::vec2(0, 0), glm::vec2(-1, 0), glm::vec2(-2, 0) },
        { glm::vec2(0, 1), glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(0, -2) }
    },
    {   // 4. Z
        { glm::vec2(-1, 0), glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(1, -1) },
        { glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(1, 0), glm::vec2(1, 1) },
        { glm::vec2(-1, 0), glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(1, -1) },
        { glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(1, 0), glm::vec2(1, 1) }
    },
    {   // 5. S
        { glm::vec2(0, -1), glm::vec2(0, 0), glm::vec2(1, 0), glm::vec2(-1, -1) },
        { glm::vec2(0, 0), glm::vec2(0, 1), glm::vec2(1, 0), glm::vec2(1, -1) },
        { glm::vec2(0, -1), glm::vec2(0, 0), glm::vec2(1, 0), glm::vec2(-1, -1) },
        { glm::vec2(0, 0), glm::vec2(0, 1), glm::vec2(1, 0), glm::vec2(1, -1) }
    },
    {   // 6. J
        { glm::vec2(-1, 0), glm::vec2(0, 0), glm::vec2(1, 0), glm::vec2(-1, -1) },
        { glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(0, 1), glm::vec2(1, -1) },
        { glm::vec2(-1, 0), glm::vec2(0, 0), glm::vec2(1, 0), glm::vec2(1, 1) },
        { glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(0, 1), glm::vec2(-1, 1) }
    },
    {   // 7. T
        { glm::vec2(-1, 0), glm::vec2(0, 0), glm::vec2(1, 0), glm::vec2(0, -1) },
        { glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(0, 1), glm::vec2(1, 0) },
        { glm::vec2(-1, 0), glm::vec2(0, 0), glm::vec2(1, 0), glm::vec2(0, 1) },
        { glm::vec2(0, 0), glm::vec2(0, -1), glm::vec2(0, 1), glm::vec2(-1, 0) }
    }
};

// 颜色
glm::vec4 orange = glm::vec4(1.0, 0.5, 0.0, 1.0);
glm::vec4 white = glm::vec4(1.0, 1.0, 1.0, 1.0);
glm::vec4 black = glm::vec4(0.0, 0.0, 0.0, 1.0);
glm::vec4 red = glm::vec4(1.0, 0.0, 0.0, 1.0);
glm::vec4 blue = glm::vec4(0.0, 0.0, 1.0, 1.0);
glm::vec4 green = glm::vec4(0.0, 1.0, 0.0, 1.0);
glm::vec4 yellow = glm::vec4(1.0, 1.0, 0.0, 1.0);
glm::vec4 purple = glm::vec4(0.63, 0.13, 0.86, 1.0);
glm::vec4 skyblue = glm::vec4(0.0, 0.74, 1.0, 1.0);
glm::vec4 pink = glm::vec4(1.0, 0.75, 0.8, 1.0);
const glm::vec4 tileColors[colorCnt] = { orange, white, pink, red, blue, green, yellow, purple, skyblue };

glm::vec2 tileCoordinate = glm::vec2(5, 19);  // 当前方块的坐标(以棋盘格的左下角为原点)

bool boardOccupied[boardWidth][boardHeight];  // boardOccupied[x][y] 表示坐标 (x, y) 是否被占据
glm::vec4 boardColor[pointsCnt];  // boardColor[x][y] 表示坐标 (x, y) 的颜色

GLuint locxsize, locysize;
GLuint vao[3], vbo[6];

// 当前方块下落或旋转时, 更新 vbo
void updateTile() {
    glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);

    for (int i = 0; i < 4; i++) {        
        GLfloat x = tileCoordinate.x + tile[i].x, y = tileCoordinate.y + tile[i].y;  // 格子的坐标

        glm::vec4 p1 = glm::vec4(tileSize + (x * tileSize), tileSize + (y * tileSize), 0.4, 1);
        glm::vec4 p2 = glm::vec4(tileSize + (x * tileSize), tileSize * 2 + (y * tileSize), 0.4, 1);
        glm::vec4 p3 = glm::vec4(tileSize * 2 + (x * tileSize), tileSize + (y * tileSize), 0.4, 1);
        glm::vec4 p4 = glm::vec4(tileSize * 2 + (x * tileSize), tileSize * 2 + (y * tileSize), 0.4, 1);

        // 每个格子包含 2 个三角形, 即 6 个顶点
        glm::vec4 newpoints[6] = {p1, p2, p3, p2, p3, p4};
        glBufferSubData(GL_ARRAY_BUFFER, i * 6 * sizeof(glm::vec4), 6 * sizeof(glm::vec4), newpoints);
    }
    glBindVertexArray(0);
}

// 生成一个新方块, 并判断游戏是否结束
void newTile() {
    // 判断生成方块的下面 2 行是否已被占据, 若是, 则游戏结束
    for (int i = 1; i <= 2; i++) {
        for (int j = -1; j < 3; j++) {
            if (boardOccupied[(boardWidth / 2) + j][boardHeight - i]) {
                std::cout << "Game over!" << std::endl;
                std::cout << "Press P to restart or press Q to quit." << std::endl;
                std::cout << std::endl;

                gaming = false;
                gameOver = true;
                return;
            }
        }
    }

    // 随机生成一个新方块
    tileCoordinate = glm::vec2(5, 19);  // 方块的初始坐标
    rotation = 0;  // 新方块的初始方向
    tileType = rand() % tileTypeCnt;  // 方块的种类
    for (int i = 0; i < 4; i++) tile[i] = allRotationsLshape[tileType][0][i];  // 方块的组成
    updateTile();  // 更新 vbo

    // 随机生成新方块的颜色
    glm::vec4 newColors[24];
    tileColor = rand() % colorCnt;
    for (int i = 0; i < 24; i++) newColors[i] = tileColors[tileColor];

    glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(newColors), newColors);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindVertexArray(0);
}

// 输出提示信息
void printHints() {
    std::cout << "Welcome to Тетрис, prepared by 2021192010 Xi Wang." << std::endl;
    std::cout << "--------------------" << std::endl;
    std::cout << "Operations:" << std::endl;
    std::cout << "    ↑ : Rotate" << std::endl;
    std::cout << "    ↓ : Move down" << std::endl;
    std::cout << "    ← : Move left" << std::endl;
    std::cout << "    → : Move right" << std::endl;
    std::cout << "    Space : Accelerate" << std::endl;
    std::cout << "    P : Pause / Continue" << std::endl;
    std::cout << "    R : Restart" << std::endl;
    std::cout << "    Q / ESC : Quit" << std::endl;
    std::cout << "--------------------" << std::endl;
    std::cout << "Press R to start!" << std::endl;
    std::cout << std::endl;
}

// 初始化游戏画面
void init() {
    printHints();  // 输出提示信息

    gaming = false;

    // 初始化 boardOccupied[][] 数组
    for (int i = 0; i < boardWidth; i++)
        for (int j = 0; j < boardHeight; j++) boardOccupied[i][j] = false;

    srand(time(NULL));

    glm::vec4 gridPoints[boardLineCnt * 2];  // 棋盘顶点
    glm::vec4 gridColors[boardLineCnt * 2];  // 棋盘顶点的颜色

    // 绘制网格线
    for (int i = 0; i < boardWidth + 1; i++) {  // 绘制纵向网格线
        gridPoints[2 * i] = glm::vec4((tileSize + (tileSize * i)), tileSize, 0, 1);
        gridPoints[2 * i + 1] = glm::vec4((tileSize + (tileSize * i)), (boardHeight + 1) * tileSize, 0, 1);
    }
    for (int i = 0; i < boardHeight + 1; i++) {  // 绘制横向网格线
        gridPoints[2 * (boardWidth + 1) + 2 * i] = glm::vec4(tileSize, (tileSize + (tileSize * i)), 0, 1);
        gridPoints[2 * (boardWidth + 1) + 2 * i + 1] = glm::vec4((boardWidth + 1) * tileSize, (tileSize + (tileSize * i)), 0, 1);
    }

    // 将网格线的颜色设为白色
    for (int i = 0; i < boardLineCnt * 2; i++) gridColors[i] = white;

    // 初始化棋盘, 将未占据的网格设为黑色
    glm::vec4 boardpoints[pointsCnt];
    for (int i = 0; i < pointsCnt; i++) boardColor[i] = black;

    // 对每个格子, 初始化 6 个顶点, 表示两个三角形
    for (int i = 0; i < boardHeight; i++) {
        for (int j = 0; j < boardWidth; j++) {
            glm::vec4 p1 = glm::vec4(tileSize + (j * tileSize), tileSize + (i * tileSize), 0.5, 1);
            glm::vec4 p2 = glm::vec4(tileSize + (j * tileSize), tileSize * 2 + (i * tileSize), 0.5, 1);
            glm::vec4 p3 = glm::vec4(tileSize * 2 + (j * tileSize), tileSize + (i * tileSize), 0.5, 1);
            glm::vec4 p4 = glm::vec4(tileSize * 2 + (j * tileSize), tileSize * 2 + (i * tileSize), 0.5, 1);

            // 注意节点顺序
            boardpoints[6 * (boardWidth * i + j) + 0] = p1;
            boardpoints[6 * (boardWidth * i + j) + 1] = p2;
            boardpoints[6 * (boardWidth * i + j) + 2] = p3;
            boardpoints[6 * (boardWidth * i + j) + 3] = p2;
            boardpoints[6 * (boardWidth * i + j) + 4] = p3;
            boardpoints[6 * (boardWidth * i + j) + 5] = p4;
        }
    }

    // 载入着色器
    std::string vshader, fshader;
    vshader = "shaders/vshader.glsl";
    fshader = "shaders/fshader.glsl";
    GLuint program = InitShader(vshader.c_str(), fshader.c_str());
    glUseProgram(program);

    locxsize = glGetUniformLocation(program, "xsize");
    locysize = glGetUniformLocation(program, "ysize");

    GLuint vPosition = glGetAttribLocation(program, "vPosition");
    GLuint vColor = glGetAttribLocation(program, "vColor");

    glGenVertexArrays(3, &vao[0]);
    glBindVertexArray(vao[0]); // 棋盘的顶点
    glGenBuffers(2, vbo);

    // 棋盘的顶点位置
    glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
    glBufferData(GL_ARRAY_BUFFER, (boardLineCnt * 2) * sizeof(glm::vec4), gridPoints, GL_STATIC_DRAW);
    glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(vPosition);

    // 棋盘的顶点颜色
    glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
    glBufferData(GL_ARRAY_BUFFER, (boardLineCnt * 2) * sizeof(glm::vec4), gridColors, GL_STATIC_DRAW);
    glVertexAttribPointer(vColor, 4, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(vColor);

    glBindVertexArray(vao[1]); // 棋盘格的格子
    glGenBuffers(2, &vbo[2]);

    // 棋盘的格子的顶点位置
    glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
    glBufferData(GL_ARRAY_BUFFER, pointsCnt * sizeof(glm::vec4), boardpoints, GL_STATIC_DRAW);
    glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(vPosition);

    // 棋盘的格子的顶点颜色
    glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
    glBufferData(GL_ARRAY_BUFFER, pointsCnt * sizeof(glm::vec4), boardColor, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(vColor, 4, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(vColor);

    glBindVertexArray(vao[2]);  // 当前方块
    glGenBuffers(2, &vbo[4]);

    // 当前方块顶点的位置
    glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
    glBufferData(GL_ARRAY_BUFFER, 24 * sizeof(glm::vec4), NULL, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(vPosition);

    // 当前方块顶点的颜色
    glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
    glBufferData(GL_ARRAY_BUFFER, 24 * sizeof(glm::vec4), NULL, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(vColor, 4, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(vColor);

    glBindVertexArray(0);

    glClearColor(0, 0, 0, 0);

    // 初始化游戏
    newTile();  // 生成一个方块作展示
    startTime = clock();
}

// 检查坐标是否越界或已被占据
bool checkvalid(glm::vec2 coordinate) {
    if (coordinate.x < 0 || coordinate.x >= boardWidth || coordinate.y < 0 || coordinate.y >= boardHeight) return false;
	if (boardOccupied[(int)coordinate.x][(int)coordinate.y]) return false;
	return true;
}

// 在棋盘上有足够空间的情况下旋转当前方块
void rotate() {
    int nextrotation = (rotation + 1) % 4;  // 旋转方向

    // 检查旋转是否合法, 若合法, 则更新方块方向和 vbo
    if (checkvalid((allRotationsLshape[tileType][nextrotation][0]) + tileCoordinate) 
	    && checkvalid((allRotationsLshape[tileType][nextrotation][1]) + tileCoordinate) 
	    && checkvalid((allRotationsLshape[tileType][nextrotation][2]) + tileCoordinate) 
	    && checkvalid((allRotationsLshape[tileType][nextrotation][3]) + tileCoordinate)) {
        
        // 更新方块
        rotation = nextrotation;
        for (int i = 0; i < 4; i++) tile[i] = allRotationsLshape[tileType][rotation][i];
        updateTile();  // 更新 vbo
    }
}

// 修改棋盘坐标 coordinate 的格子的颜色为 color , 并更新 vbo
void changeCellColor(glm::vec2 coordinate, glm::vec4 color) {
    // 设置格子的 6 个顶点的颜色
    for (int i = 0; i < 6; i++) boardColor[(int)(6 * (boardWidth * coordinate.y + coordinate.x) + i)] = color;

    glm::vec4 newColors[6] = {color, color, color, color, color, color};
    glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);

    // 计算偏移量并填色
    int offset = 6 * sizeof(glm::vec4) * (int)(boardWidth * coordinate.y + coordinate.x);
    glBufferSubData(GL_ARRAY_BUFFER, offset, sizeof(newColors), newColors);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

// 打印当前的得分和难度
void printStatus() {
    std::cout << "----------------------" << std::endl;
    std::cout << "Score: " << score << std::endl;
    std::cout << "Difficulty: " << difficulty << std::endl;
    std::cout << "----------------------" << std::endl;
    std::cout << std::endl;
}

// 检查第 row 行是否已满
void checkFullRow(int row) {
	for (int i = 0; i < boardWidth; i++) 
		if (!boardOccupied[i][row]) return;

    // 得分并更新难度
    score += 10;
	if (score >= difficulty * 60) {
		difficulty++;
		fallingSpeed /= 2;
	}

    // 消去的行上面的行下移
	for (int k = row + 1; k < boardHeight; k++) {
		for (int j = 0; j < boardWidth; j++) {
            boardOccupied[j][k - 1] = boardOccupied[j][k];
            changeCellColor(glm::vec2(j, k - 1), boardColor[6 * (j + k * boardWidth)]);
        }
	}

    // 更新棋盘
    for (int j = 0; j < boardWidth; j++) {
        changeCellColor(glm::vec2(j, boardWidth), black);
        boardOccupied[j][boardWidth] = false;
    }

    printStatus();  // 打印当前的得分和难度
}

// 放置方块并更新棋盘
void setTile() {
    for (int i = 0; i < 4; i++) {
        int x = (tile[i] + tileCoordinate).x, y = (tile[i] + tileCoordinate).y;  // 格子在棋盘上的坐标
        boardOccupied[x][y] = true;  // 标记对应格子被占据
        changeCellColor(glm::vec2(x, y), tileColors[tileColor]);  // 修改对应格子的颜色
    }

    for (int i = 0; i < 4; i++) {
		int y = (tile[i] + tileCoordinate).y;  // 判断方块的 4 个格子所在的行是否已满
		checkFullRow(y);
	}

    accelerating = false;  // 注意恢复 accelerating
}

const glm::vec2 LEFT(-1, 0), RIGHT(1, 0), DOWN(0, -1);  // 移动方向

// 移动方块
bool moveTile(glm::vec2 direction) {
    glm::vec2 newTileCoorditate[4];  // 移动后方块的坐标
    for (int i = 0; i < 4; i++) newTileCoorditate[i] = tile[i] + tileCoordinate + direction;

    // 检查移动后是否合法, 若合法, 则移动方块
    if (checkvalid(newTileCoorditate[0]) && checkvalid(newTileCoorditate[1]) 
        && checkvalid(newTileCoorditate[2]) && checkvalid(newTileCoorditate[3])) {
        
        tileCoordinate.x = tileCoordinate.x + direction.x, tileCoordinate.y = tileCoordinate.y + direction.y;
        updateTile();
        return true;
    }
    return false;
}

// 重新开始游戏
void restart() {
    system("cls");  // 控制台清屏

    // 恢复棋盘状态
    for (int i = 0; i < boardWidth; i++) {
        for (int j = 0; j < boardHeight; j++) {
            boardOccupied[i][j] = false;
            boardColor[j + boardWidth + i] = black;
            changeCellColor(glm::vec2(i, j), black);
        }
    }

    // 恢复参数状态
    startTime = clock();
    score = 0;
    difficulty = 1;
    fallingSpeed = 1000;
    gaming = true;
    gameOver = false;
 
    newTile();  // 生成一个方块用于展示
}

// 键盘事件的回调函数
void keyCallback(GLFWwindow *window, int key, int scancode, int action, int mode) {
    // 开始游戏、退出游戏
    switch (key) {
        // ESC / Q : Quit
        case GLFW_KEY_ESCAPE:
        case GLFW_KEY_Q:
            if (action == GLFW_PRESS) exit(EXIT_SUCCESS);
            break;

        // R : Restart
        case GLFW_KEY_R:
            if (action == GLFW_PRESS) restart();
            break;
    }

    // 游戏暂停、继续
    if (!gameOver) {
        if (key == GLFW_KEY_P && action == GLFW_PRESS) {
            if (gaming) std::cout << "Game Paused." << std::endl;
            else std::cout << "Game Continued." << std::endl;
            gaming = !gaming;
        }
    }

    // 游戏运行时的操作
    if (!gameOver && gaming) {  
        switch (key) {
            // ↑ : Rotate
            case GLFW_KEY_UP:
                if (action == GLFW_PRESS || action == GLFW_REPEAT) rotate();
                break;

            // ↓ : Move down
            case GLFW_KEY_DOWN:
                if (action == GLFW_PRESS || action == GLFW_REPEAT) {
                    if (!moveTile(DOWN)) {
                        setTile();
                        newTile();
                    }
                }
                break;

            // ← : Move left
            case GLFW_KEY_LEFT:
                if (action == GLFW_PRESS || action == GLFW_REPEAT) moveTile(LEFT);
                break;
            
            // → : Move right
            case GLFW_KEY_RIGHT:
                if (action == GLFW_PRESS || action == GLFW_REPEAT) moveTile(RIGHT);
                break;
            
            // Space : Accelerate
            case GLFW_KEY_SPACE:
                if (action == GLFW_PRESS || action == GLFW_REPEAT) accelerating = true;
                break;
        }
    }
}

// 时间流动的空闲函数
void idle() {
    clock_t currentTime = clock();  // 当前时间戳
    if (currentTime - startTime > (accelerating ? 60 : fallingSpeed)) {  // 到达时间间隔
        // 下落
        startTime = currentTime;  //更新时间戳
        if (!gameOver&& gaming) {
            if (!moveTile(DOWN)) {  // 下落失败
                setTile();  // 放置方块
                newTile();  // 生成新方块
            }
        }
    }
}

// 窗口改变大小时 GLFW 调用的函数
void framebufferSizeCallback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// 窗口被拉伸时, 改变网格大小
void reshape(GLsizei w, GLsizei h) {
    xSize = w, ySize = h;
    glViewport(0, 0, w, h);
}

// 渲染部分
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glUniform1i(locxsize, xSize);
    glUniform1i(locysize, ySize);

    glBindVertexArray(vao[1]);
    glDrawArrays(GL_TRIANGLES, 0, pointsCnt); // 绘制棋盘格种的 (width * height * 2) 个三角形
    glBindVertexArray(vao[2]);
    glDrawArrays(GL_TRIANGLES, 0, 24); // 绘制当前方块的 8 个三角形
    glBindVertexArray(vao[0]);
    glDrawArrays(GL_LINES, 0, boardLineCnt * 2); // 绘制棋盘
}

int main(int argc, char **argv) {
    glfwInit();  // 初始化 GLFW 库

    // 配置 GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // 配置窗口属性
    GLFWwindow *window = glfwCreateWindow(500, 900, "2021192010_王曦_期中大作业", NULL, NULL);
    if (window == NULL) {
        std::cout << "Failed to create GLFW window!" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);
    glfwSetKeyCallback(window, keyCallback);
    
    // 调用 OpenGL 的函数之前初始化 GLAD
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    init();
    while (!glfwWindowShouldClose(window)) {
        display();

        // 交换颜色缓冲、检查触发事件
        glfwSwapBuffers(window);
        glfwPollEvents();
        idle();
    }
    glfwTerminate();
    return 0;
}
