﻿#include "Angel.h"
#include "TriMesh.h"

#include <string>
#include <vector>

#pragma execution_character_set("utf-8")

const int X_AXIS = 0, Y_AXIS = 1, Z_AXIS = 2;  // 坐标轴编号
int currentAxis;  // 当前的旋转轴

const int TRANSFORM_SCALE = 0;
const int TRANSFORM_ROTATE = 1;
const int TRANSFORM_TRANSLATE = 2;

const double DEFAULT_DELTA = 0.01;  // 默认的 Delta 值
const double DELTA_DELTA = 0.01;  // Delta 的变化率

double scaleDelta = DEFAULT_DELTA;
double rotateDelta = DEFAULT_DELTA;
double translateDelta = DEFAULT_DELTA;

glm::vec3 scaleTheta(1.0, 1.0, 1.0);  // 缩放控制变量
glm::vec3 rotateTheta(0.0, 0.0, 0.0);  // 旋转控制变量
glm::vec3 translateTheta(0.0, 0.0, 0.0);  // 平移控制变量

int currentTransform = TRANSFORM_ROTATE; // 当前变换

bool pause;  // 旋转暂停标志

int mainWindow;

struct openGLObject {
    GLuint vao;  // 顶点数组对象
    GLuint vbo;  // 顶点缓存对象
    
    GLuint program;  // 着色器程序
    
    // 着色器文件
    std::string vshader, fshader;

    // 着色器变量
    GLuint pLocation;
    GLuint cLocation;
    GLuint matrixLocation;
    GLuint darkLocation;
};

openGLObject cube_object;

TriMesh *cube = new TriMesh();

void bindObjectAndData(TriMesh *mesh, openGLObject &object, const std::string &vshader, const std::string &fshader) {
    // 创建顶点数组对象
    glGenVertexArrays(1, &object.vao); // 分配 1 个顶点数组对象
    glBindVertexArray(object.vao);     // 绑定顶点数组对象

    // 创建并初始化顶点缓存对象
    glGenBuffers(1, &object.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, object.vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 mesh->getPoints().size() * sizeof(glm::vec3) + mesh->getColors().size() * sizeof(glm::vec3),
                 NULL,
                 GL_STATIC_DRAW);

    glBufferSubData(GL_ARRAY_BUFFER, 0, mesh->getPoints().size() * sizeof(glm::vec3), &mesh->getPoints()[0]);
    glBufferSubData(GL_ARRAY_BUFFER, mesh->getPoints().size() * sizeof(glm::vec3), mesh->getColors().size() * sizeof(glm::vec3), &mesh->getColors()[0]);

    object.vshader = vshader;
    object.fshader = fshader;
    object.program = InitShader(object.vshader.c_str(), object.fshader.c_str());

    // 从顶点着色器中初始化顶点的位置
    object.pLocation = glGetAttribLocation(object.program, "vPosition");
    glEnableVertexAttribArray(object.pLocation);
    glVertexAttribPointer(object.pLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    // 从顶点着色器中初始化顶点的颜色
    object.cLocation = glGetAttribLocation(object.program, "vColor");
    glEnableVertexAttribArray(object.cLocation);
    glVertexAttribPointer(object.cLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(mesh->getPoints().size() * sizeof(glm::vec3)));

    // 获得矩阵存储位置
    object.matrixLocation = glGetUniformLocation(object.program, "matrix");
}

void init() {
    // 读取着色器并使用
    std::string vshader, fshader;
    vshader = "shaders/vshader.glsl";
    fshader = "shaders/fshader.glsl";

    cube->generateCube();
    bindObjectAndData(cube, cube_object, vshader, fshader);
    
    pause = true;  // 初始时旋转暂停
    
    glClearColor(0.0, 0.0, 0.0, 1.0);  // 黑色背景
}

glm::mat4 m(1.0, 0.0, 0.0, 0.0,
            0.0, 1.0, 0.0, 0.0,
            0.0, 0.0, 1.0, 0.0,
            0.0, 0.0, 0.0, 1.0);

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  // 清理窗口

    glUseProgram(cube_object.program);

    glBindVertexArray(cube_object.vao);

    if (!pause) {
        m = glm::rotate(m, glm::radians(rotateTheta.x), glm::vec3(1.0f, 0.0f, 0.0f));
        m = glm::rotate(m, glm::radians(rotateTheta.y), glm::vec3(0.0f, 1.0f, 0.0f));
        m = glm::rotate(m, glm::radians(rotateTheta.z), glm::vec3(0.0f, 0.0f, 1.0f));
    }

    // 从指定位置 matrixLocation 中传入变换矩阵 m
    glUniformMatrix4fv(cube_object.matrixLocation, 1, GL_FALSE, glm::value_ptr(m));

    // 绘制模型中的各个三角形
    glDrawArrays(GL_TRIANGLES, 0, cube->getPoints().size());
}

// 通过 Delta 值更新 Theta
void updateTheta(int axis, int sign) {
    currentAxis = axis;
    switch (currentTransform) {  // 根据变换类型, 增加或减少某种变换的变化量
        case TRANSFORM_SCALE:
            scaleTheta[axis] += sign * scaleDelta;
            break;
        case TRANSFORM_ROTATE:
            rotateTheta[axis] += sign * rotateDelta;
            break;
        case TRANSFORM_TRANSLATE:
            translateTheta[axis] += sign * translateDelta;
            break;
    }
}

// 复原 Theta 和 Delta
void resetTheta() {
    printf("Reseted!\n");
    scaleTheta = glm::vec3(1.0, 1.0, 1.0);
    rotateTheta = glm::vec3(0.0, 0.0, 0.0);
    translateTheta = glm::vec3(0.0, 0.0, 0.0);
    scaleDelta = DEFAULT_DELTA;
    rotateDelta = DEFAULT_DELTA;
    translateDelta = DEFAULT_DELTA;
}

// 更新变化Delta值
void updateDelta(int sign) {
    switch (currentTransform) {
        // 根据变化类型增加或减少每一次变化的单位变化量
        case TRANSFORM_SCALE:
            scaleDelta += sign * DELTA_DELTA;
            break;
        case TRANSFORM_ROTATE:
            rotateDelta += sign * DELTA_DELTA;
            break;
        case TRANSFORM_TRANSLATE:
            translateDelta += sign * DELTA_DELTA;
            break;
    }
}

void printHelp() {
    printf("Mouse Options:\n");
    printf("        Left button: Start animation\n");
    printf("        Right button: Stop animation\n");
    printf("\n");

    printf("Keyboard options:\n");
    printf("        ESC: Exit\n");
    printf("        1: Line mode\n");
    printf("        2: Surface mode\n");
    printf("        T: Reset all transformations and deltas\n");
    
    printf("    - In animation\n");
    printf("        X: Set X Axis as the rotation axis\n");
    printf("        Y: Set Y Axis as the rotation axis\n");
    printf("        Z: Set Z Axis as the rotation axis\n");
    printf("        Note1: Press Shift at the same time to rotate counter-clockwise. \n");
    
    printf("        R: Increase delta of currently selected transform\n");
    printf("        F: Decrease delta of currently selected transform\n");
    printf("        Note2: Press X or Y or Z again after pressing R or F!\n");

    // printf("    - Not in animation\n");
    // printf("        Q: Increase x\n");
	// printf("        A: Decrease x\n");
	// printf("        W: Increase y\n");
	// printf("        S: Decrease y\n");
	// printf("        E: Increase z\n");
	// printf("        D: Decrease z\n");
}

void key_callback(GLFWwindow *window, int key, int scancode, int action, int mode) {
    switch (key) {
        case GLFW_KEY_ESCAPE:  // 退出
            if (action == GLFW_PRESS)
                glfwSetWindowShouldClose(window, GL_TRUE);
            break;
        
        case GLFW_KEY_1:  // 线模式
            if (action == GLFW_PRESS)
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            break;
        case GLFW_KEY_2:  // 面模式
            if (action == GLFW_PRESS)
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            break;
        
        // 绕轴旋转, 按 shift 键可逆时针旋转
        case GLFW_KEY_X:
        case GLFW_KEY_Y:
        case GLFW_KEY_Z:
            if (action == GLFW_PRESS) {
                int axis = (key == GLFW_KEY_X ? X_AXIS : (key == GLFW_KEY_Y ? Y_AXIS : Z_AXIS));
                char axis_ch = (axis == X_AXIS ? 'x' : (axis == Y_AXIS ? 'y' : 'z'));
                int sign = (mode == GLFW_MOD_SHIFT ? 1 : -1);

                updateTheta(axis, sign);

                if (pause)  printf("Animation stoped.\n");
                else printf("Animation started.\n");

                if (mode == GLFW_MOD_SHIFT) printf("Current Rotation: %c-axis counter-clockwise\n", axis_ch);
                else if (mode == 0x0000) printf("Current Rotation: %c-axis clockwise\n", axis_ch);
            }
            break;

        case GLFW_KEY_R:  // 加速旋转
            updateDelta(1);
            printf("Sped up. Current Speed: %.02lf\n", rotateDelta);
            break;
        case GLFW_KEY_F:  // 减速旋转
            updateDelta(-1);
            printf("Sped down. Current Speed: %.02lf\n", rotateDelta);
            break;

        case GLFW_KEY_T:  // 重置
            if (action == GLFW_PRESS) {
                resetTheta();
                m = glm::mat4(1.0);
                if (pause)  printf("Animation stoped.\n");
                else printf("Animation started.\n");
            }
            break;
    }
}

void mouse_button_callback(GLFWwindow *window, int button, int action, int mode) {
    switch (button) {
        case GLFW_MOUSE_BUTTON_LEFT:  // 开始旋转
            if (action == GLFW_PRESS) {
                pause = 0;
                printf("Animation started.\n");
            }
            break;
        case GLFW_MOUSE_BUTTON_RIGHT:  // 停止旋转
            if (action == GLFW_PRESS) {
                pause = 1;
                printf("Animation stoped.\n");
            }
            break;
    }
}

void cleanData() {
    cube->cleanData();

    // 释放内存
    delete cube;
    cube = NULL;

    // 删除绑定的对象
    glDeleteVertexArrays(1, &cube_object.vao);

    glDeleteBuffers(1, &cube_object.vbo);
    glDeleteProgram(cube_object.program);
}

void framebuffer_size_callback(GLFWwindow *window, int width, int height) {
    glViewport(0, 0, width, height);
}

int main(int argc, char **argv) {
    glfwInit();  // 初始化 GLFW 库

    // 配置 GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // 配置窗口属性
    std::string windowName = u8"2021192010_王曦_实验二";
    GLFWwindow *window = glfwCreateWindow(600, 600, windowName.c_str(), NULL, NULL);
    if (window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSetKeyCallback(window, key_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // 调用 OpenGL 的函数前初始化 GLAD
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    init();
    
    printHelp();  // 输出帮助信息

    if (pause)  printf("Animation stoped.\n");
    else printf("Animation started.\n");

    // 启用深度测试
    glEnable(GL_DEPTH_TEST);
    while (!glfwWindowShouldClose(window)) {
        display();

        // 交换颜色缓冲, 检查触发事件
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    cleanData();

    return 0;
}