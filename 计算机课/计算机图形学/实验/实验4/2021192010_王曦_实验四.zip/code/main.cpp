#include "Angel.h"
#include "Camera.h"
#include "MeshPainter.h"
#include "TriMesh.h"

#include <string>
#include <vector>

#pragma execution_character_set("utf-8")

int WIDTH = 600;
int HEIGHT = 600;

int mainWindow;

Camera *camera = new Camera();
Light *light = new Light();
MeshPainter *painter = new MeshPainter();

std::vector<TriMesh*> meshList;  // ���պ�ɾ���������������

void init() {
    // ��ȡ��ɫ����ʹ��
    std::string vshader, fshader;
    vshader = "shaders/vshader.glsl";
    fshader = "shaders/fshader.glsl";

    // ���ù�Դλ��
    light->setTranslation(glm::vec3(0.0, 0.0, 2.0));
    light->setAmbient(glm::vec4(1.0, 1.0, 1.0, 1.0));  // ������
    light->setDiffuse(glm::vec4(1.0, 1.0, 1.0, 1.0));  // ������
    light->setSpecular(glm::vec4(1.0, 1.0, 1.0, 1.0));  // ���淴��
    light->setAttenuation(1.0, 0.045, 0.0075);  // ˥��ϵ��

    // ��ȡ����ģ��
    TriMesh *table = new TriMesh();
    table->setNormalize(true);
    table->readObj("./assets/table.obj");

    // ���������λ�ơ���ת
    table->setTranslation(glm::vec3(-0.7, 0.0, 0.0)); 
    table->setRotation(glm::vec3(-90.0, 0.0, 0.0));   
    table->setScale(glm::vec3(2.0, 2.0, 2.0));

    // �����ӵ��������ص� painter
    painter->addMesh(table, "table1", "./assets/table.png", vshader, fshader);
    meshList.push_back(table);

    // ��ȡ����ģ��
    TriMesh *wawa = new TriMesh();
    wawa->setNormalize(true);         
    wawa->readObj("./assets/wawa.obj"); 

    // ���������λ�ơ���ת
    wawa->setTranslation(glm::vec3(0.7, 0.0, 0.0)); 
    wawa->setRotation(glm::vec3(-90.0, 0.0, 0.0));  
    wawa->setScale(glm::vec3(2.0, 2.0, 2.0));

    // �����޵��������ص� painter
    painter->addMesh(wawa, "wawa1", "./assets/wawa.png", vshader, fshader);
    meshList.push_back(wawa);

    glClearColor(1.0, 1.0, 1.0, 1.0);  // ��ɫ����
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    painter->drawMeshes(light, camera);
}

void printHelp() {
    std::cout << "================================================" << std::endl;
    std::cout << "Use mouse to controll the light position (drag)." << std::endl;
    std::cout << "================================================" << std::endl
              << std::endl;

    std::cout << "Keyboard Usage" << std::endl;
    std::cout << "[Window]" << std::endl
              << "ESC:		Exit" << std::endl
              << "h:		Print help message" << std::endl
              <<

        std::endl
              << "[Camera]" << std::endl
              << "SPACE:		Reset camera parameters" << std::endl
              << "u/U:		Increase/Decrease the rotate angle" << std::endl
              << "i/I:		Increase/Decrease the up angle" << std::endl
              << "o/O:		Increase/Decrease the camera radius" << std::endl
              << std::endl;
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode) {
    float tmp;
    glm::vec4 ambient;
    if (action == GLFW_PRESS) {
        switch (key) {
            case GLFW_KEY_ESCAPE:
                exit(EXIT_SUCCESS);
                break;
            case GLFW_KEY_H:
                printHelp();
                break;
            default:
                camera->keyboard(key, action, mode);
                break;
        }
    }
}

void cleanData() {
    delete camera;
    camera = NULL;

    delete light;
    light = NULL;

    painter->cleanMeshes();

    delete painter;
    painter = NULL;

    for (int i = 0; i < meshList.size(); i++) delete meshList[i];
    meshList.clear();
}

// ���ڴ�С�ı�ʱ�Ļص�����
void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

int main(int argc, char** argv) {
    glfwInit();  // ��ʼ��GLFW��

    // ����GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // ���ô�������
    GLFWwindow* window = glfwCreateWindow(600, 600, "2021192010_����_ʵ����", NULL, NULL);
    if (window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSetKeyCallback(window, key_callback);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    init();
    printHelp();  // ���������Ϣ
    glEnable(GL_DEPTH_TEST);  // ������Ȳ���

    while (!glfwWindowShouldClose(window)) {
        display();
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    cleanData();

    return 0;
}