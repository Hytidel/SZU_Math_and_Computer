#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>

int tprintf(const char* fmt, ...) {
	struct tm* tstruct;
	time_t tsec = time(NULL);
	tstruct = localtime(&tsec);
	printf("%02d:%02d:%02d: %5d | ", tstruct->tm_hour, tstruct->tm_min, tstruct->tm_sec, getpid());

	va_list args;
	va_start(args, fmt);
	return vprintf(fmt, args);
}

int main(void) {
	pid_t pid;
	printf("Hello from parent process (PID = %d).\n", getpid());

	pid = fork();
	if (!pid) {  // child process
		getchar();  // block
	}
	else if (~pid) {  // parent process
		getchar();  // block
		waitpid(pid, NULL, 0);
	}
	else {
		tprintf("Error when %d fork().\n", getpid());
	}

	return 0;
}
