#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
	int h;
	scanf("%d", &h);

	for (int i = 0; i < h - 1; i++) {
		pid_t pid1 = fork();  // left son
		if (!pid1) {  // child process (left)
			printf("I'm child process (PID = %d), my parent process is %d.\n", getpid(), getppid());
			printf("Child process (PID = %d) has exited.\n", getpid());
		}
		else if (pid1) {
			pid_t pid2 = fork();  // right son
			if (!pid2) {  // child process (right)
				printf("I'm child process (PID = %d), my parent process is %d.\n", getpid(), getppid());
				printf("Child process (PID = %d) has exited.\n", getpid());
			}
			else if (pid2) {  // parent process
				printf("I'm parent process (PID = %d), my children process are (PID = %d) and (PID = %d).\n", getpid(), pid1, pid2);
				printf("Parent waiting for child to exit.\n");
				waitpid(pid1, NULL, 0);
				waitpid(pid2, NULL, 0);
				printf("Parent process (PID = %d) has exited.\n", getpid());
			}
			else {
				printf("Error when %d fork() child process.\n", getpid());
			}
		}
		else {
			printf("Error when %d fork() child process.\n", getpid());
		}
	}

	pause();  // blocked

	return 0;
}
