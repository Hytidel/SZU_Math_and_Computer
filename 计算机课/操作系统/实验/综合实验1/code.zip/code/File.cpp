#include "File.h"

File::File() {
}

File::File(index_t _fileIndex, std::string _fileName, std::string _fileOwner, bool _isDirectory, index_t _fatherFileIndex) {
    fileIndex = _fileIndex;
    fileName = _fileName;
    fileOwner = _fileOwner;
    isDirectory = _isDirectory;
    fatherFileIndex = _fatherFileIndex;
}

File::~File() {
}

void File::setFileIndex(index_t _fileIndex) {
    fileIndex = _fileIndex;
}

index_t File::getFileIndex() {
    return fileIndex;
}

void File::setFileName(std::string _fileName) {
    fileName = _fileName;
}

std::string File::getFileName() {
    return fileName;
}

void File::setFileSize(size_t _fileSize) {
    fileSize = _fileSize;
}

size_t File::getFileSize() {
    return fileSize;
}

void File::setFileOwner(std::string _fileOwner) {
    fileOwner = _fileOwner;
}

std::string File::getFileOwner() {
    return fileOwner;
}

void File::setIsDirectory(bool _isDirectory) {
    isDirectory = _isDirectory;
}

bool File::getIsDirectory() {
    return isDirectory;
}

void File::setFatherFileIndex(index_t _fatherFileIndex) {
    fatherFileIndex = _fatherFileIndex;
}

index_t File::getFatherFileIndex() {
    return fatherFileIndex;
}

bool operator<(File A, File B) {
    return A.getFileIndex() < B.getFileIndex();
}

bool operator==(File A, File B) {
    return A.getFileIndex() == B.getFileIndex();
}
