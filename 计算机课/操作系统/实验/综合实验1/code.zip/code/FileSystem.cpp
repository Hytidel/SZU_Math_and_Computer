#include "FileSystem.h"

FileSystem::FileSystem(std::string fileSystemName) {
    initialPath = fileSystemName;
    currentIndex = 1;  // 系统临时目录
    fileList.resize(5);
    fileTree.resize(5);
    rootIndex = 2;
    rootName = "root";

    // 系统临时目录
    fileList[1] = { 1, "tmp", "system", true, 0 };
    fileList[1].setFileSize(0);
    fileTree[0].push_back(1);

    // 构建 root 目录
    if (!initialize(rootName)) {
        std::cerr << "File System initialized failed." << std::endl;
        return;
    }

    // root 目录构建成功
    std::cout << "File System initialized successfully." << std::endl;
    displayFileTree();
}

FileSystem::~FileSystem() {
}

void FileSystem::setCurrentIndex(index_t _currentIndex) {
    currentIndex = _currentIndex;
}

index_t FileSystem::getCurrentIndex() {
    return currentIndex;
}

void FileSystem::setRootIndex(index_t _rootIndex) {
    rootIndex = _rootIndex;
}

index_t FileSystem::getRootIndex() {
    return rootIndex;
}

void FileSystem::setRootName(std::string _rootName) {
    rootName = _rootName;
}

std::string FileSystem::getRootName() {
    return rootName;
}

index_t FileSystem::getNewIndex() {
    expandCapacity(++currentIndex);
    return currentIndex;
}

bool FileSystem::expandCapacity(index_t index) {
    if (index < fileList.size()) {
        return false;
    }

    int currentSize = fileList.size();
    fileList.resize(2 * currentSize);
    fileTree.resize(2 * currentSize);
    return true;
}

bool FileSystem::initialize(std::string rootPath) {
    if (!isDirectoryExists(getTruePath(rootPath))) {
        std::cerr << "Directory \"" << rootPath << "\" not found." << std::endl;
        return false;
    }

    if (!isDirectoryExists(getTruePath("tmp"))) {
        system(("mkdir " + initialPath + "\\" + "tmp").c_str());
    }

    bool ok = true;

    auto dfs = [&](auto&& self, index_t currentIndex, std::string currentPath, index_t fatherIndex)->void {
        std::vector<std::string> files;
        std::vector<std::string> directories;
        if (!getFiles(getTruePath(currentPath), files, directories)) {
            ok = false;
            return;
        }

        // // 输出 currentPath 目录下的文件
        // std::cout << currentPath << std::endl;
        // std::cout << "Files:" << std::endl;
        // for (auto file : files) {
        //     std::cout << "    " << file << std::endl;
        // }
        // // 输出 currentPath 目录下的目录
        // std::cout << "Directories:" << std::endl;
        // for (auto directory : directories) {
        //     std::cout << "    " << directory << std::endl;
        // }
        // std::cout << std::endl;

        for (auto fileName : files) {
            index_t newIndex = getNewIndex();
            fileList[newIndex] = { newIndex, fileName, "system", false, currentIndex };
            fileList[newIndex].setFileSize(getFileSize(getTruePath(currentPath + "/" + fileName)));
            fileTree[currentIndex].push_back(newIndex);   
        }

        for (auto directoryName : directories) {
            index_t newIndex = getNewIndex();
            fileList[newIndex] = { newIndex, directoryName, "system", true, currentIndex };
            fileList[newIndex].setFileSize(0);
            fileTree[currentIndex].push_back(newIndex);

            self(self, newIndex, currentPath + "/" + directoryName, currentIndex);
        }
    };

    // root 目录
    index_t rootIndex = getNewIndex();
    fileList[rootIndex] = { 2, rootPath, "system", true, 0 };
    fileList[rootIndex].setFileSize(0);
    fileTree[0].push_back(2);

    // 递归构建 root 目录下的文件和目录
    dfs(dfs, 2, rootPath, 0);

    return ok;
}

std::string FileSystem::getTruePath(std::string path) {
    return initialPath + "\\" + path;
}

void FileSystem::displayFileTree() {
    for (index_t u = 1; u <= currentIndex; u++) {
        std::cout << "[" << u << "] ";
        for (auto v : fileTree[u]) {
            std::cout << v << " ";
        }
        std::cout << std::endl;
    }

    for (index_t u = 1; u <= currentIndex; u++) {
        std::cout << u << " -> " << fileList[u].getFileName() << ' ';
        if (fileList[u].getIsDirectory()) {
            std::cout << getSizeOfDirectory(u);
        }
        else {
            std::cout << fileList[u].getFileSize();
        }
        std::cout << std::endl;
    }

    std::cout << std::endl;
}

size_t FileSystem::getSizeOfDirectory(index_t index) {
    if (!fileList[index].getIsDirectory()) {
        std::cerr << "File " << index << " is not a directory" << std::endl;
        return 0;
    }

    size_t totalSize = 0;
    
    auto dfs = [&](auto&& self, index_t currentIndex)->void {
        auto& file = fileList[currentIndex];
        if (file.getIsDirectory()) {
            for (auto nextIndex : fileTree[currentIndex]) {
                self(self, nextIndex);
            }
        }
        else {
            totalSize += file.getFileSize();
        }
    };

    dfs(dfs, index);

    return totalSize;
}

state_t FileSystem::displayFiles(index_t index, bool _l, bool pipe, std::string fileName, bool screen) {
    std::vector<int> directories;
    std::vector<int> files;
    for (auto fileIndex : fileTree[index]) {
        auto& file = fileList[fileIndex];
        if (file.getIsDirectory()) {
            directories.push_back(fileIndex);
        }
        else {
            files.push_back(fileIndex);
        }
    }

    // 按文件名字典序排列
    std::sort(directories.begin(), directories.end(), [&](int i, int j) {
        return fileList[i].getFileName() < fileList[j].getFileName();
    });
    std::sort(files.begin(), files.end(), [&](int i, int j) {
        return fileList[i].getFileName() < fileList[j].getFileName();
    });

    std::ofstream outputFile("HyFileSystem/tmp/tmpFile", std::ios_base::trunc);  // 覆盖模式打开
    if (!outputFile.is_open()) {
        return CANNOT_OPEN_TEMPORARY_FILE;
    }

    if (!_l) {
        outputFile << "[Directory]" << std::endl;
        for (auto directoryIndex : directories) {
            outputFile << "    " << fileList[directoryIndex].getFileName() << std::endl;
        }
        outputFile << std::endl;
        outputFile << "[File]" << std::endl;
        for (auto fileIndex : files) {
            outputFile << "    " << fileList[fileIndex].getFileName() << std::endl;
        }
        outputFile << std::endl;
    }
    else {  // -l 选项
        outputFile << "fileIndex" << "\t" 
            << "fileName" << "\t"
            << "fileSize" << "\t"
            << "fileOwner" << "\t"
            << "isDirectory" << "\t"
            << "fatherFileIndex" << std::endl;
        
        for (auto directoryIndex : directories) {
            auto& directory = fileList[directoryIndex];
            outputFile << directory.getFileIndex() << "\t" << "\t" 
                << directory.getFileName() << "\t" << "\t" 
                << getSizeOfDirectory(directoryIndex) << "\t" << "\t" 
                << directory.getFileOwner() << "\t" << "\t" 
                << directory.getIsDirectory() << "\t" << "\t" 
                << directory.getFatherFileIndex() << std::endl;
        }
        for (auto fileIndex : files) {
            auto& file = fileList[fileIndex];
            outputFile << file.getFileIndex() << "\t"  << "\t" 
                << file.getFileName() << "\t" << "\t" 
                << file.getFileSize() << "\t" << "\t" 
                << file.getFileOwner() << "\t" << "\t" 
                << file.getIsDirectory() << "\t" << "\t" 
                << file.getFatherFileIndex() << std::endl;
        }
    }

    outputFile.close();

    if (screen) {
        std::ifstream inputFile("HyFileSystem/tmp/tmpFile");
        if (!inputFile.is_open()) {
            return CANNOT_OPEN_TEMPORARY_FILE;
        }

        std::string line;
        while (std::getline(inputFile, line)) {
            if (pipe || fileName.size()) {
                if (line.find(fileName) == std::string::npos) {
                    continue;
                }
            }

            std::cout << line << std::endl;
        }

        inputFile.close();
    }

    return OK;
}

state_t FileSystem::getFatherIndex(index_t index) {
    return fileList[index].getFatherFileIndex();
}

std::string FileSystem::getFileName(index_t index) {
    return fileList[index].getFileName();
}

index_t FileSystem::isFileNameExists(index_t index, std::string fileName) {
    fileName = stringToLower(fileName);

    for (auto nextIndex : fileTree[index]) {
        std::string tmpFileName = fileList[nextIndex].getFileName();
        tmpFileName = stringToLower(tmpFileName);
        
        if (tmpFileName == fileName) {
            return nextIndex;
        }
    }

    return 0;  // 未找到
}

std::tuple<state_t, index_t, std::string> FileSystem::getFileByPath(std::string filePath, index_t currentIndex, std::string currentPath) {
    // 跳到上级
    if (filePath.substr(0, 2) == "..") {
        if (currentIndex == getRootIndex()) {
            return { DIRECTORY_CHANGED_FAILED, currentIndex, currentPath };
        }

        index_t fatherIndex = getFatherIndex(currentIndex);
        currentPath = currentPath.substr(0, (int)currentPath.length() - (int)getFileName(currentIndex).length() - 1);
        currentIndex = fatherIndex;
        
        return { OK, currentIndex, currentPath };
    }

    // ..
    if (filePath.substr(0, 3) == "..\\") {
        if (currentIndex == getRootIndex()) {
            return { DIRECTORY_CHANGED_FAILED, currentIndex, currentPath };
        }

        index_t fatherIndex = getFatherIndex(currentIndex);
        filePath = getFileName(fatherIndex) + filePath.substr(2);
    }

    // .
    if (filePath.substr(0, 1) == "." || filePath.substr(0, 2) == ".\\") {
        filePath = getFileName(currentIndex) + filePath.substr(1);
    }

    auto splitFilePath = split(filePath, '\\');

    std::string tmpCurrentPath;
    index_t tmpCurrentIndex;
    if (splitFilePath[0] == getRootName()) {  // 绝对路径
        tmpCurrentPath = splitFilePath[0] + "\\";
        tmpCurrentIndex = getRootIndex();
    }
    else {  // 相对路径
        tmpCurrentPath = currentPath;
        tmpCurrentIndex = currentIndex;
    }
    
    for (unsigned int i = 1; i < splitFilePath.size(); i++) {
        index_t nextIndex = isFileNameExists(tmpCurrentIndex, splitFilePath[i]);
        if (nextIndex) {
            tmpCurrentPath = tmpCurrentPath + splitFilePath[i] + "\\";
            tmpCurrentIndex = nextIndex;
        }
        else {
            return { DIRECTORY_CHANGED_FAILED, tmpCurrentIndex, tmpCurrentPath };
        }
    }

    return { OK, tmpCurrentIndex, tmpCurrentPath };
}

std::string FileSystem::getFilePath(index_t index) {
    std::vector<index_t> stk;
    while (index) {
        stk.push_back(index);
        index = fileList[index].getFatherFileIndex();
    }

    std::string filePath;
    for (; stk.size(); stk.pop_back()) {
        filePath = filePath + fileList[stk.back()].getFileName() + "\\";
    }
    filePath.pop_back();  // 去掉最后的 '\'
    return filePath;
}

index_t FileSystem::createFile(index_t index, std::string fileName, std::string fileOwner, bool isDirectory) {
    std::string filePath = getFilePath(index) + "\\" + fileName;
    std::string trueFilePath = getTruePath(filePath);

    if (isDirectory) {  // 创建目录
        system(("mkdir " + trueFilePath).c_str());
    }
    else {  // 创建文件
        system(("echo > " + trueFilePath).c_str());
    }

    index_t newIndex = getNewIndex();
    fileList[newIndex] = { newIndex, fileName, fileOwner, isDirectory, index };
    if (isDirectory) {  // 目录
        fileList[newIndex].setFileSize(0);
    }
    else {  // 文件
        fileList[newIndex].setFileSize(getFileSize(trueFilePath));
    }
    fileTree[index].push_back(newIndex);

    return newIndex;
}

std::tuple<state_t, index_t, std::string> FileSystem::buildPath(std::string filePath, std::string fileOwner, index_t currentIndex, std::string currentPath) {
    // 跳到上级
    if (filePath.substr(0, 2) == "..") {
        if (currentIndex == getRootIndex()) {
            return { PATH_BUILT_FAILED, currentIndex, currentPath };
        }

        index_t fatherIndex = getFatherIndex(currentIndex);
        currentPath = currentPath.substr(0, (int)currentPath.length() - (int)getFileName(currentIndex).length() - 1);
        currentIndex = fatherIndex;
    }

    // ..
    if (filePath.substr(0, 3) == "..\\") {
        if (currentIndex == getRootIndex()) {
            return { PATH_BUILT_FAILED, currentIndex, currentPath };
        }

        index_t fatherIndex = getFatherIndex(currentIndex);
        filePath = getFileName(fatherIndex) + filePath.substr(2);
    }

    // .
    if (filePath.substr(0, 1) == "." || filePath.substr(0, 2) == ".\\") {
        filePath = getFileName(currentIndex) + filePath.substr(1);
    }

    auto splitFilePath = split(filePath, '\\');

    std::string tmpCurrentPath;
    index_t tmpCurrentIndex;
    if (splitFilePath[0] == getRootName()) {  // 绝对路径
        tmpCurrentPath = splitFilePath[0] + "\\";
        tmpCurrentIndex = getRootIndex();
    }
    else {  // 相对路径
        tmpCurrentPath = currentPath;
        tmpCurrentIndex = currentIndex;
    }
    
    for (unsigned int i = 1; i < splitFilePath.size(); i++) {
        index_t nextIndex = isFileNameExists(tmpCurrentIndex, splitFilePath[i]);
        tmpCurrentPath = tmpCurrentPath + splitFilePath[i] + "\\";
        if (nextIndex) {
            tmpCurrentIndex = nextIndex;
        }
        else {  // 新建目录
            tmpCurrentIndex = createFile(tmpCurrentIndex, splitFilePath[i], fileOwner, true);
        }
    }

    return { OK, tmpCurrentIndex, tmpCurrentPath };
}

std::pair<state_t, index_t> FileSystem::copyFile(index_t destinationIndex, index_t sourceIndex, std::string fileOwner) {
    std::string fileName = fileList[sourceIndex].getFileName();
    if (isFileNameExists(currentIndex, fileName)) {
        return { DUPLICATE_FILE_NAME, currentIndex };
    }

    std::string destinationPath = getFilePath(destinationIndex);
    std::string sourcePath = getFilePath(sourceIndex);
    
    std::string trueDestinationPath = getTruePath(destinationPath);
    std::string trueSourcePath = getTruePath(sourcePath);
    system(("copy " + trueSourcePath + " " + trueDestinationPath).c_str());

    index_t newIndex = getNewIndex();
    fileList[newIndex] = { newIndex, fileName, fileOwner, false, destinationIndex };
    fileList[newIndex].setFileSize(fileList[sourceIndex].getFileSize());
    fileTree[destinationIndex].push_back(newIndex);

    return { OK, newIndex };
}

state_t FileSystem::copyFiles(std::string sourcePath, std::string destinationPath, std::string fileOwner, index_t currentIndex, std::string currentPath) {
    // 源
    auto [sourceState, sourceIndex, _sourcePath] = getFileByPath(sourcePath, currentIndex, currentPath);
    if (sourceState != OK) {
        return SOURCE_NOT_EXISTS;
    }

    // 目的
    size_t pos = destinationPath.rfind('\\');
    std::string prePath = destinationPath.substr(0, pos);  // destinationPath 前的所有目录
    auto [destinationState, destinationIndex, _destinationPath] = buildPath(prePath, fileOwner, currentIndex, currentPath);  // 建出所有路径
    if (destinationState != OK) {
        return PATH_BUILT_FAILED;
    }

    state_t state = OK;
    index_t tmpCurrentIndex = destinationIndex;
    std::string tmpCurrentPath = prePath;

    // 递归复制
    auto dfs = [&](auto&& self, index_t currentIndex, std::string currentPath)->void {
        auto& file = fileList[currentIndex];
        if (file.getIsDirectory()) {  // 目录
            index_t newIndex = createFile(tmpCurrentIndex, file.getFileName(), fileOwner, true);

            for (auto nextIndex : fileTree[currentIndex]) {
                auto& nextFile = fileList[nextIndex];
                std::string nextFileName = nextFile.getFileName();
                std::string nextPath = currentPath + "\\" + nextFileName;

                tmpCurrentIndex = isFileNameExists(tmpCurrentIndex, nextFileName);
                tmpCurrentPath = tmpCurrentPath + "\\" + nextFileName;
                self(self, nextIndex, nextPath);
                tmpCurrentIndex = fileList[tmpCurrentIndex].getFatherFileIndex();
                tmpCurrentPath = tmpCurrentPath.substr(0, (int)tmpCurrentPath.length() - (int)nextFileName.length() - 1);
            }
        }
        else {  // 文件
            auto [copyState, newIndex] = copyFile(tmpCurrentIndex, currentIndex, fileOwner);
            if (copyState != OK) {
                state = copyState;
            }
        }
    };

    dfs(dfs, sourceIndex, sourcePath);

    return state;
}

std::pair<state_t, std::vector<std::string>> FileSystem::readFile(index_t fileIndex) {
    auto& file = fileList[fileIndex];
    if (file.getIsDirectory()) {
        return { DIRECTORY_CANNOT_BE_READ, {} };
    }

    std::string filePath = getFilePath(fileIndex);
    std::string trueFilePath = getTruePath(filePath);

    std::vector<std::string> lines;
    std::ifstream inputFile(trueFilePath);
    if (!inputFile.is_open()) {
        return { CANNOT_OPEN_SOURCE_FILE, {} };
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        lines.push_back(line);
    }

    inputFile.close();

    return { OK, lines };
}

state_t FileSystem::writeFile(index_t fileIndex, std::vector<std::string> lines) {
    if (fileIndex > currentIndex) {
        return SOURCE_NOT_EXISTS;
    }

    std::string filePath = getFilePath(fileIndex);
    std::string trueFilePath = getTruePath(filePath);
    std::ofstream outputFile(trueFilePath);
    if (!outputFile.is_open()) {
        return CANNOT_OPEN_SOURCE_FILE;
    }

    for (auto& line : lines) {
        outputFile << line << std::endl;
    }

    outputFile.close();

    return OK;
}

std::pair<state_t, std::string> FileSystem::completeFilePath(std::string filePath, index_t currentIndex, std::string currentPath) {
    // 跳到上级
    if (filePath == "..") {
        if (currentIndex == getRootIndex()) {
            return { ILLEGAL_PATH, filePath };
        }

        index_t fatherIndex = getFatherIndex(currentIndex);
        currentPath = currentPath.substr(0, (int)currentPath.length() - (int)getFileName(currentIndex).length() - 1);
        currentIndex = fatherIndex;
        
        return { OK, currentPath };
    }

    // ..
    if (filePath.substr(0, 3) == "..\\") {
        if (currentIndex == getRootIndex()) {
            return { ILLEGAL_PATH, currentPath };
        }

        index_t fatherIndex = getFatherIndex(currentIndex);
        filePath = getFileName(fatherIndex) + filePath.substr(2);
    }

    // .
    if (filePath.substr(0, 1) == "." || filePath.substr(0, 2) == ".\\") {
        filePath = getFileName(currentIndex) + filePath.substr(1);
    }

    return { OK, filePath };
}

std::tuple<state_t, index_t, std::string> FileSystem::redirectToOutputFile(std::string outputFilePath, std::string fileOwner, index_t currentIndex, std::string currentPath) {
    auto [state1, _outputFilePath] = completeFilePath(outputFilePath, currentIndex, currentPath);
    if (state1 != OK) {
        return { ILLEGAL_PATH, currentIndex, currentPath };
    }

    if (outputFilePath.back() == '/' || outputFilePath.back() == '\\') {
        outputFilePath.pop_back();
    }
    size_t pos = outputFilePath.rfind('\\');
    std::string prePath = outputFilePath.substr(0, pos);
    auto [state2, preIndex, _prePath] = buildPath(prePath, fileOwner, currentIndex, currentPath);
    if (state2 != OK) {
        return { PATH_BUILT_FAILED, currentIndex, currentPath };
    }

    std::string fileName = outputFilePath.substr(pos + 1);
    auto newIndex = createFile(preIndex, fileName, fileOwner);

    auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
    writeFile(newIndex, lines);

    return { OK, newIndex, outputFilePath };
}
