#include <bits/stdc++.h>
using namespace std;

int main() {
    // string line = "ls -l || grep t1";
    // int pos = line.find("||");
    // cout << line.substr(0, pos - 1) << '\n';
    // cout << line.substr(pos + 3) << '\n';

    

    return 0;
}