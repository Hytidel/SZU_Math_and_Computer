#include "Headers.h"
#include "File.h"
#include "FileSystem.h"

FileSystem fileSystem("HyFileSystem");
std::string userName = "Hytidel";

// 合法命令
// std::unordered_set<std::string> ops = {
//     "help",  // 帮助
//     "quit",  // 退出 shell
//     "pwd",  // 打印当前路径
//     "ls",  // 列出目录下的文件
//     "cd",  // 切换当前目录
//     "echo",  // 输出信息
//     "touch",  // 创建文件
//     "mkdir",  // 创建目录
//     "cp",  // 复制文件
//     "rm",  // 删除文件
//     "move",  // 移动文件
//     "cat",  // 读取文件
//     "more",  // 读取文件前若干行
//     "grep",  // 文本搜索
//     "run",  // 运行可执行程序
//     "g++",  // 编译 C++
// };

std::string currentPath = fileSystem.getRootName() + "\\";
index_t currentIndex = fileSystem.getRootIndex();

// 处理行
state_t processLine(std::string line);

// 处理单个命令
state_t processSingleCommand(std::string line, bool pipe = false, bool screen = true);

// 执行 help 命令, 返回错误代码
// state_t _help(std::vector<std::string> splitResult, bool pipe = false, bool screen = true, bool redirectInput = false, bool redirectOutput = false);
state_t _help(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 pwd 命令, 返回错误代码
state_t _pwd(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 ls 命令, 返回错误代码
state_t _ls(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 cd 命令, 返回错误代码
state_t _cd(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 echo 命令, 返回错误代码
state_t _echo(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 touch 命令, 返回错误代码
state_t _touch(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 mkdir 命令, 返回错误代码
state_t _mkdir(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 cp 命令, 返回错误代码
state_t _cp(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 move 命令, 返回错误代码
state_t _move(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 rm 命令, 返回错误代码
state_t _rm(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 cat 命令, 返回错误代码
state_t _cat(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 more 命令, 返回错误代码
state_t _more(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 grep 命令, 返回错误代码
state_t _grep(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 g++ 命令, 返回错误代码
state_t _gpp(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

// 执行 run 命令(运行可执行程序), 返回错误代码
state_t _run(std::vector<std::string> splitResult, bool pipe = false, bool screen = true);

int main() {
    std::cout << "Hello " << userName << "." << std::endl;

    std::cout << "[" << userName << "@HyShell ~ " << currentPath << "]$ ";

    std::string line;  // 当前行
    while (getline(std::cin, line)) {
        if (line.empty()) {
            // std::cerr << "Empty line." << std::endl;
            std::cout << "[" << userName << "@HyShell ~ " << currentPath << "]$ ";
            continue;
        }

        while (line.back() == ' ') {
            line.pop_back();
        }

        if (line == "quit") {
            break;
        }
        else {
            auto state = processLine(line);
            if (state != 0) {
                switch (state) {
                    case CANNOT_OPEN_TEMPORARY_FILE:
                        std::cerr << "Cannot open the temporary file." << std::endl;
                        break;
                    case ILLEGAL_COMMAND:
                        std::cerr << "Illegal command." << std::endl;
                        break;
                    case ILLEGAL_FORMAT:
                        std::cerr << "Illegal format." << std::endl;
                        break;
                    case DIRECTORY_CHANGED_FAILED:
                        std::cerr << "Directory changed failed." << std::endl;
                        break;
                    case DUPLICATE_FILE_NAME:
                        std::cerr << "Duplicate file name." << std::endl;
                        break;
                    case SOURCE_NOT_EXISTS:
                        std::cerr << "Source not exists." << std::endl;
                        break;
                    case PATH_BUILT_FAILED:
                        std::cerr << "Path built failed." << std::endl;
                        break;
                    case DIRECTORY_CANNOT_BE_READ:
                        std::cerr << "Directory cannot be read." << std::endl;
                        break;
                    case CANNOT_OPEN_SOURCE_FILE:
                        std::cerr << "Cannot open the source file." << std::endl;
                        break;
                    case ILLEGAL_PATH:
                        std::cerr << "Illegal path." << std::endl;
                        break;
                }
            }
        }

        std::cout << "[" << userName << "@HyShell ~ " << currentPath << "]$ ";
    }

    return 0;
}

// 处理行
state_t processLine(std::string line) {
    state_t state = OK;
    bool first = true;
    bool pipe = false;  // 有管道, 将输出保存到 HyFileSystem/tmp/tmpFile 
    while (line.find("||") != std::string::npos) {
        pipe = true;
        
        size_t pos = line.find("||");
        std::string tmpLine = line.substr(0, pos - 1);
        state = processSingleCommand(tmpLine, first ? false : true, false);
        line = line.substr(pos + 3);

        first = false;
    }

    state = processSingleCommand(line, pipe, true);
    return state;
}

// 处理单个命令
state_t processSingleCommand(std::string line, bool pipe, bool screen) {
    while (line.back() == ' ') {
        line.pop_back();
    }

    auto splitResult = split(line);
    std::string op = splitResult[0];

    state_t state = OK;
    if (op == "help") {
        state = _help(splitResult, pipe, screen);
    }
    else if (op == "pwd") {
        state = _pwd(splitResult, pipe, screen);
    }
    else if (op == "ls") {
        state = _ls(splitResult, pipe, screen);
    }
    else if (op == "cd") {
        state = _cd(splitResult, pipe, screen);
    }
    else if (op == "echo") {
        state = _echo(splitResult, pipe, screen);
    }
    else if (op == "touch") {
        state = _touch(splitResult, pipe, screen);
    }
    else if (op == "mkdir") {
        state = _mkdir(splitResult, pipe, screen);
    }
    else if (op == "cp") {
        state = _cp(splitResult, pipe, screen);
    }
    else if (op == "rm") {
        state = _rm(splitResult, pipe, screen);
    }
    else if (op == "move") {
        state = _move(splitResult, pipe, screen);
    }
    else if (op == "cat") {
        state = _cat(splitResult, pipe, screen);
    }
    else if (op == "more") {
        state = _more(splitResult, pipe, screen);
    }
    else if (op == "grep") {
        state = _grep(splitResult, pipe, screen);
    }
    else if (op == "g++") {
        state = _gpp(splitResult, pipe, screen);
    }
    else if (op == "run") {
        state = _run(splitResult, pipe, screen);
    }
    else {
        state = ILLEGAL_COMMAND;
    }

    return state;
}

// 执行 help 命令, 返回错误代码
// 格式: help [command]
// 输入: [命令]
// 输出: 命令格式
state_t _help(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 help 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string fileName = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else {  // 输入
            fileName = option;
            if (fileName.back() == '/' || fileName.back() == '\\') {
                fileName.pop_back();
            }
        }
    }

    std::ofstream outputFile("HyFileSystem/tmp/tmpFile", std::ios_base::trunc);  // 覆盖模式打开
    if (!outputFile.is_open()) {
        return CANNOT_OPEN_TEMPORARY_FILE;
    }

    outputFile << "help: help [command]" << std::endl;
    outputFile << "quit: quit" << std::endl;
    outputFile << "pwd: pwd" << std::endl;
    outputFile << "ls: ls [-l] [filePath]" << std::endl;
    outputFile << "cd: cd [directory]" << std::endl;
    outputFile << "echo: echo message" << std::endl;
    outputFile << "touch: touch fileName" << std::endl;
    outputFile << "mkdir: mkdir directoryName" << std::endl;
    outputFile << "cp: cp destinationPath sourcePath" << std::endl;
    outputFile << "rm: rm filePath" << std::endl;
    outputFile << "move: move destinationPath sourcePath" << std::endl;
    outputFile << "cat: cat filePath" << std::endl;
    outputFile << "more: more [-number] filePath" << std::endl;
    outputFile << "grep targetText filePath" << std::endl;
    outputFile << "run: run filePath" << std::endl;
    outputFile << "g++: g++ -o destinationPath sourcePath" << std::endl;

    outputFile.close();

    if (screen) {
        std::ifstream inputFile("HyFileSystem/tmp/tmpFile");
        if (!inputFile.is_open()) {
            return CANNOT_OPEN_TEMPORARY_FILE;
        }

        std::string line;
        while (std::getline(inputFile, line)) {
            if (pipe || fileName.size()) {
                if (line.find(fileName) == std::string::npos) {
                    continue;
                }
            }

            std::cout << line << std::endl;
        }

        inputFile.close();
    }
    
    return OK;
}

// 执行 pwd 命令, 返回错误代码
// 格式: pwd
// 输入: 无
// 输出: 当前路径
state_t _pwd(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 pwd 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string fileName = "";
    bool input = false;
    bool output = false;
    std::string inputFilePath = "";
    std::string outputFilePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else if (option == "<") {
            input = true;
        }
        else if (option == ">") {
            output = true;
            screen = false;  // 有输出重定向时关闭屏显
        }
        else if ((input && inputFilePath.empty()) || (output && outputFilePath.empty())) {  // 重定向
            if (input && inputFilePath.empty()) {
                inputFilePath = option;
                if (inputFilePath.back() == '/' || inputFilePath.back() == '\\') {
                    inputFilePath.pop_back();
                }
            }
            else if (output && outputFilePath.empty()) {
                outputFilePath = option;
                if (outputFilePath.back() == '/' || outputFilePath.back() == '\\') {
                    outputFilePath.pop_back();
                }
            }
        }
        else {  // 输入
            fileName = option;
            if (fileName.back() == '/' || fileName.back() == '\\') {
                fileName.pop_back();
            }
        }
    }

    std::ofstream outputFile("HyFileSystem/tmp/tmpFile", std::ios_base::trunc);  // 覆盖模式打开
    if (outputFile.is_open()) {
        outputFile << currentPath << std::endl;

        outputFile.close();
    }
    else {
        return CANNOT_OPEN_TEMPORARY_FILE;
    }

    // 屏显
    if (screen) {
        displayToScreen("HyFileSystem/tmp/tmpFile");
    }

    state_t state = OK;

    // 重定向输出
    if (output) {
        auto [outputState, outputFileIndex, _outputFilePath] = fileSystem.redirectToOutputFile(outputFilePath, userName, currentIndex, currentPath);
        if (outputState != OK) {
            state = outputState;
        }
    }
    
    return state;
}

// 执行 ls 命令, 返回错误代码
// 格式: ls [-l] [filePath]
// 输入: [filePath]
// 输出: 当前目录下的目录和文件
state_t _ls(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 ls 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }
    
    std::unordered_set<std::string> options = {
        "-l", 
    };
    
    // ls [选项]
    bool _l = false;  // -l
    std::string fileName = "";
    bool input = false;
    bool output = false;
    std::string inputFilePath = "";
    std::string outputFilePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            if (!options.count(option)) {
                return ILLEGAL_FORMAT;
            }
            else if (option == "-l") {
                _l = true;
            }
        }
        else if (option == "<") {
            input = true;
        }
        else if (option == ">") {
            output = true;
            screen = false;  // 有输出重定向时关闭屏显
        }
        else if ((input && inputFilePath.empty()) || (output && outputFilePath.empty())) {  // 重定向
            if (input && inputFilePath.empty()) {
                inputFilePath = option;
                if (inputFilePath.back() == '/' || inputFilePath.back() == '\\') {
                    inputFilePath.pop_back();
                }
            }
            else if (output && outputFilePath.empty()) {
                outputFilePath = option;
                if (outputFilePath.back() == '/' || outputFilePath.back() == '\\') {
                    outputFilePath.pop_back();
                }
            }
        }
        else {  // 输入
            fileName = option;
            if (fileName.back() == '/' || fileName.back() == '\\') {
                fileName.pop_back();
            }
        }
    }
    
    state_t state = fileSystem.displayFiles(currentIndex, _l, pipe, fileName, screen);
    if (state != OK) {
        return state;
    }

    // 重定向输出
    if (output) {
        auto [outputState, outputFileIndex, _outputFilePath] = fileSystem.redirectToOutputFile(outputFilePath, userName, currentIndex, currentPath);
        if (outputState != OK) {
            state = outputState;
        }
    }
    
    return state;
}

// 执行 cd 命令, 返回错误代码
// 格式: cd [directory] (.. 的判断有误)
// 输入: [filePath]
// 输出: 无
state_t _cd(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 cd 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string filePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else {  // 输入
            filePath = option;
            if (filePath.back() == '\\') {
                filePath.pop_back();
            }
        }
    }

    auto [state, tmpCurrentIndex, tmpCurrentPath] = fileSystem.getFileByPath(filePath, currentIndex, currentPath);
    if (state == 0) {
        currentIndex = tmpCurrentIndex;
        currentPath = tmpCurrentPath;
    }
    return state;
}

// 执行 echo 命令, 返回错误代码
// 格式: echo message
// 输入: 信息
// 输出: 信息
state_t _echo(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 echo 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::ofstream outputFile("HyFileSystem/tmp/tmpFile", std::ios_base::trunc);  // 覆盖模式打开
    if (!outputFile.is_open()) {
        return CANNOT_OPEN_TEMPORARY_FILE;
    }

    outputFile << splitResult[1] << std::endl;

    outputFile.close();

    if (screen) {
        displayToScreen("HyFileSystem/tmp/tmpFile");
    }

    return OK;
}

// 执行 touch 命令, 返回错误代码
// 格式: touch fileName
// 输入: 文件名
// 输出: 无
state_t _touch(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 touch 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string filePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else {  // 输入
            filePath = option;
            if (filePath.back() == '/' || filePath.back() == '\\') {
                filePath.pop_back();
            }
        }
    }

    // 建立目录路径
    size_t pos = filePath.rfind('\\');
    std::string prePath = filePath.substr(0, pos);  // filePath 前的所有目录
    auto [state, preIndex, _prePath] = fileSystem.buildPath(prePath, userName, currentIndex, currentPath);
    
    std::string fileName = filePath.substr(pos + 1);
    if (fileSystem.isFileNameExists(preIndex, fileName)) {  // 重名
        return DUPLICATE_FILE_NAME;
    }
    else {  // 创建文件
        fileSystem.createFile(preIndex, fileName, userName);
    }
    
    return OK;
}

// 执行 mkdir 命令, 返回错误代码
// 格式: mkdir directoryName
// 输入: 文件名
// 输出: 无
state_t _mkdir(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 mkdir 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string filePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else {  // 输入
            filePath = option;
            if (filePath.back() == '/' || filePath.back() == '\\') {
                filePath.pop_back();
            }
        }
    }

    // 建立目录路径
    size_t pos = filePath.rfind('\\');
    std::string prePath = filePath.substr(0, pos);  // filePath 前的所有目录
    auto [state, preIndex, _prePath] = fileSystem.buildPath(prePath, userName, currentIndex, currentPath);
    
    std::string fileName = filePath.substr(pos + 1);
    if (fileSystem.isFileNameExists(preIndex, fileName)) {  // 重名
        return DUPLICATE_FILE_NAME;
    }
    else {  // 创建目录
        fileSystem.createFile(preIndex, fileName, userName, true);
    }
    
    return OK;
}

// 执行 cp 命令, 返回错误代码
// 格式: cp destinationPath sourcePath
// 输入: destinationPath sourcePath
// 输出: 无
state_t _cp(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 mkdir 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string destinationPath = "";
    std::string sourcePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else {  // 输入
            if (destinationPath.empty()) {  // 目的路径
                destinationPath = option;
            }
            else {  // 源路径
                sourcePath = option;
            }
        }
    }

    return fileSystem.copyFiles(sourcePath, destinationPath, userName, currentIndex, currentPath);
}

// 执行 rm 命令, 返回错误代码
// 格式: rm filePath
// 输入: filePath
// 输出: 无
state_t _rm(std::vector<std::string> splitResult, bool pipe, bool screen) {
    
    return OK;
}

// 执行 move 命令, 返回错误代码
// 格式: move destinationPath sourcePath
// 输入: destinationPath sourcePath
// 输出: 无
state_t _move(std::vector<std::string> splitResult, bool pipe, bool screen) {

    return OK;
}

// 执行 cat 命令, 返回错误代码
// 格式: cat filePath
// 输入: filePath
// 输出: 文件内容
state_t _cat(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 cat 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string filePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else {  // 输入
            filePath = option;
            if (filePath.back() == '\\') {
                filePath.pop_back();
            }
        }
    }

    auto [state1, fileIndex, _filePath] = fileSystem.getFileByPath(filePath, currentIndex, currentPath);
    if (state1 != OK) {
        return SOURCE_NOT_EXISTS;
    }

    auto [state2, lines] = fileSystem.readFile(fileIndex);
    if (state2 != OK) {
        return state2;
    }

    std::ofstream outputFile("HyFileSystem/tmp/tmpFile", std::ios_base::trunc);  // 覆盖模式打开
    if (!outputFile.is_open()) {
        return CANNOT_OPEN_TEMPORARY_FILE;
    }

    for (auto& line : lines) {
        outputFile << line << std::endl;
    }

    outputFile.close();

    if (screen) {
        displayToScreen("HyFileSystem/tmp/tmpFile");
    }

    return OK;
}

// 执行 more 命令, 返回错误代码
// 格式: more [-number] filePath
// 输入: [-number] filePath
// 输出: 文件内容, 1 次显示 number 行
state_t _more(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 cat 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string filePath = "";
    bool haveOption = false;
    size_t number = 0;
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            std::string numberString = option.substr(1);
            if (!isStringNumber(numberString)) {
                return ILLEGAL_FORMAT;
            }
            else {
                number = atoi(numberString.c_str());
            }
        }
        else {  // 输入
            filePath = option;
            if (filePath.back() == '\\') {
                filePath.pop_back();
            }
        }
    }

    auto [state1, fileIndex, _filePath] = fileSystem.getFileByPath(filePath, currentIndex, currentPath);
    if (state1 != OK) {
        return SOURCE_NOT_EXISTS;
    }

    auto [state2, lines] = fileSystem.readFile(fileIndex);
    if (state2 != OK) {
        return state2;
    }

    std::ofstream outputFile("HyFileSystem/tmp/tmpFile", std::ios_base::trunc);  // 覆盖模式打开
    if (!outputFile.is_open()) {
        return CANNOT_OPEN_TEMPORARY_FILE;
    }

    for (unsigned int i = 0; i < std::min(number, lines.size()); i++) {
        outputFile << lines[i] << std::endl;
    }

    outputFile.close();

    if (screen) {
        displayToScreen("HyFileSystem/tmp/tmpFile");
    }

    return OK;
}

// 执行 grep 命令, 返回错误代码
// 格式: grep targetText filePath
// 输入: targetText filePath
// 输出: 文件包含 targetText 的行
state_t _grep(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 grep 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string targetText = "";
    std::string filePath = "";
    bool input = false;
    bool output = false;
    std::string inputFilePath = "";
    std::string outputFilePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else if (option == "<") {
            input = true;
        }
        else if (option == ">") {
            output = true;
            screen = false;  // 有输出重定向时关闭屏显
        }
        else if ((input && inputFilePath.empty()) || (output && outputFilePath.empty())) {  // 重定向
            if (input && inputFilePath.empty()) {
                inputFilePath = option;
                if (inputFilePath.back() == '/' || inputFilePath.back() == '\\') {
                    inputFilePath.pop_back();
                }
            }
            else if (output && outputFilePath.empty()) {
                outputFilePath = option;
                if (outputFilePath.back() == '/' || outputFilePath.back() == '\\') {
                    outputFilePath.pop_back();
                }
            }
        }
        else {  // 输入
            if (targetText.empty()) {
                targetText = option;
            }
            else {
                filePath = option;
                if (filePath.back() == '\\') {
                    filePath.pop_back();
                }
            }
        }
    }

    auto [state1, fileIndex, _filePath] = fileSystem.getFileByPath(filePath, currentIndex, currentPath);
    if (state1 != OK) {
        return SOURCE_NOT_EXISTS;
    }

    auto [state2, lines] = fileSystem.readFile(fileIndex);
    if (state2 != OK) {
        return state2;
    }

    std::ofstream outputFile("HyFileSystem/tmp/tmpFile", std::ios_base::trunc);  // 覆盖模式打开
    if (!outputFile.is_open()) {
        return CANNOT_OPEN_TEMPORARY_FILE;
    }

    for (auto& line : lines) {
        if (line.find(targetText) != std::string::npos) {
            outputFile << line << std::endl;
        }
    }

    outputFile.close();

    if (screen) {
        displayToScreen("HyFileSystem/tmp/tmpFile");
    }

    state_t state = OK;

    // 重定向输出
    if (output) {
        auto [outputState, outputFileIndex, _outputFilePath] = fileSystem.redirectToOutputFile(outputFilePath, userName, currentIndex, currentPath);
        if (outputState != OK) {
            state = outputState;
        }
    }

    return state;
}

// 执行 g++ 命令(运行可执行程序), 返回错误代码
// 格式: g++ -o destinationPath sourcePath (system() 运行结果和直接运行结果不同)
// 输入: -o destinationPath sourcePath
// 输出: 无
state_t _gpp(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 g++ 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    bool _o = false;
    std::string destinationPath = "";
    std::string sourcePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            if (option != "-o") {
                return ILLEGAL_FORMAT;
            }
            else {
                _o = true;
            }
        }
        else {  // 输入
            if (destinationPath.empty()) {
                destinationPath = option;
                if (destinationPath.back() == '\\') {
                    destinationPath.pop_back();
                }
            }
            else {
                sourcePath = option;
                if (sourcePath.back() == '\\') {
                    sourcePath.pop_back();
                }
            }
        }
    }

    auto [state1, fileIndex, filePath] = fileSystem.getFileByPath(sourcePath, currentIndex, currentPath);
    if (state1 != OK) {
        return SOURCE_NOT_EXISTS;
    }

    auto [sourceState, _sourcePath] = fileSystem.completeFilePath(sourcePath, currentIndex, currentPath);
    auto [destinationState, _destinationPath] = fileSystem.completeFilePath(destinationPath, currentIndex, currentPath);
    if (sourceState != OK || destinationState != OK) {
        return ILLEGAL_PATH;
    }
    else {
        sourcePath = _sourcePath;
        destinationPath = _destinationPath;
    }

    std::string trueSourcePath = fileSystem.getTruePath(sourcePath);
    std::string trueDestinationPath = fileSystem.getTruePath(destinationPath);
    system(("g++ .\\" + trueSourcePath + " -o .\\" + trueDestinationPath).c_str());

    size_t pos = destinationPath.rfind('\\');
    std::string fileName = destinationPath.substr(pos + 1);
    std::string prePath = destinationPath.substr(0, (int)destinationPath.length() - (int)fileName.length() - 1);
    auto [state2, preIndex, _prePath] = fileSystem.getFileByPath(prePath, currentIndex, currentPath);
    fileSystem.createFile(preIndex, fileName, userName);
    return OK;
}

// 执行 run 命令(运行可执行程序), 返回错误代码
// 格式: run filePath
// 输入: filePath
// 输出: 无
state_t _run(std::vector<std::string> splitResult, bool pipe, bool screen) {
    // 默认 run 的输入只有 1 行
    if (pipe) {
        auto lines = getLinesOfFile("HyFileSystem/tmp/tmpFile");
        splitResult.push_back(lines[0]);
    }

    std::string filePath = "";
    std::string fileName = "";
    bool input = false;
    bool output = false;
    std::string inputFilePath = "";
    std::string outputFilePath = "";
    for (unsigned int i = 1; i < splitResult.size(); i++) {
        auto option = splitResult[i];
        if (option[0] == '-') {  // 选项
            return ILLEGAL_FORMAT;
        }
        else if (option == "<") {
            input = true;
        }
        else if (option == ">") {
            output = true;
            screen = false;  // 有输出重定向时关闭屏显
        }
        else if ((input && inputFilePath.empty()) || (output && outputFilePath.empty())) {  // 重定向
            if (input && inputFilePath.empty()) {
                inputFilePath = option;
                if (inputFilePath.back() == '/' || inputFilePath.back() == '\\') {
                    inputFilePath.pop_back();
                }
            }
            else if (output && outputFilePath.empty()) {
                outputFilePath = option;
                if (outputFilePath.back() == '/' || outputFilePath.back() == '\\') {
                    outputFilePath.pop_back();
                }
            }
        }
        else {  // 输入
            filePath = option;
            if (filePath.back() == '\\') {
                filePath.pop_back();
            }
        }
    }

    auto [state1, _filePath] = fileSystem.completeFilePath(filePath, currentIndex, currentPath);
    if (state1 != OK) {
        return ILLEGAL_PATH;
    }
    else {
        filePath = _filePath;
    }

    auto [state2, fileIndex, __filePath] = fileSystem.getFileByPath(filePath, currentIndex, currentPath);
    if (state2 != OK) {
        return SOURCE_NOT_EXISTS;
    }

    std::string trueFilePath = fileSystem.getTruePath(filePath);
    if (!input) {
        system((".\\" + trueFilePath + " > .\\" + fileSystem.getTruePath("tmp\\tmpFile")).c_str());
    }
    else {
        auto [inputState, _inputFilePath] = fileSystem.completeFilePath(inputFilePath, currentIndex, currentPath);
        if (inputState != OK) {
            return inputState;
        }
        else {
            inputFilePath = _inputFilePath;
        }

        auto [state3, inputFileIndex, __inputFilePath] = fileSystem.getFileByPath(inputFilePath, currentIndex, currentPath);
        if (state3 != OK) {
            return SOURCE_NOT_EXISTS;
        }
        
        // std::string cmd = ".\\" + trueFilePath + " < .\\" + fileSystem.getTruePath(inputFilePath) + " > .\\" + fileSystem.getTruePath("tmp\\tmpFile");
        // std::cerr << cmd << std::endl;
        system((".\\" + trueFilePath + " < .\\" + fileSystem.getTruePath(inputFilePath) + " > .\\" + fileSystem.getTruePath("tmp\\tmpFile")).c_str());
    }

    // 屏显
    if (screen) {
        displayToScreen("HyFileSystem/tmp/tmpFile");
    }

    state_t state = OK;
    // 重定向输出
    if (output) {
        auto [outputState, outputFileIndex, _outputFilePath] = fileSystem.redirectToOutputFile(outputFilePath, userName, currentIndex, currentPath);
        if (outputState != OK) {
            state = outputState;
        }
    }

    return state;
}
