#include "Headers.h"

bool isFileExists(std::string filePath) {
    std::ifstream fileStream(filePath);
    return fileStream.good();
}

bool isDirectoryExists(std::string directoryPath) {
    return _access(directoryPath.c_str(), 0) != -1;
}

bool getFiles(std::string path, std::vector<std::string>& files, std::vector<std::string>& directories) {
    if (!isDirectoryExists(path)) {
        return false;
    }

    DIR* dir;
    if (!(dir = opendir(path.c_str()))) {
        std::cerr << "Directory \"" << path << "\" opend failed" << std::endl;
        return false;
    }

    dirent* ptr;
    while ((ptr = readdir(dir)) != NULL) {
        // 当前目录、上级目录
        if (strcmp(ptr->d_name, ".") == 0 || strcmp(ptr->d_name, "..") == 0) {
            continue;
        }
        
        if (ptr->d_type == DT_DIR) {  // 目录
            directories.push_back(ptr->d_name);
        }
        else {  // 文件
            files.push_back(ptr->d_name);
        }
    }
    closedir(dir);
    return true;
}

size_t getFileSize(std::string filePath) {
    HANDLE fileHandle = CreateFile(filePath.c_str(), 0, 0, 0, OPEN_EXISTING, 0, 0);
    DWORD fileSize = GetFileSize(fileHandle, 0);
    return fileSize;
}

std::vector<std::string> split(std::string line, char delimiter) {
    if (line.back() == delimiter) {
        line.pop_back();
    }

    std::vector<std::string> res = { "" };
    for (auto ch : line) {
        if (ch == delimiter) {
            res.push_back("");
        }
        else {
            res.back().push_back(ch);
        }
    }
    return res;
}

std::vector<std::string> getLinesOfFile(std::string filePath) {
    std::vector<std::string> lines;
    std::ifstream inputFile(filePath);
    if (inputFile.is_open()) {
        std::string line;
        while (std::getline(inputFile, line)) {
            lines.push_back(line);
        }
        
        inputFile.close();
    }
    return lines;
}

void displayToScreen(std::string filePath) {
    auto lines = getLinesOfFile(filePath);
    for (auto line : lines) {
        std::cout << line << std::endl;
    }
}

std::string stringToLower(std::string str) {
    for (auto& ch : str) {
        if (isalpha(ch)) {
            ch = tolower(ch);
        }
    }
    return str;
}

bool isStringNumber(std::string str) {
    bool neg = false;
    for (auto ch : str) {
        if (ch == '-') {
            if (neg) {
                return false;
            }
            else {
                neg = true;
            }
        }
        else if (!isdigit(ch)) {
            return false;
        }
    }
    return true;
}
