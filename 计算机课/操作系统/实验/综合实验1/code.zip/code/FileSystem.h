#ifndef __FILESYSTEM_H__
#define __FILESYSTEM_H__

#include "Headers.h"
#include "File.h"

class FileSystem {
private:
    std::string initialPath;
    index_t currentIndex;
    std::vector<File> fileList;
    std::vector<std::vector<index_t>> fileTree;
    index_t rootIndex;
    std::string rootName;

public:
    FileSystem(std::string fileSystemName);

    ~FileSystem();

    void setCurrentIndex(index_t currentIndex);

    index_t getCurrentIndex();

    void setRootIndex(index_t _rootIndex);

    index_t getRootIndex();

    void setRootName(std::string rootName);

    std::string getRootName();

    index_t getNewIndex();

    // 若当前的 index 超出容量, 则扩容为两倍, 返回是否扩容
    bool expandCapacity(index_t index);

    // 用目录下的 rootName 文件夹和 tmp 文件夹构建文件系统
    bool initialize(std::string rootPath);

    // 获取真实路径
    std::string getTruePath(std::string path);

    void displayFileTree();

    // 获取编号为 index 的目录的大小
    size_t getSizeOfDirectory(index_t index);

    // 列出编号为 index 的目录的目录名和文件名
    state_t displayFiles(index_t index, bool _l = false, bool _grep = false, std::string fileName = "", bool screen = true);

    // 获取编号为 index 的文件的父文件
    state_t getFatherIndex(index_t index);

    // 获取编号为 index 的文件的文件名
    std::string getFileName(index_t index);

    // 判断编号为 index 的目录下有无名称为 fileName 的目录或文件 (不区分大小写)
    // 若有, 返回该目录或文件的编号; 否则返回 0
    index_t isFileNameExists(index_t index, std::string fileName);

    // 获取路径为 filePath 的文件, 返回 { 状态, 编号, 当前路径 }
    // 若不存在, 则返回能走到的最远的文件
    std::tuple<state_t, index_t, std::string> getFileByPath(std::string filePath, index_t currentIndex, std::string currentPath);

    // 获取编号为 index 的文件的路径
    std::string getFilePath(index_t index);

    // 在当前目录下创建目录或文件, 返回目录或文件的编号
    index_t createFile(index_t index, std::string fileName, std::string fileOwner, bool isDirectory = false);

    // 沿目录路径行进, 不存在则建出目录路径, 返回路径终点的编号
    std::tuple<state_t, index_t, std::string> buildPath(std::string filePath, std::string fileOwner, index_t currentIndex, std::string currentPath);

    // 将编号为 sourceIndex 的文件复制到当前目录下, 返回 { 状态, 文件的编号 }
    std::pair<state_t, index_t> copyFile(index_t destinationIndex, index_t sourceIndex, std::string fileOwner);

    // 复制 sourcePath 的文件到 destinationPath (递归复制)
    state_t copyFiles(std::string sourcePath, std::string destinationPath, std::string fileOwner, index_t currentIndex, std::string currentPath);

    // 读文件内容, 返回 { 状态, 文件内容 }
    std::pair<state_t, std::vector<std::string>> readFile(index_t fileIndex);

    // 写文件内容, 返回状态
    state_t writeFile(index_t fileIndex, std::vector<std::string> lines);

    // 将相对路径补充为绝对路径, 返回 { 状态, 绝对路径 }
    std::pair<state_t, std::string> completeFilePath(std::string filePath, index_t currentIndex, std::string currentPath);

    // 将 tmp/tmpFile 中的内容重定向到输出文件, 返回 { 状态, 输出文件编号, 输出文件路径 }
    std::tuple<state_t, index_t, std::string> redirectToOutputFile(std::string filePath, std::string fileOwner, index_t currentIndex, std::string currentPath);
};

#endif