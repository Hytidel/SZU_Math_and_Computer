#ifndef __FILE_H__
#define __FILE_H__

#include "Headers.h"

using index_t = unsigned int;

class File {
private:
    index_t fileIndex;
    std::string fileName;
    size_t fileSize;  // 目录的 fileSize 设为 0 , 需要时再计算
    std::string fileOwner;
    bool isDirectory;
    index_t fatherFileIndex;

public:
    File();

    File(index_t _fileIndex, std::string _fileName, std::string _fileOwner, bool _isDirectory, index_t _fatherFileIndex);

    ~File();

    void setFileIndex(index_t _fileIndex);

    index_t getFileIndex();

    void setFileName(std::string _fileName);

    std::string getFileName();

    void setFileSize(size_t _fileSize);

    size_t getFileSize();

    void setFileOwner(std::string _fileOwner);

    std::string getFileOwner();

    void setIsDirectory(bool _isDirectory);

    bool getIsDirectory();

    void setFatherFileIndex(index_t _fatherFileIndex);

    index_t getFatherFileIndex();

    friend bool operator<(File A, File B);

    friend bool operator==(File A, File B);
};

#endif