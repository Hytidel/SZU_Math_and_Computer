#ifndef __HEADERS_H__
#define __HEADERS_H__

#include <windows.h>
#include <io.h>
#include "dirent.h"

#include <iostream>
#include <cstring>
#include <algorithm>
#include <cassert>
#include <fstream>
#include <vector>
#include <unordered_set>

// 错误代码
using state_t = unsigned int;
const state_t OK = 0;
const state_t CANNOT_OPEN_TEMPORARY_FILE = 1;
const state_t ILLEGAL_COMMAND = 2;
const state_t ILLEGAL_FORMAT = 3;
const state_t DIRECTORY_CHANGED_FAILED = 4;
const state_t DUPLICATE_FILE_NAME = 5;
const state_t SOURCE_NOT_EXISTS = 6;
const state_t PATH_BUILT_FAILED = 7;
const state_t DIRECTORY_CANNOT_BE_READ = 8;
const state_t CANNOT_OPEN_SOURCE_FILE = 9;
const state_t ILLEGAL_PATH = 10;

bool isFileExists(std::string filePath);

bool isDirectoryExists(std::string directoryPath);

// 获得目录下的所有文件、目录, 返回目录是否存在
bool getFiles(std::string path, std::vector<std::string>& files, std::vector<std::string>& directories);

size_t getFileSize(std::string filePath);

// 将字符串按分隔符分隔
std::vector<std::string> split(std::string line, char delimiter = ' ');

// 获得 tmp/tmpFile 的行
std::vector<std::string> getLinesOfFile(std::string filePath);

// 将文件中的内容显示到屏幕上
void displayToScreen(std::string filePath);

// 将字符串中的英文字母转化为小写
std::string stringToLower(std::string str);

// 判断字符串是否是数字
bool isStringNumber(std::string str);

#endif