#include <bits/stdc++.h>
using namespace std;

void solve() {
    cout << "Hello World." << endl;
    cout << "dwe4 4wet wmjdd" << endl;
    cout << "fko3w eiew0 3ew" << endl;
    cout << "89sd9f ww0 wsd" << endl;
}

int main() {
    cin.tie(0)->sync_with_stdio(false);
    // int t; cin >> t; while (t--)
    solve();
    return 0;
}