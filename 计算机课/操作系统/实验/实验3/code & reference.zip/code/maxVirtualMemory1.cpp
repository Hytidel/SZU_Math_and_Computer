#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

using uint = unsigned int;
const uint MB = 1024 * 1024;
const uint Sigma = 128;
const uint MAXN = 15;

char* myMalloc(uint memSize) {
	char* buffer = (char*)malloc(memSize);

	// 写
	for (uint i = 0; i < memSize; i++) {
		buffer[i] = i % Sigma;
	}

	printf("Allocated %d MB of Mememory: %p - %p\n", memSize / MB, buffer, buffer + memSize - 1);
	
	return buffer;
}

int main() {
	uint memSize = 256 * MB;
	uint cnt = 0;
	while (1) {
		printf("[%d] ", ++cnt);
		
		char* buffer = myMalloc(memSize);
		if (!buffer) {  // 申请失败
			break;
		}
	}
	
	return 0;
}
