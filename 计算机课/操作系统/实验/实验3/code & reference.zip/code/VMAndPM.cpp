#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

using uint = unsigned int;
const uint KB = 1024;
const uint MB = 1024 * 1024;
const uint Sigma = 128;
const uint MAXN = 15;

char* myMalloc(uint memSize) {
	char* buffer = (char*)malloc(memSize);

	// 写
	/*for (uint i = 0; i < memSize; i++) {
		buffer[i] = i % Sigma;
	}*/

	printf("Allocated %d MB of Mememory: %p - %p\n", memSize / MB, buffer, buffer + memSize - 1);
	
	return buffer;
}

int main() {
	getchar();

	// 申请 256 MB 的内存
	uint memSize = 256 * MB;
	char* buffer = myMalloc(memSize);
	
	printf("Allocation completed.\n");
	getchar();

	// 每隔 4 kB 读一次
	for (uint i = 0; i < memSize; i += 4 * KB) {
		uint tmp = buffer[i];
	}

	printf("Reading completed.\n");
	getchar();

	// 每隔 4 kB 写一次
	for (uint i = 0; i < memSize; i += 4 * KB) {
		buffer[i] = i % Sigma;
	}

	printf("Writing completed.\n");
	getchar();
	
	return 0;
}
