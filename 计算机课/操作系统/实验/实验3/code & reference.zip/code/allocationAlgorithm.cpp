#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

using uint = unsigned int;
const uint MB = 1024 * 1024;
const uint Sigma = 128;
const uint MAXN = 15;

char* myMalloc(uint memSize) {
	char* buffer = (char*)malloc(memSize);

	// 写
	for (uint i = 0; i < memSize; i++) {
		buffer[i] = i % Sigma;
	}

	printf("Allocated %d MB of Mememory: %p - %p\n", memSize / MB, buffer, buffer + memSize - 1);
	
	return buffer;
}

int main() {	
	// 连续申请 6 个 128 MB 的空间
	char* buffers[MAXN];
	buffers[1] = myMalloc(128 * MB);
	buffers[2] = myMalloc(128 * MB);
	buffers[3] = myMalloc(128 * MB);
	buffers[4] = myMalloc(65 * MB);
	buffers[5] = myMalloc(128 * MB);
	buffers[6] = myMalloc(128 * MB);

	// 释放第 2 、4 号
	free(buffers[2]);
	free(buffers[4]);

	// 申请 64 MB 的空间
	buffers[7] = myMalloc(64 * MB);

	return 0;
}
