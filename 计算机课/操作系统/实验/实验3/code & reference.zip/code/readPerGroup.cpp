#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

using uint = unsigned int;
const uint KB = 1024;
const uint MB = 1024 * 1024;
const uint PAGE = 4 * KB;
const uint Sigma = 128;
const uint MAXN = 15;
const uint ROUND = 10;

char* myMalloc(uint memSize) {
	char* buffer = (char*)malloc(memSize);

	// 写
	/*for (uint i = 0; i < memSize; i++) {
		buffer[i] = i % Sigma;
	}*/

	printf("Allocated %d MB of Mememory: %p - %p\n", memSize / MB, buffer, buffer + memSize - 1);
	
	return buffer;
}

int main() {
	// 申请 3000 MB 的内存
	uint memSize = 3000 * MB;
	char* buffer = myMalloc(memSize);
	
	printf("Allocation completed.\n");

	uint pageCount = (memSize + PAGE - 1) / PAGE;
	uint groupCount = (pageCount + 16 - 1) / 16;

	clock_t my_clock = clock();

	for (uint group = 0; group < groupCount; group++) {  // 枚举组
		for (uint page = 0; page < 16; page++) {  // 枚举页
			uint truePage = group * 16 + page;
			uint base = truePage * PAGE;

			for (uint round = 0; round < ROUND; round++) {
				// 每隔 4 kB 将字节值 + 1
				for (uint i = 0; i < PAGE; i += 4 * KB) {
					buffer[base + i] = i % Sigma;
				}
			}
		}
	}
	
	uint timeCost = clock() - my_clock;
	printf("Writing completed.\n");
	printf("Time cost %d ms.\n", timeCost);
	
	return 0;
}
