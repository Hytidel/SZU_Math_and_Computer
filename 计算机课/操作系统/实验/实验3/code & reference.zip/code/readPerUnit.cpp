#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

using uint = unsigned int;
const uint KB = 1024;
const uint MB = 1024 * 1024;
const uint Sigma = 128;
const uint MAXN = 15;
const uint ROUND = 10;

char* myMalloc(uint memSize) {
	char* buffer = (char*)malloc(memSize);

	// 写
	/*for (uint i = 0; i < memSize; i++) {
		buffer[i] = i % Sigma;
	}*/

	printf("Allocated %d MB of Mememory: %p - %p\n", memSize / MB, buffer, buffer + memSize - 1);
	
	return buffer;
}

int main() {
	// 申请 3000 MB 的内存
	uint memSize = 3000 * MB;
	char* buffer = myMalloc(memSize);
	
	printf("Allocation completed.\n");

	clock_t my_clock = clock();

	for (uint round = 0; round < ROUND; round++) {
		// 每隔 4 kB 写一次
		for (uint i = 0; i < memSize; i += 4 * KB) {
			buffer[i] = i % Sigma;
		}
	}
	
	uint timeCost = clock() - my_clock;
	printf("Writing completed.\n");
	printf("Time cost %d ms.\n", timeCost);
	
	return 0;
}
