#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

using uint = unsigned int;
const uint MB = 1024 * 1024;
const uint Sigma = 128;
const uint MAXN = 15;

char* myMalloc(uint memSize) {
	char* buffer = (char*)malloc(memSize);

	// 写
	for (uint i = 0; i < memSize; i++) {
		buffer[i] = i % Sigma;
	}

	printf("Allocated %d MB of Mememory: %p - %p\n", memSize / MB, buffer, buffer + memSize - 1);
	
	return buffer;
}

int main() {
	getchar();  // 阻塞
	
	// 连续申请 6 个 128 MB 的空间
	char* buffers[MAXN];
	for (uint i = 1; i <= 6; i++) {
		buffers[i] = myMalloc(128 * MB);
	}

	getchar();  // 阻塞

	// 释放第 2 、3 、5 号
	free(buffers[2]);
	free(buffers[3]);
	free(buffers[5]);

	getchar();  // 阻塞

	// 申请 1024 MB 的空间
	buffers[7] = myMalloc(1024 * MB);

	getchar();  // 阻塞

	// 申请 64 MB 的空间
	buffers[8] = myMalloc(64 * MB);

	getchar();  // 阻塞

	return 0;
}
