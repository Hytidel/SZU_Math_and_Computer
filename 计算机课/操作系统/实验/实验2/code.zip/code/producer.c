#include "SharedMemory.h"

char line[BUFFER_SIZE];

int main() {
	// 创建或打开共享内存文件
	int shm_fd = shm_open("exp2", O_CREAT | O_RDWR, 0666);  // 创建、所有人可读可写
	if (shm_fd < 0) {
		printf("Failed to create shared memory.\n");
		exit(-1);
	}

	printf("Successfully created shared memory: %d\n", shm_fd);

	// 修改共享内存文件大小
	if (ftruncate(shm_fd, sizeof(struct SharedMemory)) == -1) {
		printf("Failed to set the size of the shared memory.\n");
		exit(-1);
	}

	// 将共享内存文件映射到内存
	struct SharedMemory* sm = (struct SharedMemory*)mmap(
		NULL,  // 要将文件映射到的地址, 传 NULL 由 Linux 内核指定
		sizeof(struct SharedMemory),  // 文件长度
		PROT_READ | PROT_WRITE,  // 映射的内存的权限
		MAP_SHARED,  // 建立共享, 用于进程间通信
		shm_fd,  // 文件描述符
		0  // 偏移量
		);
		
	 if (sm == MAP_FAILED) {
	 	printf("Failed to map the shared memory.\n");
	 	exit(-1);
	 }

	 // 初始化三个信号量
	 if (sem_init(&sm->mutex, 1, 1) == -1) {  // mutex = 1
	 	printf("Failed to initialize semaphore mutex.\n");
	 	exit(-1);
	 }
	 if (sem_init(&sm->empty, 1, BUFFER_SIZE) == -1) {  // empty = n
	 	printf("Failed to initialize semaphore empty.\n");
	 	exit(-1);
	 }
	 if (sem_init(&sm->full, 1, 0) == -1) {  // full = 1
	 	printf("Failed to initialize semaphore full.\n");
	 	exit(-1);
	 }

	 while (1) {
	 	printf("[2021192010@Producer ~]$ ");
		// gets(line);  // 忽略缓冲区溢出
		fgets(line, BUFFER_SIZE, stdin);

		// 获取空缓冲区
		sem_wait(&sm->empty);  // P(empty)

		// 进入临界区
		sem_wait(&sm->mutex);  // P(mutex)

		// 将行写入缓冲区
		// strcpy(sm->data, line);  // 忽略缓冲区溢出
		strncpy(sm->data, line, BUFFER_SIZE);

		// 退出临界区
		sem_post(&sm->mutex);  // V(mutex)

		// 满缓冲区数 + 1
		sem_post(&sm->full);  // V(full)

		// 退出
		// if (!strcmp(line, "quit")) {
		if (!strcmp(line, "quit\n")) {
			break;
		}
	 }

	 // 撤销信号量
	 sem_destroy(&sm->mutex);
	 sem_destroy(&sm->empty);
	 sem_destroy(&sm->full);

	 // 解除共享内存文件到内存的映射
	 munmap(sm, sizeof(struct SharedMemory));

	 // 关闭共享内存文件
	 close(shm_fd);

	 // 删除共享内存文件
	 shm_unlink("exp2");

	 return 0;
}
