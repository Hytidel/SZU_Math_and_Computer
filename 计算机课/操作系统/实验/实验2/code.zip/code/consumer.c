#include "SharedMemory.h"

char line[BUFFER_SIZE];

int main() {
	// 创建或打开共享内存文件
	int shm_fd = shm_open("/exp2", O_RDWR, 0666);  // 创建、所有人可读可写
	if (shm_fd == -1) {
		printf("Failed to create shared memory.\n");
		exit(-1);
	}

	// 将共享内存文件映射到内存
	struct SharedMemory* sm = (struct SharedMemory*)mmap(
		NULL,  // 要将文件映射到的地址, 传 NULL 由 Linux 内核指定
		sizeof(struct SharedMemory),  // 文件长度
		PROT_READ | PROT_WRITE,  // 映射的内存的权限
		MAP_SHARED,  // 建立共享, 用于进程间通信
		shm_fd,  // 文件描述符
		0  // 偏移量
		);
	 if (sm == MAP_FAILED) {
	 	printf("Failed to map the shared memory.\n");
	 	exit(-1);
	 }

	 // 创建子进程
	 pid_t pid = fork();
	 if (pid < 0) {
		printf("Failed to fork a child process.\n");
	 	exit(-1);
	 }
	 else if (pid == 0) {  // 子进程
	 	while (1) {
	 		// 获取满缓冲区
	 		sem_wait(&sm->full);  // P(full)

	 		// 进入临界区
	 		sem_wait(&sm->mutex);  // P(mutex)

			// 检查是否为 quit
			bool quit = false;
			if (!strcmp(sm->data, "quit\n")) {
	 			quit = true;
	 		}
			
	 		// 消费缓冲区数据
	 		printf("[2021192010@Consumer_child ~]$ Received data: %s", sm->data);

	 		if (!quit) {
	 			// 清空缓冲区
	 			memset(sm->data, 0, sizeof(sm->data));
	 		}

			// 退出临界区
			sem_post(&sm->mutex);  // V(mutex)

	 		// 退出
	 		if (quit) {
	 			// 满缓冲区数 + 1
				sem_post(&sm->full);  // V(full)
	 			break;
	 		}

	 		// 空缓冲区数 + 1
			sem_post(&sm->empty);  // V(empty)

	 		// 加入延时以便观察
	 		sleep(3);
	 	}
	 }
	 else {  // 父进程
	 	while (1) {
	 		// 获取满缓冲区
	 		sem_wait(&sm->full);  // P(full)

	 		// 进入临界区
	 		sem_wait(&sm->mutex);  // P(mutex)

			// 检查是否为 quit
			bool quit = false;
			if (!strcmp(sm->data, "quit\n")) {
	 			quit = true;
	 		}

	 		// 消费缓冲区数据
	 		printf("[2021192010@Consumer_parent ~]$ Received data: %s", sm->data);

	 		if (!quit) {
	 			// 清空缓冲区
	 			memset(sm->data, 0, sizeof(sm->data));
	 		}

			// 退出临界区
			sem_post(&sm->mutex);  // V(mutex)

	 		// 退出
	 		if (quit) {
	 			// 满缓冲区数 + 1
				sem_post(&sm->full);  // V(full)
	 			break;
	 		}

	 		// 空缓冲区数 + 1
			sem_post(&sm->empty);  // V(empty)
	 	}
	 }

	 // 解除共享内存文件到内存的映射
	 munmap(sm, sizeof(struct SharedMemory));

	 // 关闭共享内存文件
	 close(shm_fd);

	 return 0;
}
