#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/mman.h>


enum {
	BUFFER_SIZE = 100
};

struct SharedMemory {
	char data[BUFFER_SIZE];
	sem_t mutex;  // 互斥信号量
	sem_t empty;  // 空缓冲区数
	sem_t full;  // 满缓冲区数
};
