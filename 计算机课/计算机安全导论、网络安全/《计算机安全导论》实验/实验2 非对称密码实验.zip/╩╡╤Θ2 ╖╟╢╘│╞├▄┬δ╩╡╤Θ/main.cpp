#include<bits/stdc++.h>
#include<random>
using namespace std;
typedef long long ll;
typedef unsigned int uint;
typedef pair<ll, ll> pll;

const int MAXN = 1e7 + 5;
namespace IO {
    char buffer[MAXN];  // 读入文件的缓冲区
    int len;  // 读入文件的实际长度
    char tmpbuffer[MAXN];  // 解密得到的文件
    int tmplen;  // 解密文件的实际长度
    ll cipher[MAXN];  // 读入的密文
    int clen;  // 读入的密文的实际长度

    void inputText() {  // 以二进制读入明文
        ifstream infile("C:\\E\\cpp project\\RSA\\text.txt", ios::in | ios::binary);

        if (!infile) {
            cout << "Open failed." << endl;
            return;
        }

        infile.read((char*)buffer, (MAXN - 1) * sizeof(char));
        len = strlen(buffer);
        infile.close();
    }

    void inputCipher() {  // 以二进制读入密文
        ifstream infile("C:\\E\\cpp project\\RSA\\cipher.txt", ios::in | ios::binary);

        if (!infile) {
            cout << "Open failed." << endl;
            return;
        }

        while (infile >> cipher[clen]) clen++;
        infile.close();
    }
}
using namespace IO;

namespace Math {
    int primes[MAXN], cnt;  // 素数及其个数
    bool state[MAXN];  // 记录每个数是否被筛掉

    void getPrimes() {  // 预处理出1e7以内的素数
        for (int i = 2; i < MAXN; i++) {
            if (!state[i]) primes[cnt++] = i;
            
            for (int j = 0; (ll)primes[j] * i < MAXN; j++) {
                state[primes[j] * i] = true;
                if (i % primes[j] == 0) break;
            }
        }
    }

    ll getPhi(ll p, ll q) {  // 计算两个素数之积的Euler函数
        return (ll)(p - 1) * (q - 1);
    }

    ll gcd(ll a, ll b) {  // 求两数的gcd
        return b ? gcd(b, a % b) : a;
    }

    ll exgcd(ll a, ll b, ll& x, ll& y) {  // 扩展Euclid算法
        if (!b) {
            x = 1, y = 0;
            return a;
        }

        ll d = exgcd(b, a % b, y, x);
        y -= a / b * x;
        return d;
    }

    ll inv(ll a, ll MOD) {  // 求a模MOD的逆元
        ll x, y;
        exgcd(a, MOD, x, y);
        x = (x % MOD + MOD) % MOD;  // 防止出现负数
        return x;
    }

    ll smul(ll a, ll b, ll MOD) {  // 龟速乘求a乘b模MOD
        ll res = 0;
        while (b) {
            if (b & 1) res = (res + a) % MOD;
            a = (a + a) % MOD;
            b >>= 1;
        }
        return res;
    }

    ll qpow(ll a, ll k, ll MOD) {  // 快速幂求a的k次方模MOD
        a %= MOD, k %= MOD;
        ll res = 1;
        while (k) {
            if (k & 1) res = smul(res, a, MOD);
            k >>= 1;
            a = smul(a, a, MOD);
        }
        return res;
    }
}
using namespace Math;

namespace BinaryNumber {  // 二进制数
    ll pow2[65];

    void getPow2() {  // 预处理出2的幂次
        pow2[0] = 1;
        for (int i = 1; i < 65; i++) pow2[i] = pow2[i - 1] * 2;
    }

    ll charToLongLong(char ch[4]) {  // 每四个字符一组编码成一个long long类型的数
        ll res = 0;
        for (int i = 0; i < 4; i++) {
            res += ch[i];
            res *= pow2[8];
        }
        return res;
    }

    char* longLongToChar(ll s) {  // 将一个long long类型的数解码为四个字符
        static char res[4];
        memset(res, 0, sizeof(res));
        for (int i = 4; i >= 0; i--) {
            for (int j = 0; j < 8; j++) res[i] += (s >> j & 1) * pow2[j];
            s /= pow2[8];
        }
        return res;
    }
}
using namespace BinaryNumber;

namespace StringHash {
	int n;  // 字符串长度
	char str[MAXN];  // 下标从1开始
	const ll Base1 = 29, MOD1 = 1e9 + 7;
	const ll Base2 = 131, MOD2 = 1e9 + 9;
	ll ha1[MAXN], ha2[MAXN];  // 正着的哈希值
	ll rha1[MAXN], rha2[MAXN];  // 反着的哈希值
	ll pow1[MAXN], pow2[MAXN];  // Base1和Base2的乘方

	void init() {  // 预处理pow1[]、pow2[]
		pow1[0] = pow2[0] = 1;
		for (int i = 1; i <= n; i++) {
			pow1[i] = pow1[i - 1] * Base1 % MOD1;
			pow2[i] = pow2[i - 1] * Base2 % MOD2;
		}
	}

	void pre() {  // 预处理ha1[]、ha2[]
		for (int i = 1; i <= n; i++) {
			ha1[i] = (ha1[i - 1] * Base1 + str[i]) % MOD1;
			ha2[i] = (ha2[i - 1] * Base2 + str[i]) % MOD2;
			rha1[i] = (rha1[i - 1] * Base1 + str[n - i + 1]) % MOD1;
			rha2[i] = (rha2[i - 1] * Base2 + str[n - i + 1]) % MOD2;
		}
	}

	pll get_hash(int l, int r) {  // 求子串str[l...r]正着的哈希值
		ll res1 = ((ha1[r] - ha1[l - 1] * pow1[r - l + 1]) % MOD1 + MOD1) % MOD1;
		ll res2 = ((ha2[r] - ha2[l - 1] * pow2[r - l + 1]) % MOD2 + MOD2) % MOD2;
		return pll(res1, res2);
	}

	pll get_rhash(int l, int r) {  // 求子串str[l...r]反着的哈希值
		ll res1 = ((rha1[n - l + 1] - rha1[n - r] * pow1[r - l + 1]) % MOD1 + MOD1) % MOD1;
		ll res2 = ((rha2[n - l + 1] - rha2[n - r] * pow2[r - l + 1]) % MOD2 + MOD2) % MOD2;
		return pll(res1, res2);
	}

	bool IsPalindrome(int l, int r) {  // 判断子串str[l...r]是否是回文串
		return get_hash(l, r) == get_rhash(l, r);
	}

	pll add(pll a, pll b) {
		ll res1 = (a.first + b.first) % MOD1;
		ll res2 = (a.second + b.second) % MOD2;
		return pll(res1, res2);
	}

	pll mul(pll& a, ll k) {  // a *= Base的k次方
		ll res1 = a.first * pow1[k] % MOD1;
		ll res2 = a.second * pow2[k] % MOD2;
		return pll(res1, res2);
	}
};
using namespace StringHash;

namespace RSA {
    ll p, q;  // 素数
    ll n;  // 模数n = pq
    ll e;  // 公钥
    ll d;  // 私钥
    ll M[MAXN];  // 明文
    ll C[MAXN];  // 密文
    ll tmpM[MAXN];  // 密文解密得到的明文
    int newlen;  // 加密后的长度
    ll digitalSignature;  // 发送者的数字签名

    void init() {  // 随机生成模数、公钥、私钥
        uint seed = time(0);
        mt19937 rnd(seed);

        int idx1 = 1, idx2 = 1;  // 随机抽取两个素数
        while (abs(idx1 - idx2) <= 1e4) {  // 两素数过于接近
            idx1 = rnd() % (cnt / 2) + cnt / 2;
            idx2 = rnd() % (cnt / 2) + cnt / 2;
        }
        p = primes[idx1], q = primes[idx2];  // 产生大素数
        n = p * q;  // 产生模数
        ll phi = getPhi(p, q);
        
        while (true) {  // 产生公钥
            int idx = rnd() % (cnt / 2) + cnt / 2;
            if (gcd(phi, primes[idx]) == 1) {
                e = primes[idx];
                break;
            }
        }

        d = inv(e, phi);  // 产生私钥
    }

    void show() {  // 展示参数
        cout << "大素数 p = " << p << ", q = " << q << endl;
        cout << "模数 n = " << n << endl;
        cout << "公钥 e = " << e << endl;
        cout << "私钥 d = " << d << endl;
    }

    void encode() {  // 对buffer[]进行分组编码,结果存在M[]中
        for (int i = 0; i < (len + 3) / 4 * 4; i += 4) {  // 对文件分组
            char tmp[4] = { buffer[i],buffer[i + 1],buffer[i + 2],buffer[i + 3] };
            M[newlen++] = charToLongLong(tmp);
        }
    }

    void decode(ll text[]) {  // 将得到的密文解码,结果存在tmpbuffer[]中
        for (int i = 0; i < newlen; i++) {
            auto tmp = longLongToChar(text[i]);
            for (int j = 0; j < 4; j++) tmpbuffer[tmplen++] = tmp[j];
        }
    }

    ll getStringHash(char* buf) {
        strcpy(str + 1, buf);  // 拷贝到字符串哈希的数组中
        StringHash::n = strlen(str + 1);
        pre();  // 处理出字符串的哈希值
        pll sign = get_hash(1, StringHash::n);
        return sign.first;
    }

    ll getDigitalSignature(char* buf, ll key) {  // 生成/验证数字签名
        return digitalSignature = qpow(getStringHash(buf), key, n);  // 用key加密/解密
    }

    void encrypt() {  // 加密,结果存在C[]中
        inputText();  // 读入明文文件
        encode();  // 编码
        cout << "发送者的数字签名: " << getDigitalSignature(buffer, d) << endl;
        
        // 加密
        for (int i = 0; i < newlen; i++) C[i] = qpow(M[i], e, n);

        // cout << "编码:" << endl;
        // for (int i = 0; i < newlen; i++) cout << M[i] << endl;
        // cout << endl;
        // cout << "加密:" << endl;
        // for (int i = 0; i < newlen; i++) cout << C[i] << endl;
        // cout << endl;

        // 加密结果保存在cipher.txt中
        ofstream outfile("C:\\E\\cpp project\\RSA\\cipher.txt", ios::out | ios::binary);
        for (int i = 0; i < newlen; i++) outfile << C[i] << endl;
        outfile.close();
    }

    void decrypt() {  // 解密,结果存在tmpM[]中
        inputCipher();  // 读入密文文件

        for (int i = 0; i < newlen; i++) tmpM[i] = qpow(cipher[i], d, n);

        // cout << "解密:" << endl;
        // for (int i = 0; i < newlen; i++) cout << tmpM[i] << endl;
        // cout << endl;

        // 解密结果保存在clear.txt中
        decode(tmpM);
        ofstream outfile("C:\\E\\cpp project\\RSA\\clear.txt", ios::out | ios::binary);
        outfile << tmpbuffer;
        outfile.close();

        // 验证数字签名
        cout << "解密得到的明文的哈希值: " << getStringHash(tmpbuffer) << endl;
        cout << "验证数字签名: " << qpow(digitalSignature, e, n) << endl;  // 用公钥解密
    }
}
using namespace RSA;

int main() {
    getPrimes();  // 预处理素数
    getPow2();  // 预处理2的幂次
    StringHash::init();  // 预处理字符串哈希所需的数组
    RSA::init();  // RSA初始化
    show();  // 展示RSA参数

    encrypt();  // 加密text.txt
    decrypt();  // 解密cipher.txt

    return 0;
}