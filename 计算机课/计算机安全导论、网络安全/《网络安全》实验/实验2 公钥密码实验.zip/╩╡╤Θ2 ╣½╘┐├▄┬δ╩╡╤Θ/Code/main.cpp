#include <bits/stdc++.h>
#include "rsa.h"
using namespace std;

void solve() {
    rsa_init();
    n = 2;
    cout << qpow(n, 5, 10) << endl;
}

int main() {
    solve();
    return 0;
}