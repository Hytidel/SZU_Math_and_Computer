#include <bits/stdc++.h>
using namespace std;

struct Math;

extern int p, q;  // 大素数
extern int n;  // 模数
extern int phi;  // Euler函数
extern int e, d;  // 公钥、私钥

void show();

void rsa_init();

int qpow(int a, int k, int MOD);

