#include <stdint.h>  // 定义了unsigned char的别名uint8_t
#include <stdlib.h>  // free()函数

#define gmul(a, b) gmul_table[256 * a + b]  // G(2^8)中的乘法用查表实现

uint8_t* aes_init(size_t key_size);  // 初始化AES的参数和分配空间

void aes_key_expansion(uint8_t* key, uint8_t* w);  // 密钥扩展

void aes_encryption(uint8_t* in, uint8_t* out, uint8_t* w);  // 加密

void aes_decryption(uint8_t* in, uint8_t* out, uint8_t* w);  // 解密
