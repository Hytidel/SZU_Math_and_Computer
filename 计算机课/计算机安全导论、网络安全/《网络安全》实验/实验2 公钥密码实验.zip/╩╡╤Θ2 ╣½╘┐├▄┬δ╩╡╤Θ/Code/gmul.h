#ifndef __GMULT_H__

#define __GMULT_H__

#include <stdint.h>  // 定义了unsigned char的别名uint8_t

extern uint8_t gmul_table[];  // GF(2^8)中的乘法表, 既约多项式m(x) = x^8 + x^4 + x^3 + x + 1

#endif