#include <bits/stdc++.h>
#include "rsa.h"
using namespace std;
typedef long long ll;

struct Math {
    vector<int> primes;
    int cnt;
    vector<bool> state;

    Math(int MAXN) :cnt(0) {  // 预处理MAXN以内的素数
        state.resize(MAXN);

        for (int i = 2; i < MAXN; i++) {
            if (!state[i]) primes.push_back(i);

            for (int j = 0; primes[j] * i < MAXN; j++) {
                state[primes[j] * i] = true;
                if (i % primes[j] == 0) break;
            }
        }
        cnt = primes.size();
    }

    static int phi(int p, int q) {  // 求两素数之积的Euler函数
        return (p - 1) * (q - 1);
    }

    static int gcd(int a, int b) {  // 求两数的gcd
        return b ? gcd(b, a % b) : a;
    }

    static int exgcd(int a, int b, int& x, int& y) {  // 扩展Euclid算法
        if (!b) {
            x = 1, y = 0;
            return a;
        }

        int d = exgcd(b, a % b, y, x);
        y -= a / b * x;
        return d;
    }

    static int inv(int a, int MOD) {  // 求a模MOD的逆元
        int x, y;
        exgcd(a, MOD, x, y);
        x = (x % MOD + MOD) % MOD;
        return x;
    }

    static int qpow(int a, int k, int MOD) {  // 快速幂求a的k次方模MOD
        int res = 1;
        for (; k; k >>= 1) {
            if (k & 1) res = (ll)res * a % MOD;
            a = (ll)a * a % MOD;
        }
        return res;
    }
};

int qpow(int a, int k, int MOD) {  // 快速幂求a的k次方模MOD
    int res = 1;
    for (; k; k >>= 1) {
        if (k & 1) res = (ll)res * a % MOD;
        a = (ll)a * a % MOD;
    }
    return res;
}

Math solver(256);
int p, q;  // 大素数
int n;  // 模数
int phi;  // Euler函数
int e, d;  // 公钥、私钥

void show() {  // 打印RSA的参数
    cout << "p = " << p << ", q = " << q << endl;
    cout << "n = " << n << ", phi = " << phi << endl;
    cout << "e = " << e << ", d = " << d << endl;
}

void rsa_init() {  // 初始化RSA的参数
    p = 13, q = 19;
    n = p * q;  // n < 256
    phi = Math::phi(p, q);

    // 随机一个与phi互素的
    srand(time(0));
    e = solver.primes[rand() % solver.cnt];
    d = Math::inv(e, phi);

    // show();
}