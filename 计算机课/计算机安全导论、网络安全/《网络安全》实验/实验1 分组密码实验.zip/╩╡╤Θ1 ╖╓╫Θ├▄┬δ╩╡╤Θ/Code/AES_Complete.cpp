#include <bits/stdc++.h>
#include "aes.h"
using namespace std;

uint8_t key[] = {  // 256-bit的密钥
    0x00, 0x01, 0x02, 0x03,
    0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0a, 0x0b,
    0x0c, 0x0d, 0x0e, 0x0f,
    0x10, 0x11, 0x12, 0x13,
    0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1a, 0x1b,
    0x1c, 0x1d, 0x1e, 0x1f
    };
uint8_t* w;

uint8_t in[16];  // 输入
uint8_t out[16];  // 输出

void init() {
    w = aes_init(sizeof(key));  // 初始化AES的参数和分配空间
    aes_key_expansion(key, w);  // 密钥扩展
}

void input() {
    cout << "Enter the file name: ";
    string name; cin >> name;
    cout << "Encrypt or Decrypt? [E / D]: ";
    char ch; cin >> ch;
    string s = ch == 'E' ? "_encrypted" : "_decrypted";

    ifstream fin(name, ios::binary);
    ofstream fout(name.substr(0, name.find('.')) + s + name.substr(name.find('.')), ios::binary);

    char szBuf[16 + 1] = { 0 };  // 与in[]同大小, 其中 + 1为'\0'的位置
    int cnt = 0;
    while (fin.read(szBuf, (int)sizeof(szBuf) - 1)) {  // 前面完整的块
        const int k = sizeof(szBuf) * 8;
        bitset<k> tmp;
        memcpy(&tmp, szBuf, sizeof(szBuf));

        uint8_t res = 0x00;
        for (int i = 0; i < k; i++) {
            int j = i % 8;
            res += tmp[i] * (1 << 7 - j);
            if (j == 7) {
                in[cnt++] = res;
                res = 0x00;
            }
        }
        cnt = 0;

        if (s[1] == 'e') {  // 加密
            aes_encryption(in, out, w);
            memcpy(in, out, sizeof(out));
        }
        else {  // 解密
            memcpy(out, in, sizeof(in));
            aes_decryption(out, in, w);
        }
        
        for (int i = 0; i < 16; i++) 
            for (int j = 0; j < 8; j++) tmp[8 * i + j] = in[i] >> (7 - j) & 1;

        memcpy(szBuf, &tmp, sizeof(szBuf));
        fout.write(szBuf, (int)sizeof(szBuf) - 1);

        memset(szBuf, 0, sizeof(szBuf));
        memset(in, 0, sizeof(in)), memset(out, 0, sizeof(out));
    }

    if (fin.eof()) {  // 最后一个可能不完整的块
        const int k = sizeof(szBuf) * 8;
        bitset<k> tmp;

        uint8_t res = 0x00;
        for (int i = 0; i < k; i++) {
            int j = i % 8;
            res += tmp[i] * (1 << 7 - j);
            if (j == 7) {
                in[cnt++] = res;
                res = 0x00;
            }
        }

        if (s[1] == 'e') {  // 加密
            aes_encryption(in, out, w);
            memcpy(in, out, sizeof(out));
        }
        else {  // 解密
            memcpy(out, in, sizeof(in));
            aes_decryption(out, in, w);
        }

        for (int i = 0; i < 16; i++) 
            for (int j = 0; j < 8; j++) tmp[8 * i + j] = in[i] >> (7 - j) & 1;
        
        memcpy(szBuf, &tmp, sizeof(szBuf));
        fout.write(szBuf, (int)sizeof(szBuf[0]) * (int)strlen(szBuf));

        memset(szBuf, 0, sizeof(szBuf));
        memset(in, 0, sizeof(in)), memset(out, 0, sizeof(out));
    }

    fin.close(), fout.close();
}

int main() {
    init();
    input();

    delete[] w;  // 释放空间

    return 0;
}