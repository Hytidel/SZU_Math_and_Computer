-- ---------= 表与数据 =---------
-- 设计师表
CREATE TABLE Designers (
	id INT(3) NOT NULL AUTO_INCREMENT, 
	name VARCHAR(20) NOT NULL, 
	daily DECIMAL(3, 2) NOT NULL, 
	
	PRIMARY KEY(id)
) ENGINE = InnoDB;

-- 4 个设计师
INSERT INTO Designers VALUES(1, "Alice", 1.23);
INSERT INTO Designers VALUES(2, "Bob", 2.34);
INSERT INTO Designers VALUES(3, "Carl", 3.45);
INSERT INTO Designers VALUES(4, "Dale", 4.56);

-- 顾客表
CREATE TABLE Customers (
	id INT(3) NOT NULL AUTO_INCREMENT, 
	lastName VARCHAR(10) NOT NULL,
	firstName VARCHAR(10) NOT NULL,
	phone INT(11) NOT NULL, 
	address VARCHAR(50) NOT NULL, 
	email VARCHAR(30) NOT NULL, 
	card VARCHAR(20) NOT NULL, 
	
	PRIMARY KEY(id)
) ENGINE = InnoDB;

-- 8 位顾客, 将自己的信息作为额外的顾客
INSERT INTO Customers VALUES(1, "Zhao", "Yi", 12345, "SZU 1", "szu1@gmail.com", "a12345");
INSERT INTO Customers VALUES(2, "Qian", "Er", 23456, "SZU 2", "szu2@gmail.com", "a23456");
INSERT INTO Customers VALUES(3, "Sun", "San", 34567, "SZU 3", "szu3@gmail.com", "a34567");
INSERT INTO Customers VALUES(4, "Li", "Si", 45678, "SZU 4", "szu4@gmail.com", "a45678");
INSERT INTO Customers VALUES(5, "Zhou", "Wu", 56789, "SZU 5", "szu5@gmail.com", "a56789");
INSERT INTO Customers VALUES(6, "Wu", "Liu", 67890, "SZU 6", "szu6@gmail.com", "a67890");
INSERT INTO Customers VALUES(7, "Zheng", "Qi", 78901, "SZU 7", "szu7@gmail.com", "a78901");
INSERT INTO Customers VALUES(8, "Feng", "Ba", 89012, "SZU 8", "szu8@gmail.com", "a89012");
INSERT INTO Customers VALUES(9, "Wang", "Xi", 90123, "SZU 9", "szu9@gmail.com", "a90123");

-- 包包表
CREATE TABLE Bags (
	id INT(3) NOT NULL AUTO_INCREMENT, 
	name VARCHAR(20) NOT NULL,
	type VARCHAR(10) NOT NULL,
	color VARCHAR(10) NOT NULL,
	did INT(3) NOT NULL, 
	manufacturer VARCHAR(20) NOT NULL,
	available BOOLEAN DEFAULT TRUE, 

	PRIMARY KEY(id), 
	FOREIGN KEY(did) REFERENCES Designers(id)
) ENGINE = InnoDB;

-- 10 个至少由 4 个设计师设计的包包 (1 + 2 + 3 + 4)
INSERT INTO Bags VALUES(1, "Bag 1", "type A", "red", 1, "Manufacturer 1", TRUE);
INSERT INTO Bags VALUES(2, "Bag 2", "type B", "green", 2, "Manufacturer 2", TRUE);
INSERT INTO Bags VALUES(3, "Bag 3", "type C", "blue", 2, "Manufacturer 3", TRUE);
INSERT INTO Bags VALUES(4, "Bag 4", "type C", "blue", 3, "Manufacturer 4", TRUE);
INSERT INTO Bags VALUES(5, "Bag 5", "type B", "green", 3, "Manufacturer 5", TRUE);
INSERT INTO Bags VALUES(6, "Bag 6", "type A", "red", 3, "Manufacturer 6", TRUE);
INSERT INTO Bags VALUES(7, "Bag 7", "type A", "red", 4, "Manufacturer 7", TRUE);
INSERT INTO Bags VALUES(8, "Bag 8", "type B", "green", 4, "Manufacturer 8", TRUE);
INSERT INTO Bags VALUES(9, "Bag 9", "type C", "blue", 4, "Manufacturer 9", TRUE);
INSERT INTO Bags VALUES(10, "Bag 10", "type C", "blue", 4, "Manufacturer 10", TRUE);

-- 租借表
CREATE TABLE Rentals (
	id INT(3) NOT NULL AUTO_INCREMENT, 
	cid INT(3) NOT NULL, 
	bid INT(3) NOT NULL, 
	rentedDate DATE NOT NULL, 
	returnedDate DATE NOT NULL, 
	insurance BOOLEAN DEFAULT FALSE, 

	PRIMARY KEY(id), 
	FOREIGN KEY(cid) REFERENCES Customers(id), 
	FOREIGN KEY(bid) REFERENCES Bags(id)
) ENGINE = InnoDB;

-- 每个包包至少被借 1 次, 每位顾客借 2 次包包
INSERT INTO Rentals VALUES(1, 1, 1, "2023-1-1", "2023-1-2", FALSE);
INSERT INTO Rentals VALUES(2, 1, 2, "2023-2-1", "2023-2-3", TRUE);
INSERT INTO Rentals VALUES(3, 2, 3, "2023-3-1", "2023-3-4", FALSE);
INSERT INTO Rentals VALUES(4, 2, 4, "2023-4-1", "2023-4-5", TRUE);
INSERT INTO Rentals VALUES(5, 3, 5, "2023-5-1", "2023-5-6", FALSE);
INSERT INTO Rentals VALUES(6, 3, 6, "2023-6-1", "2023-6-7", TRUE);
INSERT INTO Rentals VALUES(7, 4, 7, "2023-7-1", "2023-7-8", FALSE);
INSERT INTO Rentals VALUES(8, 4, 8, "2023-8-1", "2023-8-9", TRUE);
INSERT INTO Rentals VALUES(9, 5, 9, "2023-9-1", "2023-9-10", FALSE);
INSERT INTO Rentals VALUES(10, 5, 10, "2023-10-1", "2023-10-11", TRUE);
INSERT INTO Rentals VALUES(11, 6, 1, "2023-11-1", "2023-11-12", FALSE);
INSERT INTO Rentals VALUES(12, 6, 2, "2023-12-1", "2023-12-13", TRUE);
INSERT INTO Rentals VALUES(13, 7, 3, "2024-1-1", "2024-1-14", FALSE);
INSERT INTO Rentals VALUES(14, 7, 4, "2024-2-1", "2024-2-15", TRUE);
INSERT INTO Rentals VALUES(15, 8, 5, "2024-3-1", "2024-3-16", FALSE);
INSERT INTO Rentals VALUES(16, 8, 6, "2024-4-1", "2024-4-17", TRUE);
INSERT INTO Rentals VALUES(17, 9, 7, "2024-5-1", "2024-5-18", FALSE);
INSERT INTO Rentals VALUES(18, 9, 8, "2024-6-1", "2024-6-19", TRUE);

-- 用户表
CREATE TABLE Users (
	id INT(3) NOT NULL AUTO_INCREMENT, 
	username VARCHAR(20) NOT NULL, 
	password VARCHAR(20) NOT NULL,
	admin BOOLEAN DEFAULT FALSE, 
	cid INT(3) NOT NULL, 

	PRIMARY KEY(id)
) ENGINE = InnoDB;

-- 添加管理员用户
INSERT INTO Users VALUES(1, "admin", "admin", TRUE, 0);

-- ---------= 存储过程 =---------
-- 2.4.1 插入租赁
DROP PROCEDURE IF EXISTS addRental;
DELIMITER $
CREATE PROCEDURE addRental(IN _cid INT(3), IN _bid INT(3), IN _rentedDate DATE, IN _returnedDate DATE, IN _insurance BOOLEAN)
BEGIN 
	-- 将租赁插入 rentals 表
	INSERT INTO rentals(cid, bid, rentedDate, returnedDate, insurance) 
		VALUES(_cid, _bid, _rentedDate, _returnedDate, _insurance);
	
	-- 设置被租的包为不可租
	UPDATE bags SET available = '0' WHERE id = _bid;
END $
DELIMITER ;

-- 2.4.2 插入包包
DROP PROCEDURE IF EXISTS addBag;
DELIMITER $
CREATE PROCEDURE addBag(IN _name VARCHAR(20), IN _type VARCHAR(10), IN _color VARCHAR(10), IN _did INT(3), IN _manufacturer VARCHAR(20))
BEGIN 
	INSERT INTO bags(name, type, color, did, manufacturer)
		VALUES(_name, _type, _color, _did, _manufacturer);
END $
DELIMITER ;

-- 2.1 输入设计师名, 显示 ta 设计的包包的名称、颜色、厂商
DROP PROCEDURE IF EXISTS bagsByManufacturer;
DELIMITER $
CREATE PROCEDURE bagsByManufacturer(IN designerName VARCHAR(20))
BEGIN
	DROP VIEW IF EXISTS viewBags;
	CREATE VIEW viewBags AS (SELECT id, name, color, did, manufacturer FROM bags);
	SELECT name, color, manufacturer FROM viewBags WHERE
		did = (SELECT designers.id FROM designers WHERE designers.name = designerName);
END $
DELIMITER ;

-- 2.2 对每位顾客租过的包包的时间求和, 展示每位顾客的姓、名、地址、电话、租包包的总时间, 
-- 将顾客按租包包的总时间非升序排列
DROP PROCEDURE IF EXISTS bestCustomers;
DELIMITER $
CREATE PROCEDURE bestCustomers()
BEGIN
	-- 创建一个展示租赁时长的视图
	DROP VIEW IF EXISTS viewRental;
	CREATE VIEW viewRental AS 
		(SELECT id, cid, bid, 
			TIMESTAMPDIFF(DAY, rentedDate, returnedDate) AS rentalDuration, 
			insurance
		FROM rentals);

	SELECT c.lastName, c.firstName, c.address, c.phone, 
			SUM(r.rentalDuration) AS totalLengthOfRental
		FROM customers c
		JOIN viewRental r ON c.id = r.cid
		GROUP BY c.id
		ORDER BY rentalDuration DESC;
END $
DELIMITER ;

-- 2.3 输入顾客的 id , 展示该顾客的姓、名、租过的包包的厂商、名称、花费、所有租赁的总花费
DROP PROCEDURE IF EXISTS reportCustomerAmount;
DELIMITER $
CREATE PROCEDURE reportCustomerAmount(IN customerId INT(3))
BEGIN
	-- 创建一个展示租赁时长、日租金(含保险)、花费的视图
	DROP VIEW IF EXISTS viewRental;
	CREATE VIEW viewRental AS 
		(SELECT r.id, r.cid, r.bid, 
			TIMESTAMPDIFF(DAY, r.rentedDate, r.returnedDate) AS rentalDuration, 
			(d.daily + insurance) AS dailyCost, 
			(TIMESTAMPDIFF(DAY, r.rentedDate, r.returnedDate) * (d.daily + insurance)) AS cost
		FROM rentals r
		JOIN customers c ON r.cid = c.id
		JOIN bags b ON r.bid = b.id
		JOIN designers d ON b.did = d.id);

	SELECT c.lastName, c.firstName, b.manufacturer, b.name, r.cost
	FROM customers c
	JOIN viewRental r ON c.id = r.cid 
	JOIN bags b ON b.id = r.bid
	WHERE c.id = customerId AND r.cid = customerId;
END $
DELIMITER ;

-- 输入顾客 id , 展示顾客在租的包包
DROP PROCEDURE IF EXISTS getRenting;
DELIMITER $
CREATE PROCEDURE getRenting(IN customerId INT(3))
BEGIN
	-- 创建一个展示在租的包包的名称、日租金、借出日期、是否购买保险的视图
	DROP VIEW IF EXISTS viewRental;
	CREATE VIEW viewRental AS 
		(SELECT r.id, c.id AS cid, b.id AS bid, b.name, d.daily, r.rentedDate, r.returnedDate, r.insurance
		FROM rentals r
		JOIN customers c ON r.cid = c.id
		JOIN bags b ON r.bid = b.id
		JOIN designers d ON b.did = d.id
		ORDER BY r.id);

	-- 在租包包的归还日期 > 当前日期
	SELECT r.id, c.lastName, c.firstName, r.name, r.daily, r.rentedDate, r.insurance
	FROM customers c
	JOIN viewRental r ON c.id = r.cid 
	JOIN bags b ON b.id = r.bid
	WHERE c.id = customerId AND r.cid = customerId AND r.returnedDate > CURDATE();
END $
DELIMITER ;

-- 用于 2.5 , 创建一个展示租赁时长、日租金(含保险)、花费的视图
DROP PROCEDURE IF EXISTS returnImplement;
DELIMITER $
CREATE PROCEDURE returnImplement(IN rentalId INT(3))
BEGIN
	DROP VIEW IF EXISTS viewReturn;
	CREATE VIEW viewReturn AS 
		(SELECT r.id, b.name, 
			TIMESTAMPDIFF(DAY, r.rentedDate, r.returnedDate) AS rentalDuration, 
			(d.daily + insurance) AS dailyCost, 
			(TIMESTAMPDIFF(DAY, r.rentedDate, r.returnedDate) * (d.daily + insurance)) AS cost
		FROM rentals r
		JOIN customers c ON r.cid = c.id
		JOIN bags b ON r.bid = b.id
		JOIN designers d ON b.did = d.id);

	SELECT name, rentalDuration, dailyCost, cost FROM viewReturn WHERE id = rentalId;
END $
DELIMITER ;

-- 2.5 触发器, 还包时展示租赁的总时长、总花费, 并让该包可租
DROP TRIGGER IF EXISTS returnTrigger;
DELIMITER $
CREATE TRIGGER returnTrigger
AFTER UPDATE ON rentals FOR EACH ROW
BEGIN
	-- returnedDate 被修改为不晚于当前日期, 则认为发生还包
	IF (old.returnedDate != new.returnedDate AND new.returnedDate <= CURDATE()) THEN
		-- 让该包可租
		UPDATE bags SET available = '1' WHERE id = old.bid;
	END IF;
END $
DELIMITER ;