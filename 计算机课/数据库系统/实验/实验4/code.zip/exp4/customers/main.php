<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>顾客表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <h1>顾客信息</h1>

    <div class="center">
        <form action="./add.html" method="post">
            <input class="button" type="submit" value="新增">
        </form>

        <br>

        <form action="" method="post">
            <input type="text" placeholder="查找关键词(不区分大小写)" name="word">
            <input class="button" type="submit" value="查找" name="search">
        </form>

        <br>

        <form action="./bestCustomers.php" method="post">
            <input class="button" type="submit" value="排序" name="sort">
        </form>
    </div>

    <table width="800px">
        <?php
            printTable($con, "customers");
        ?>
    </table>
</body>
</html>