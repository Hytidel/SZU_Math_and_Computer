<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>顾客表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <a href="./main.php">返回</a>

    <h1>顾客信息</h1>

    <div class="center">
        <?php
            echo "<table width='800px'>";
            // 表头
            echo "<br>";
            echo "<tr>";
            echo "<th>lastName</th>";
            echo "<th>firstName</th>";
            echo "<th>address</th>";
            echo "<th>phone</th>";
            echo "<th>totalLengthOfRental</th>";
            echo "</tr>";

            $sql = "CALL bestCustomers()";
            $table = mysqli_query($con, $sql) or die(mysqli_error($con));
            if (mysqli_num_rows($table)) {
                while ($line = mysqli_fetch_assoc($table)) {
                    $lastName = $line["lastName"];
                    $firstName = $line["firstName"];
                    $address = $line["address"];
                    $phone = $line["phone"];
                    $totalLengthOfRental = $line["totalLengthOfRental"];

                    echo "<tr>";
                    echo "<td>$lastName</td>";
                    echo "<td>$firstName</td>";
                    echo "<td>$address</td>";
                    echo "<td>$phone</td>";
                    echo "<td>$totalLengthOfRental</td>";
                    echo "</tr>";
                }
            }
            else {
                echo "no data";
            }

            echo "</table>";
        ?>
    </div>
</body>
</html>