<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改设计师</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $id = $_POST["id"];
        $name= $_POST["name"];
        $daily= $_POST["daily"];

        if ($id == null || $name == null || $daily == null) {
            ?>
                <script language=javascript>
                    window.alert("输入不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            if (modifyDesigner($con, $id, $name, $daily)) {
                ?>
                    <script language=javascript>
                        window.alert("修改成功!");
                    </script>
                <?php

                header("Location: ./main.php");
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("修改失败!");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>