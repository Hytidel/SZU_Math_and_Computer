<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>包包表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <?php
        $id = $_GET["id"];
    ?>

    <a href="./main.php">返回</a>

    <h1><?php echo queryDesigner($con, $id)?> 设计的包包</h1>

    <div class="center">    
        <?php
            echo "<table width='800px'>";
            // 表头
            echo "<br>";
            echo "<tr>";
            echo "<th>name</th>";
            echo "<th>color</th>";
            echo "<th>manufacturer</th>";
            echo "</tr>";

            $sql = "SELECT * FROM bags WHERE did = $id";
            $res = mysqli_query($con, $sql) or die(mysqli_error($con));
            $rowCnt = 0;
            if (mysqli_num_rows($res)) {
                while ($line = mysqli_fetch_assoc($res)) {
                    $name = $line["name"];
                    $color = $line["color"];
                    $manufacturer = $line["manufacturer"];

                    echo "<tr>";
                    echo "<td>$name</td>";
                    echo "<td>$color</td>";
                    echo "<td>$manufacturer</td>";
                    echo "</tr>";

                    $rowCnt++;
                }
            }
            else {
                echo "no data";
            }

            echo "<tr>";
            echo "<td></td>";
            echo "<td></td>";
            echo "<td>Total: $rowCnt</td>";
            echo "</tr>";

            echo "</table>";
        ?>
    </div>
</body>
</html>