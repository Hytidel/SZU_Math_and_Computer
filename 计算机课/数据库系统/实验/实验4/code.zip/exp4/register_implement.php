<?php include "conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $username = $_POST["username"];
        $password = $_POST["password"];
        $lastName = $_POST["lastName"];
        $firstName = $_POST["firstName"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];
        $email = $_POST["email"];
        $card = $_POST["card"];

        if ($username == null || $password == null || $lastName == null || $firstName == null || $phone == null || $address == null || $email == null || $card == null) {
            ?>
                <script language=javascript>
                    window.alert("输入不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            $sql = "INSERT INTO customers(lastName, firstName, phone, address, email, card) 
                VALUES ('$lastName', '$firstName', '$phone', '$address', '$email', '$card')";
            $res = mysqli_query($con, $sql);
            
            if ($res) {
                /*if (function_exists('date_default_timezone_set')) {
                    date_default_timezone_set('UTC');
                }
                $time = date("y-m-d h:m:s");
                $key_value = '(' . $eid . ', ' . $ename . ', ' . $city . ')';
                $key_value = mysqli_real_escape_string($con, $key_value);
                $sql = "INSERT INTO logs(who, time, table_name, operation, key_value) VALUES ('admin', '$time', 'employees', 'insert', '" . $key_value . "')";
                $res = mysqli_query($con, $sql);*/

                $sql = "SELECT * FROM customers WHERE lastName='$lastName' AND firstName='$firstName' 
                    AND phone='$phone' AND address='$address' AND email='$email' AND card='$card'";
                $res = mysqli_query($con, $sql);
                if (mysqli_num_rows($res)) {
                    while ($line = mysqli_fetch_assoc($res)) {
                        $cid = $line["id"];

                        $sql = "INSERT INTO users(username, password, admin, cid) 
                            VALUES ('$username', '$password', FALSE, '$cid')";
                        $res = mysqli_query($con, $sql);
                    }
                }

                ?>
                    <script language=javascript>
                        window.alert("插入成功!");
                    </script>
                <?php

                header("Location: ./login.html");
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("插入失败!");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>