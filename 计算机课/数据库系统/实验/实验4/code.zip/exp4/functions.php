<?php 
    include "conn.php";

// ---------= 数据表 =---------

    // 根据表名获取表结构
    function getTableStructure($con, $tableName) {
        $sql = "DESC $tableName";
        $res = mysqli_query($con, $sql) or die(mysqli_error($con));
        return $res;
    }

    // 根据表名获取表主键
    function getTablePrimaryKey($con, $tableName) {
        $res = getTableStructure($con, $tableName);
        $rowCnt = mysqli_num_rows($res);
        for ($i = 0; $i < $rowCnt; $i++) {
            $row = mysqli_fetch_array($res);
            if ($row["Key"] == "PRI") $primaryKey = $row['Field'];
        }
        if (empty($primaryKey)) return $row['Field'];
        return $primaryKey;
    }

    // 根据表名获取表
    function getTable($con, $tableName) {
        $primaryKey = getTablePrimaryKey($con, $tableName);
        $sql = "SELECT * FROM $tableName ORDER BY '$primaryKey'";
        $res = mysqli_query($con, $sql) or die(mysqli_error($con));
        return $res;
    }

    // 根据表名获取表字段
    function getTableField($con, $tableName) {
        $fields = array();
        $res = getTableStructure($con, $tableName);
        $fieldCnt = mysqli_num_rows($res);
        for ($i = 0; $i < $fieldCnt; $i++) {
            $field = mysqli_fetch_array($res);
            $fields[$i] = $field['Field'];
        }
        return $fields;
    }

    // 根据表名打印表的实现
    // $table : 表
    // $rowCnt : 行数
    // $fields : 字段
    // $primaryKey : 主键
    // $fieldCnt : 字段个数 
    function printTableImplement($con, $tableName, $table, $rowCnt, $fields, $primaryKey, $fieldCnt) {
        // 表头
        echo "<tr>";
        for ($i = 0; $i < $fieldCnt; $i++) {
            echo "<th>$fields[$i]</th>";
        }
        echo "<th>operation</th>";
        echo "</tr>";

        // 搜索
        if (empty($_POST["search"]) || $_POST["word"] == '') {
            $sql = "SELECT * FROM $tableName ORDER BY $primaryKey";
        }
        else {
            $word = $_POST["word"];
            $sql = "SELECT * FROM $tableName WHERE ";
            for ($i = 0; $i < $fieldCnt; $i++) {
               $sql .= "$fields[$i] LIKE '%$word%' ";
               if ($i != $fieldCnt - 1) $sql .= "OR ";
            }
        }
        $res = mysqli_query($con, $sql);
        
        if (mysqli_num_rows($res)) {
            while ($line = mysqli_fetch_assoc($res)) {
                echo "<tr>";
                for ($i = 0; $i < $fieldCnt; $i++) {
                    $field = $fields[$i];
                    if ($field == $primaryKey) $primaryValue = $line[$field];
                    echo "<td>$line[$field]</td>";
                }
                echo "
                    <td>
                        <form action='./modify.php?$primaryKey=$primaryValue' method='post'>
                            <input class='button' type='submit' value='修改'>
                        </form>

                        <form action='./delete_implement.php?$primaryKey=$primaryValue' method='post'>
                            <input class='button' type='submit' value='删除'>
                        </form>
                    </td>
                    ";
                echo "</tr>";
            }
        }
        else {
            echo "no data";
        }

        mysqli_close($con);
    }

    // 根据表名打印表
    function printTable($con, $tableName) {
        $table = getTable($con, $tableName);
        $rowCnt = mysqli_num_rows($table);
        $fields = getTableField($con, $tableName);
        $primaryKey = getTablePrimaryKey($con, $tableName);
        $fieldCnt = count($fields);
        printTableImplement($con, $tableName, $table, $rowCnt, $fields, $primaryKey, $fieldCnt);
    }

// ---------= 功能性函数 =---------

// 获取当前日期的字符串表示
function getCurrentDate() {
    if (function_exists('date_default_timezone_set')) {
        date_default_timezone_set('UTC');
    }
    $date = date("y-m-d");
    return $date;
}

// ---------= 包包表 =---------

    // 插入包包
    function addBag($con, $name, $type, $color, $did, $manufacturer) {
        $sql = "INSERT INTO bags(name, type, color, did, manufacturer) VALUES
            ('$name', '$type', '$color', '$did', '$manufacturer')";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 删除包包
    function deleteBag($con, $id) {
        $sql = "DELETE FROM bags WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 修改包包
    function modifyBag($con, $id, $name, $type, $color, $did, $manufacturer, $available) {
        $sql = "UPDATE bags SET name='$name', type='$type', color='$color', 
            did='$did', manufacturer='$manufacturer', available='$available' WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

// ---------= 设计师表 =---------

    // 插入设计师
    function addDesigner($con, $name, $daily) {
        $sql = "INSERT INTO designers(name, daily) VALUES('$name', '$daily')";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 删除设计师
    function deleteDesigner($con, $id) {
        $sql = "DELETE FROM designers WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 修改设计师
    function modifyDesigner($con, $id, $name, $daily) {
        $sql = "UPDATE designers SET name='$name', daily='$daily' WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 根据设计师 id 查询名称
    function queryDesigner($con, $id) {
        $sql = "SELECT name FROM designers WHERE id = $id";
        $res = mysqli_query($con, $sql); 
        if (mysqli_num_rows($res)) {
            while ($line = mysqli_fetch_assoc($res)) {
                $name = $line["name"];
            }
        }
        return $name;
    }

// ---------= 顾客表 =---------

    // 插入顾客
    function addCustomer($con, $lastName, $firstName, $phone, $address, $email, $card) {
        $sql = "INSERT INTO customers(lastName, firstName, phone, address, email, card) 
            VALUES('$lastName', '$firstName', '$phone', '$address', '$email', '$card')";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 删除顾客
    function deleteCustomer($con, $id) {
        $sql = "DELETE FROM customers WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 修改顾客
    function modifyCustomer($con, $id, $lastName, $firstName, $phone, $address, $email, $card) {
        $sql = "UPDATE customers SET lastName='$lastName', firstName='$firstName', 
            phone='$phone', address='$address', email='$email', card='$card' WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

// ---------= 租赁表 =---------

    // 插入租赁
    function addRental($con, $cid, $bid, $rentedDate, $returnedDate, $insurance) {
        $sql = "INSERT INTO rentals(cid, bid, rentedDate, returnedDate, insurance) 
            VALUES('$cid', '$bid', '$rentedDate', '$returnedDate', '$insurance')";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 删除租赁
    function deleteRental($con, $id) {
        $sql = "DELETE FROM rentals WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 修改租赁
    function modifyRental($con, $id, $cid, $bid, $rentedDate, $returnedDate, $insurance) {
        $sql = "UPDATE rentals SET cid='$cid', bid='$bid', rentedDate='$rentedDate', 
            returnedDate='$returnedDate', insurance='$insurance' WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

// ---------= 用户表 =---------

    // 插入用户
    function addUser($con, $username, $password, $admin, $cid) {
        $sql = "INSERT INTO users(username, password, admin, cid) 
            VALUES('$username', '$password', '$admin', '$cid')";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 删除用户
    function deleteUser($con, $id) {
        $sql = "DELETE FROM users WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }

    // 修改用户
    function modifyUser($con, $id, $username, $password, $admin, $cid) {
        $sql = "UPDATE users SET username='$username', password='$password', 
            admin='$admin', cid='$cid' WHERE id='$id'";
        $res = mysqli_query($con, $sql); 
        return $res;
    }
?>