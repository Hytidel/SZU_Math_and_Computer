<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>在借表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <div class="center">
        <?php
            $id = $_GET["id"];
            
            $date= getCurrentDate();
            $sql = "UPDATE rentals SET returnedDate = '$date' WHERE id = '$id'";
            mysqli_query($con, $sql) or die(mysqli_error($con));

            echo "<table width='800px'>";
            // 表头
            echo "<br>";
            echo "<tr>";
            echo "<th>name</th>";
            echo "<th>rentalDuration</th>";
            echo "<th>dailyCost (insurance included)</th>";
            echo "<th>cost</th>";
            echo "</tr>";

            $sql = "CALL returnImplement('$id')";
            $res = mysqli_query($con, $sql) or die(mysqli_error($con));
            if (mysqli_num_rows($res)) {
                while ($line = mysqli_fetch_assoc($res)) {
                    $name = $line["name"];
                    $rentalDuration = $line["rentalDuration"];
                    $dailyCost = $line["dailyCost"];
                    $cost = $line["cost"];

                    echo "<tr>";
                    echo "<td>$name</td>";
                    echo "<td>$rentalDuration</td>";
                    echo "<td>$dailyCost</td>";
                    echo "<td>$cost</td>";
                    echo "</tr>";
                }
            }
            else {
                echo "no data";
            }

            echo "</table>";

            mysqli_close($con);
        ?>

        <form action="#" method="post">
            <br><br>
            <input class="button" type="submit" value="确定" name="confirm">

            <?php
                if (isset($_POST["confirm"])) {
                    ?>
                        <script language=javascript>
                            window.close();
                        </script>
                    <?php
                }
            ?>
        </form>
    </div>
</body>
</html>