<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>在借表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <h1>在借信息</h1>

    <div class="center">
        <?php
            $cid = $_GET["cid"];

            echo "<table width='800px'>";
            // 表头
            echo "<br>";
            echo "<tr>";
            echo "<th>id</th>";
            echo "<th>lastName</th>";
            echo "<th>firstName</th>";
            echo "<th>name</th>";
            echo "<th>daily</th>";
            echo "<th>rentedDate</th>";
            echo "<th>operation</th>";
            echo "</tr>";

            $sql = "CALL getRenting('$cid')";
            $table = mysqli_query($con, $sql) or die(mysqli_error($con));
            if (mysqli_num_rows($table)) {
                while ($line = mysqli_fetch_assoc($table)) {
                    $id = $line["id"];
                    $lastName = $line["lastName"];
                    $firstName = $line["firstName"];
                    $name = $line["name"];
                    $daily = $line["daily"];
                    $rentedDate = $line["rentedDate"];

                    echo "<tr>";
                    echo "<td>$id</td>";
                    echo "<td>$lastName</td>";
                    echo "<td>$firstName</td>";
                    echo "<td>$name</td>";
                    echo "<td>$daily</td>";
                    echo "<td>$rentedDate</td>";
                    echo "
                        <td>
                            <form action='./return_implement.php?id=$id' method='post'>
                                <input class='button' type='submit' value='还包'>
                            </form>
                        </td>
                        ";
                    echo "</tr>";
                }
            }
            else {
                echo "no data";
            }

            echo "</table>";
        ?>
    </div>
</body>
</html>