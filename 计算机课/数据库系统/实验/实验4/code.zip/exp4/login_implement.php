<?php include "conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $username = $_POST["username"];
        $password = $_POST["password"];

        if ($username == null || $password == null) {
            ?>
                <script language=javascript>
                    window.alert("账号、密码不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            $authority = $_POST["authority"];

            $sql = "SELECT * FROM users WHERE username='$username' AND password='$password' AND admin=FALSE";
            if ($authority == "admin") {
                $sql = "SELECT * FROM users WHERE username='$username' AND password='$password' AND admin=TRUE";
            }
            
            $res = mysqli_query($con, $sql);
            if (mysqli_num_rows($res) > 0) {
                while ($line = mysqli_fetch_assoc($res)) {
                    $cid = $line["cid"];
                }

                if ($authority == "admin") {
                    header("Location: ./admin_index.php?cid=$cid");
                }
                else {
                    header("Location: ./user_index.php?cid=$cid");
                }
                
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("账号或密码错误");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>