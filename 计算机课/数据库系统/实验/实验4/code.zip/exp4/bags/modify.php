<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改包包</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        .add {
            margin: 50px auto;
            padding-top: 40px;

            width: 300px;
            height: 480px;
            background-color: bisque;
            text-align: center;

            border-radius: 10px;

            box-shadow: 2px 5px 10px 1px rgba(0, 0, 0, 0.5);
        }

        .add h3 {
            margin-bottom: 12px;
            font-size: 18px;
            color: midnightblue;
        }

        .add input {
            width: 180px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
            
            padding-left: 10px;
        }

        .add .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;

            padding-left: 0px;
        }

        a {
            margin-left: 10px;

            font-size: 20px;
            font-weight: 400;
            line-height: 40px;

            color: #333;

            text-decoration: none;
        }

        a:hover {
            color: blue;
        }
    </style>
</head>
<body>
    <a href="./main.php">返回</a>

    <?php 
        $id = $_GET["id"];
        $sql = "SELECT * FROM bags WHERE id='$id'";
        $res = mysqli_query($con, $sql);

        $line = mysqli_fetch_assoc($res);
        $name = $line["name"];
        $type = $line["type"];
        $color = $line["color"];
        $did = $line["did"];
        $manufacturer = $line["manufacturer"];
        $available = $line["available"];
    ?>

    <div class="add">
        <form action="./modify_implement.php" method="post">
            <h3>修改包包</h3>
            <input type="text" readonly=true placeholder="请输入 包包 id" value="<?php echo $id; ?>" name="id">
            <br><br>
            <input type="text" placeholder="请输入 名称" value="<?php echo $name; ?>" name="name">
            <br><br>
            <input type="text" placeholder="请输入 种类" value="<?php echo $type; ?>" name="type">
            <br><br>
            <input type="text" placeholder="请输入 颜色" value="<?php echo $color; ?>" name="color">
            <br><br>
            <input type="text" placeholder="请输入 设计师 id" value="<?php echo $did; ?>" name="did">
            <br><br>
            <input type="text" placeholder="请输入 厂商" value="<?php echo $manufacturer; ?>" name="manufacturer">
            <br><br>
            <input type="text" placeholder="请输入 是否可租" value="<?php echo $available; ?>" name="available">
            <br><br>
            <input class="button" type="submit" value="确定" name="confirm">
        </form>
    </div>
</body>
</html>