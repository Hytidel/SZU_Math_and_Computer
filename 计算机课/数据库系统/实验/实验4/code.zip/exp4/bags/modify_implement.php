<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改顾客</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $id = $_POST["id"];
        $name= $_POST["name"];
        $type= $_POST["type"];
        $color= $_POST["color"];
        $did= $_POST["did"];
        $manufacturer= $_POST["manufacturer"];
        $available= $_POST["available"];

        if ($id == null || $name == null || $type == null || $color == null || $did == null || $manufacturer == null) {
            ?>
                <script language=javascript>
                    window.alert("输入不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            if (modifyBag($con, $id, $name, $type, $color, $did, $manufacturer, $available)) {
                ?>
                    <script language=javascript>
                        window.alert("修改成功!");
                        window.close();
                    </script>
                <?php

                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("修改失败!");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>