<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>删除用户</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $id = $_GET["id"];
        if (deleteUser($con, $id)) {
            ?>
                <script language=javascript>
                    window.alert("删除成功!");
                </script>
            <?php

            header("Location: ./main.php");
            exit;
        }
        else {
            ?>
                <script language=javascript>
                    window.alert("删除失败!");
                    history.back(1);
                </script>
            <?php
        }

        mysqli_close($con);
    ?>
</body>
</html>