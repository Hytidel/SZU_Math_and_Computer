<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>包包表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        .short {
            width: 100px;
            height: 24px;
            font-size: 12px;
            line-height: 24px;
        }

        .checkbox {
            margin: auto 10px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <h1>包包信息</h1>

    <div class="center">
        <form action="./add.php" method="post">
            <input class="button" type="submit" disabled value="新增">
        </form>

        <br>

        <form action="#" method="post">
            <input type="text" placeholder="查找关键词(不区分大小写)" name="word">
            <input class="button" type="submit" value="查找" name="search">
        </form>

        <br>

        <?php
            $cid = $_GET["cid"];
            echo "<form action='./bagsByManufacturer.php?cid=$cid' method='post'>";
        ?>

            <input class="button" type="submit" value="筛选" name="filter">
        </form>
    </div>

    <table width="800px">
        <?php
            // 表头
            echo "<br>";
            echo "<tr>";
            echo "<th>id</th>";
            echo "<th>name</th>";
            echo "<th>type</th>";
            echo "<th>color</th>";
            echo "<th>did</th>";
            echo "<th>manufacturer</th>";
            echo "<th>available</th>";
            echo "<th>operation</th>";
            echo "<th>insurance</th>";
            echo "</tr>";

            $sql = "SELECT * FROM bags";
            $table = mysqli_query($con, $sql) or die(mysqli_error($con));
            if (mysqli_num_rows($table)) {
                while ($line = mysqli_fetch_assoc($table)) {
                    $id = $line["id"];
                    $name = $line["name"];
                    $type = $line["type"];
                    $color = $line["color"];
                    $did = $line["did"];
                    $manufacturer = $line["manufacturer"];
                    $available = $line["available"];

                    echo "<tr>";
                    echo "<td>$id</td>";
                    echo "<td>$name</td>";
                    echo "<td>$type</td>";
                    echo "<td>$color</td>";
                    echo "<td>$did</td>";
                    echo "<td>$manufacturer</td>";
                    echo "<td>$available</td>";
                    echo "
                        <td>
                            <form action='./modify.php?id=$id' method='post'>
                                <input class='button' type='submit' disabled value='修改'>
                            </form>

                            <form action='./delete_implement.php?id=$id' method='post'>
                                <input class='button' type='submit' disabled value='删除'>
                            </form>
                        </td>
                        ";
                    
                    echo "<td>";
                    echo "<form action='#' method='post'>";
                    echo "<input class='short' type='text' placeholder='请输入 归还日期' name='returnedDate'>";
                    echo "<input class='checkbox' type='checkbox' name='insurance$id'>";

                    if ($available) {
                        echo "<input class='button' type='submit' value='租包' name='rent$id'>";
                    }
                    else {
                        echo "<input class='button' type='submit' disabled value='租包' name='rent$id'>";
                    }
                    
                    if (isset($_POST["rent$id"])) {
                        $returnedDate = $_POST["returnedDate"];
                        $insurance = 0;
                        if (isset($_POST["insurance$id"])) $insurance = 1;

                        $rentedDate = getCurrentDate();
                        $sql = "CALL addRental('$cid', '$id', '$rentedDate', '$returnedDate', '$insurance')";
                        $res = mysqli_query($con, $sql) or die(mysqli_error($con));
                        ?>
                            <script language=javascript>
                                window.alert("租包成功!");
                                window.close();
                            </script>
                        <?php
                    }

                    echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
            }
            else {
                echo "no data";
            }
        ?>
    </table>
</body>
</html>