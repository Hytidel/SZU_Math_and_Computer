<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>奢侈品租赁系统</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        li {
            list-style: none;
        }

        .box {
            margin: 50px auto;
            width: 1200px;
            height: 600px;
            
            background-color: #fff;

            border: 1px solid #ddd;
            border-radius: 10px;
        }

        .box ul {
            height: 600px;

            padding: 90px 40px 90px 60px;

            display: flex;
            flex-wrap: wrap;  /* 弹性盒子换行 */
            justify-content: space-between;  /* 调整主轴对齐方式 */ 
            align-content: space-between;  /* 调整主轴对齐方式 */ 
        }

        .box li {
            width: 500px;
            height: 88px;

            display: flex;
        }

        .box .pic {
            margin-right: 15px;
        }

        .box .text a {
            font-size: 20px;
            font-weight: 400;
            line-height: 40px;

            color: #333;

            text-decoration: none;
        }

        .box .text a:hover {
            color: blue;
        }

        .box .text p {
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="box">
        <ul>
            <?php
                $cid = $_GET["cid"];
            ?>

            <li>
                <div class="pic">
                    <img src="./images/rocket.svg" alt="">
                </div>

                <div class="text">
                    <?php
                        echo "<a href='./bags/main.php?cid=$cid' target='_blank'>包包表</a>";
                    ?>

                    <p>在这里借包包. </p>
                </div>
            </li>

            <li>
                <div class="pic">
                    <img src="./images/rocket.svg" alt="">
                </div>

                <div class="text">
                    <?php
                        echo "<a href='./renting/main.php?cid=$cid' target='_blank'>在借表</a>";
                    ?>
                    
                    <p>在这里还包包. </p>
                </div>
            </li>

            <li>
                <div class="pic">
                    <img src="./images/rocket.svg" alt="">
                </div>

                <div class="text">
                    <a href="./designers/main.php" target="_blank">设计师表</a>
                    <p>对设计师表进行增、删、改、查. </p>
                </div>
            </li>
            
            <li>
                <div class="pic">
                    <img src="./images/rocket.svg" alt="">
                </div>

                <div class="text">
                    <a href="./customers/main.php" target="_blank">顾客表</a>
                    <p>对顾客表进行增、删、改、查. </p>
                </div>
            </li>

            <li>
                <div class="pic">
                    <img src="./images/rocket.svg" alt="">
                </div>

                <div class="text">
                    <a href="./rentals/main.php" target="_blank">租赁表</a>
                    <p>对租赁表进行增、删、改、查. </p>
                </div>
            </li>

            <li>
                <div class="pic">
                    <img src="./images/rocket.svg" alt="">
                </div>

                <div class="text">
                    <a href="./users/main.php" target="_blank">用户表</a>
                    <p>对用户表进行增、删、改、查. </p>
                </div>
            </li>
        </ul>
    </div>
</body>
</html>