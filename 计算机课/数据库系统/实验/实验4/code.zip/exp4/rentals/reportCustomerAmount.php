<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>租赁表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <a href="./main.php">返回</a>

    <h1>租赁信息</h1>

    <div class="center">

        <form action="#" method="post">
            <input type="text" placeholder="输入客户 id" name="customerId">
            <input class="button" type="submit" value="筛选" name="filter">
            
            <?php
                echo "<table width='800px'>";
                // 表头
                echo "<br>";
                echo "<tr>";
                echo "<th>lastName</th>";
                echo "<th>firstName</th>";
                echo "<th>manufacturer</th>";
                echo "<th>name</th>";
                echo "<th>cost</th>";
                echo "</tr>";

                $totalCost = 0;
                if (isset($_POST["filter"]) && array_key_exists("customerId", $_POST) && $_POST["customerId"] != '') {
                    $customerId = $_POST["customerId"];
                    $sql = "CALL reportCustomerAmount('$customerId')";
                    $table = mysqli_query($con, $sql) or die(mysqli_error($con));
                    $totalCost = 0;
                    if (mysqli_num_rows($table)) {
                        while ($line = mysqli_fetch_assoc($table)) {
                            $lastName = $line["lastName"];
                            $firstName = $line["firstName"];
                            $manufacturer = $line["manufacturer"];
                            $name = $line["name"];
                            $cost = $line["cost"];

                            echo "<tr>";
                            echo "<td>$lastName</td>";
                            echo "<td>$firstName</td>";
                            echo "<td>$manufacturer</td>";
                            echo "<td>$name</td>";
                            echo "<td>$cost</td>";
                            echo "</tr>";

                            $totalCost += $cost;
                        }
                    }
                }
                else {
                    echo "no data";
                }

                echo "<tr>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td>-----</td>";
                echo "</tr>";

                echo "<tr>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td></td>";
                echo "<td>$totalCost</td>";
                echo "</tr>";
                echo "</table>";
            ?>
        </form>
    </div>
</body>
</html>