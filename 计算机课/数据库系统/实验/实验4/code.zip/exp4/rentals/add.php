<?php 
    include "../conn.php";
    include "../functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加租赁</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        .add {
            margin: 50px auto;
            padding-top: 40px;

            width: 300px;
            height: 400px;
            background-color: bisque;
            text-align: center;

            border-radius: 10px;

            box-shadow: 2px 5px 10px 1px rgba(0, 0, 0, 0.5);
        }

        .add h3 {
            margin-bottom: 12px;
            font-size: 18px;
            color: midnightblue;
        }

        .add input {
            width: 180px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
            
            padding-left: 10px;
        }

        .add .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;

            padding-left: 0px;
        }

        a {
            margin-left: 10px;

            font-size: 20px;
            font-weight: 400;
            line-height: 40px;

            color: #333;

            text-decoration: none;
        }

        a:hover {
            color: blue;
        }
    </style>
</head>
<body>
    <a href="./main.php">返回</a>

    <div class="add">
        <!-- php 函数实现 -->
        <!-- <form action="./add_implement.php" method="post"> -->

        <!-- MySQL 存储过程实现 -->
        <form action="#" method="post">
            <h3>添加租赁</h3>
            <input type="text" placeholder="请输入 顾客 id" name="cid">
            <br><br>
            <input type="text" placeholder="请输入 包包 id" name="bid">
            <br><br>
            <input type="text" placeholder="请输入 借出日期" value="<?php echo getCurrentDate(); ?>" name="rentedDate">
            <br><br>
            <input type="text" placeholder="请输入 归还日期" name="returnedDate">
            <br><br>
            <input type="text" placeholder="请输入 是否购买保险" name="insurance">
            <br><br>
            <input class="button" type="submit" value="确定" name="confirm">

            <?php
                if (isset($_POST["confirm"]) && array_key_exists("cid", $_POST) 
                    && array_key_exists("bid", $_POST) && array_key_exists("rentedDate", $_POST) 
                    && array_key_exists("returnedDate", $_POST) && array_key_exists("insurance", $_POST)) {
                    $cid = $_POST["cid"];
                    $bid = $_POST["bid"];
                    $rentedDate = $_POST["rentedDate"];
                    $returnedDate = $_POST["returnedDate"];
                    $insurance = $_POST["insurance"];

                    if ($cid == null || $bid == null || $rentedDate == null || $returnedDate == null || $insurance == null) {
                        ?>
                            <script language=javascript>
                                window.alert("输入不能为空");
                                history.back(1);
                            </script>
                        <?php
                    }
                    else {
                        $sql = "CALL addRental('$cid', '$bid', '$rentedDate', '$returnedDate', '$insurance')";
                        $res = mysqli_query($con, $sql) or die(mysqli_error($con));
                        if ($res) {
                            ?>
                                <script language=javascript>
                                    window.alert("插入成功!");
                                </script>
                            <?php

                            header("Location: ./main.php");
                            exit;
                        }
                        else {
                            ?>
                                <script language=javascript>
                                    window.alert("插入失败!");
                                    history.back(1);
                                </script>
                            <?php
                        }
                    }
                }
            ?>
        </form>
    </div>
</body>
</html>