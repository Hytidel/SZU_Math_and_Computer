<?php
    $hostname = "localhost";  // 主机网址
    $database = "exp3.1";
    $username = "root";
    $password = "";
    $con = mysqli_connect($hostname, $username, $password, $database);  // 连接数据库

    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
    }
?>