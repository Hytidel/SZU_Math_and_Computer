<?php include "conn.php" ?>

<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />

    <title>查询数据库</title>

    <style>
        form {
            padding: 0px;
            margin: 0px;
        }
    </style>
</head>

<?php
    echo "---=数据库的所有条目=---<br>";
    echo "<br>";

    $sql = "select * from news ";
    $res = @mysqli_query($con, $sql);
    if (mysqli_num_rows($res) > 0) {
        while ($dbrow = mysqli_fetch_assoc($res)) {
            $id = $dbrow['id'];
            $title = $dbrow['title'];
            $content = $dbrow['content'];
            $add_time = $dbrow['add_time'];
            $content = str_replace("\r", "<br>", $content);
            $content = str_replace(" ", "&nbsp; ", $content);
            echo "编号: " . $id . "<br>";
            echo "添加日期: " . $add_time . "<br>";
            echo "新闻标题: " . $title . "<br>";
            echo "新闻内容: " . $content . "<br>";
            echo "--------------------------------";
            echo "<br>";
        }
    } else {
        echo "no data";
    }

    mysqli_close($con);
?>