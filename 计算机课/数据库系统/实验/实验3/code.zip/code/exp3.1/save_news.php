<?php include "conn.php" ?>

<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />

    <title>添加成功</title>

    <style>
        form {
            padding: 0px;
            margin: 0px;
        }
    </style>
</head>

<?php
    $title = $_POST["title"];
    $content = $_POST["content"];
    if (function_exists('date_default_timezone_set')) {
        date_default_timezone_set('UTC');
    }

    $add_time = date("Y-m-d");
    $sql = "INSERT INTO news (title,content,add_time) VALUES ('$title','$content','$add_time')";
    // echo $sql;
    $result = @mysqli_query($con, $sql);

    if ($result) {
        echo "添加成功, <a href='add_news.php'>返回</a> .";
    } else {
        echo "添加失败, <a href='add_news.php'>返回</a> .";
    }
?>