<?php include "conn.php" ?>

<html>
    <head>
        <title>修改新闻</title>

        <style>
            form {
                padding: 0px;
                margin: 0px;
            }
        </style>
    </head>

    <body>
        <?php
            $id = $_GET["id"];
            $sql = "select * from news where id=$id";
            $res = @mysqli_query($con, $sql);

            $dbrow = mysqli_fetch_assoc($res);
            $id = $dbrow['id'];
            $title = $dbrow['title'];
            $content = $dbrow['content'];
            $add_time = $dbrow['add_time'];
        ?>
        
        <table width="70%" height="30" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
                <td align="center">修改新闻</td>
            </tr>
        </table>

        <form action="save_edit_news.php" method="post">
            <table width="70%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="30%" align="right">新闻标题: </td>
                    <td width="70%" align="left"><input type="text" name="title" size="30" value="<?php echo $title; ?>" />
                    </td>
                </tr>

                <tr>
                    <td align="right">新闻内容: </td>
                    <td align="left"><textarea name="content" cols="30" rows="5"><?php echo $content; ?></textarea></td>
                </tr>
            </table>

            <table width="70%" height="30" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                    <td align="center"> <input type="hidden" name="id" value="<?php echo $id; ?>" />
                        <input type="submit" name="submit1" value="确认修改" />
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>