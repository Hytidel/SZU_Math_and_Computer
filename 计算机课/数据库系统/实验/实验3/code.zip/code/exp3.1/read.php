<?php include "conn.php" ?>

<?php
    $sql = "select * from news where id = 1";
    $res = @mysqli_query($con, $sql);
    $row = @mysqli_fetch_array($res, MYSQLI_ASSOC);

    if ($row) {
        $id = $row['id'];
        $title = $row['title'];
        $content = $row['content'];
        $add_time = $row['add_time'];
        echo "ID: " . $id . "<br>";
        echo "Title: " . $title . "<br>";
        echo "Timestamp: " . $add_time;
        echo "<br>";
    } else {
        echo "no data";
    }
?>