<?php include "conn.php" ?>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />

    <title>修改成功</title>

    <style>
        form {
            padding: 0px;
            margin: 0px;
        }
    </style>
</head>


<?php
    $id = $_POST["id"];
    $title = $_POST["title"];
    $content = $_POST["content"];
    $sql = "Update news set title='$title', content='$content' where id=$id";
    $res = @mysqli_query($con, $sql);
    if (mysqli_affected_rows($con) > 0) {
        ?>
        <script language=javascript>window.alert('修改成功'); history.back(1);</script>
        <?php
    } else {
        ?>
        <script language=javascript>window.alert('修改失败'); history.back(1);</script>
        <?php
    }
?>