<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>订单表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <h1>订单信息</h1>

    <div class="center">
        <form action="./add.html" method="post">
            <input class="button" type="submit" value="新增">
        </form>

        <br>

        <form action="" method="post">
            <input type="text" placeholder="查找关键词(不区分大小写)" name="word">
            <input class="button" type="submit" value="查找" name="search">
        </form>
    </div>

    <table width="800px">
        <tr>
            <th>purid</th>
            <th>cid</th>
            <th>eid</th>
            <th>pid</th>
            <th>qty</th>
            <th>ptime</th>
            <th>total_price</th>
            <th>操作</th>
        </tr>

        <?php
            if (empty($_POST["search"])) {
                $sql = "SELECT * FROM purchases ORDER BY purid";
            }
            else {
                $word = $_POST["word"];
                $sql = "SELECT * FROM purchases WHERE 
                    purid LIKE '%$word%' OR 
                    cid LIKE '%$word%' OR 
                    eid LIKE '%$word%' OR 
                    pid LIKE '%$word%' OR 
                    qty LIKE '%$word%' OR 
                    ptime LIKE '%$word%' OR 
                    total_price LIKE '%$word%'
                    ";
            }
            $res = mysqli_query($con, $sql);
            
            if (mysqli_num_rows($res)) {
                while ($line = mysqli_fetch_assoc($res)) {
                    $purid = $line["purid"];
                    $cid = $line["cid"];
                    $eid = $line["eid"];
                    $pid = $line["pid"];
                    $qty = $line["qty"];
                    $ptime = $line["ptime"];
                    $total_price = $line["total_price"];

                    echo "<tr>";
                    echo "<td>$purid</td>
                        <td>$cid</td>
                        <td>$eid</td>
                        <td>$pid</td>
                        <td>$qty</td>
                        <td>$ptime</td>
                        <td>$total_price</td>
                        <td>
                            <form action='./modify.php?purid=$purid' method='post'>
                                <input class='button' type='submit' value='修改'>
                            </form>

                            <form action='./delete_implement.php?purid=$purid' method='post'>
                                <input class='button' type='submit' value='删除'>
                            </form>
                        </td>
                        ";
                    echo "</tr>";
                }
            }
            else {
                echo "no data";
            }

            mysqli_close($con);
        ?>
    </table>
</body>
</html>