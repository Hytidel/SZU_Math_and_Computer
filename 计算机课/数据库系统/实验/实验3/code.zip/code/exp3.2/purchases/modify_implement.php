<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改订单</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $purid = $_POST["purid"];
        $cid= $_POST["cid"];
        $eid= $_POST["eid"];
        $pid= $_POST["pid"];
        $qty= $_POST["qty"];
        $ptime = $_POST["ptime"];
        $total_price = $_POST["total_price"];

        if ($purid == null || $cid == null || $eid == null || $pid == null || $qty == null || $ptime == null || $total_price == null) {
            ?>
                <script language=javascript>
                    window.alert("输入不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            $sql = "UPDATE purchases SET cid='$cid', eid='$eid', pid='$pid', qty='$qty', ptime='$ptime', total_price='$total_price' WHERE purid='$purid'";
            $res = mysqli_query($con, $sql);
            if ($res) {
                if (function_exists('date_default_timezone_set')) {
                    date_default_timezone_set('UTC');
                }
                $time = date("y-m-d h:m:s");
                $key_value = '(' . $purid . ', ' . $cid . ', ' . $eid . ', ' . $pid . ', ' . $qty . ', ' . $ptime . ', ' . $total_price . ')';
                $key_value = mysqli_real_escape_string($con, $key_value);
                $sql = "INSERT INTO logs(who, time, table_name, operation, key_value) VALUES ('admin', '$time', 'purchases', 'modify', '" . $key_value . "')";
                $res = mysqli_query($con, $sql);

                ?>
                    <script language=javascript>
                        window.alert("修改成功!");
                    </script>
                <?php

                header("Location: ./main.php");
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("修改失败!");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>