<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改订单</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        .add {
            margin: 50px auto;
            padding-top: 40px;

            width: 300px;
            height: 500px;
            background-color: bisque;
            text-align: center;

            border-radius: 10px;

            box-shadow: 2px 5px 10px 1px rgba(0, 0, 0, 0.5);
        }

        .add h3 {
            margin-bottom: 12px;
            font-size: 18px;
            color: midnightblue;
        }

        .add input {
            width: 180px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
            
            padding-left: 10px;
        }

        .add .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;

            padding-left: 0px;
        }

        a {
            margin-left: 10px;

            font-size: 20px;
            font-weight: 400;
            line-height: 40px;

            color: #333;

            text-decoration: none;
        }

        a:hover {
            color: blue;
        }
    </style>
</head>
<body>
    <a href="./main.php">返回</a>

    <?php 
        $purid = $_GET["purid"];
        $sql = "SELECT * FROM purchases WHERE purid='$purid'";
        $res = mysqli_query($con, $sql);

        $line = mysqli_fetch_assoc($res);
        $cid = $line["cid"];
        $eid = $line["eid"];
        $pid = $line["pid"];
        $qty = $line["qty"];
        $ptime = $line["ptime"];
        $total_price = $line["total_price"];
    ?>

    <div class="add">
        <form action="./modify_implement.php" method="post">
            <h3>修改订单</h3>
            <input type="text" readonly=true placeholder="请输入 purid" value="<?php echo $purid; ?>" name="purid">
            <br><br>
            <input type="text" placeholder="请输入 cid" value="<?php echo $cid; ?>" name="cid">
            <br><br>
            <input type="text" placeholder="请输入 eid" value="<?php echo $eid; ?>" name="eid">
            <br><br>
            <input type="text" placeholder="请输入 pid" value="<?php echo $pid; ?>" name="pid">
            <br><br>
            <input type="text" placeholder="请输入 qty" value="<?php echo $qty; ?>" name="qty">
            <br><br>
            <input type="text" placeholder="请输入 ptime" value="<?php echo $ptime; ?>" name="ptime">
            <br><br>
            <input type="text" placeholder="请输入 total_price" value="<?php echo $total_price; ?>" name="total_price">
            <br><br>
            <input class="button" type="submit" value="确定" name="confirm">
        </form>
    </div>
</body>
</html>