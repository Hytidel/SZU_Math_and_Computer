<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改订单</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $pid = $_POST["pid"];
        $pname= $_POST["pname"];
        $qoh= $_POST["qoh"];
        $qoh_threshold= $_POST["qoh_threshold"];
        $original_price= $_POST["original_price"];
        $discnt_rate = $_POST["discnt_rate"];
        $sid = $_POST["sid"];

        if ($pid == null || $pname == null || $qoh == null || $qoh_threshold == null || $original_price == null || $discnt_rate == null || $sid == null) {
            ?>
                <script language=javascript>
                    window.alert("输入不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            $sql = "UPDATE products SET pname='$pname', qoh='$qoh', qoh_threshold='$qoh_threshold', original_price='$original_price', 
                discnt_rate='$discnt_rate', sid='$sid' WHERE pid='$pid'";
            $res = mysqli_query($con, $sql);
            if ($res) {
                if (function_exists('date_default_timezone_set')) {
                    date_default_timezone_set('UTC');
                }
                $time = date("y-m-d h:m:s");
                $key_value = '(' . $pid . ', ' . $pname . ', ' . $qoh . ', ' . $qoh_threshold . ', ' . $original_price . ', ' . $discnt_rate . ', ' . $sid . ')';
                $key_value = mysqli_real_escape_string($con, $key_value);
                $sql = "INSERT INTO logs(who, time, table_name, operation, key_value) VALUES ('admin', '$time', 'products', 'modify', '" . $key_value . "')";
                $res = mysqli_query($con, $sql);

                ?>
                    <script language=javascript>
                        window.alert("修改成功!");
                    </script>
                <?php

                header("Location: ./main.php");
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("修改失败!");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>