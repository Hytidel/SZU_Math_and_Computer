<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改产品</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        .add {
            margin: 50px auto;
            padding-top: 40px;

            width: 300px;
            height: 500px;
            background-color: bisque;
            text-align: center;

            border-radius: 10px;

            box-shadow: 2px 5px 10px 1px rgba(0, 0, 0, 0.5);
        }

        .add h3 {
            margin-bottom: 12px;
            font-size: 18px;
            color: midnightblue;
        }

        .add input {
            width: 180px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
            
            padding-left: 10px;
        }

        .add .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;

            padding-left: 0px;
        }

        a {
            margin-left: 10px;

            font-size: 20px;
            font-weight: 400;
            line-height: 40px;

            color: #333;

            text-decoration: none;
        }

        a:hover {
            color: blue;
        }
    </style>
</head>
<body>
    <a href="./main.php">返回</a>

    <?php 
        $pid = $_GET["pid"];
        $sql = "SELECT * FROM products WHERE pid='$pid'";
        $res = mysqli_query($con, $sql);

        $line = mysqli_fetch_assoc($res);
        $pname = $line["pname"];
        $qoh = $line["qoh"];
        $qoh_threshold = $line["qoh_threshold"];
        $original_price = $line["original_price"];
        $discnt_rate = $line["discnt_rate"];
        $sid = $line["sid"];
    ?>

    <div class="add">
        <form action="./modify_implement.php" method="post">
            <h3>修改产品</h3>
            <input type="text" readonly=true placeholder="请输入 pid" value="<?php echo $pid; ?>" name="pid">
            <br><br>
            <input type="text" placeholder="请输入 pname" value="<?php echo $pname; ?>" name="pname">
            <br><br>
            <input type="text" placeholder="请输入 qoh" value="<?php echo $qoh; ?>" name="qoh">
            <br><br>
            <input type="text" placeholder="请输入 qoh_threshold" value="<?php echo $qoh_threshold; ?>" name="qoh_threshold">
            <br><br>
            <input type="text" placeholder="请输入 original_price" value="<?php echo $original_price; ?>" name="original_price">
            <br><br>
            <input type="text" placeholder="请输入 discnt_rate" value="<?php echo $discnt_rate; ?>" name="discnt_rate">
            <br><br>
            <input type="text" placeholder="请输入 sid" value="<?php echo $sid; ?>" name="sid">
            <br><br>
            <input class="button" type="submit" value="确定" name="confirm">
        </form>
    </div>
</body>
</html>