<?php include "conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $username = $_POST["username"];
        $password = $_POST["password"];

        if ($username == null || $password == null) {
            ?>
                <script language=javascript>
                    window.alert("账号、密码不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            $sql = 'SELECT * FROM users WHERE username='."'{$username}' AND password="."'{$password}';";
            $res = mysqli_query($con, $sql);
            if (mysqli_num_rows($res) > 0) {
                // 在 header() 前的输出无效
                header("Location: ./index.html");
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("账号或密码错误");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>