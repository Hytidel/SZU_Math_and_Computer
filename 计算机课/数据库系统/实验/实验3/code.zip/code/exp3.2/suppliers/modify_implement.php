<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改供应商</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $sid = $_POST["sid"];
        $sname= $_POST["sname"];
        $city= $_POST["city"];
        $telephone_no= $_POST["telephone_no"];

        if ($sid == null || $sname == null || $city == null || $telephone_no == null) {
            ?>
                <script language=javascript>
                    window.alert("输入不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            $sql = "UPDATE suppliers SET sname='$sname', city='$city', telephone_no='$telephone_no' WHERE sid='$sid'";
            $res = mysqli_query($con, $sql);
            if ($res) {
                if (function_exists('date_default_timezone_set')) {
                    date_default_timezone_set('UTC');
                }
                $time = date("y-m-d h:m:s");
                $key_value = '(' . $sid . ', ' . $sname . ', ' . $city . ', ' . $telephone_no . ')';
                $key_value = mysqli_real_escape_string($con, $key_value);
                $sql = "INSERT INTO logs(who, time, table_name, operation, key_value) VALUES ('admin', '$time', 'suppliers', 'modify', '" . $key_value . "')";
                $res = mysqli_query($con, $sql);

                ?>
                    <script language=javascript>
                        window.alert("修改成功!");
                    </script>
                <?php

                header("Location: ./main.php");
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("修改失败!");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>