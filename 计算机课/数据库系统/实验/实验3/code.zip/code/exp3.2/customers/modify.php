<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改顾客</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        .add {
            margin: 50px auto;
            padding-top: 40px;

            width: 300px;
            height: 400px;
            background-color: bisque;
            text-align: center;

            border-radius: 10px;

            box-shadow: 2px 5px 10px 1px rgba(0, 0, 0, 0.5);
        }

        .add h3 {
            margin-bottom: 12px;
            font-size: 18px;
            color: midnightblue;
        }

        .add input {
            width: 180px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
            
            padding-left: 10px;
        }

        .add .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;

            padding-left: 0px;
        }

        a {
            margin-left: 10px;

            font-size: 20px;
            font-weight: 400;
            line-height: 40px;

            color: #333;

            text-decoration: none;
        }

        a:hover {
            color: blue;
        }
    </style>
</head>
<body>
    <a href="./main.php">返回</a>

    <?php 
        $cid = $_GET["cid"];
        $sql = "SELECT * FROM customers WHERE cid='$cid'";
        $res = mysqli_query($con, $sql);

        $line = mysqli_fetch_assoc($res);
        $cname = $line["cname"];
        $city = $line["city"];
        $visits_made = $line["visits_made"];
        $last_visit_time = $line["last_visit_time"];
    ?>

    <div class="add">
        <form action="./modify_implement.php" method="post">
            <h3>修改顾客</h3>
            <input type="text" readonly=true placeholder="请输入 cid" value="<?php echo $cid; ?>" name="cid">
            <br><br>
            <input type="text" placeholder="请输入 cname" value="<?php echo $cname; ?>" name="cname">
            <br><br>
            <input type="text" placeholder="请输入 city" value="<?php echo $city; ?>" name="city">
            <br><br>
            <input type="text" placeholder="请输入 visits_made" value="<?php echo $visits_made; ?>" name="visits_made">
            <br><br>
            <input type="text" placeholder="YYYY-MM-DD HH:MM:SS" value="<?php echo $last_visit_time; ?>" name="last_visit_time">
            <br><br>
            <input class="button" type="submit" value="确定" name="confirm">
        </form>
    </div>
</body>
</html>