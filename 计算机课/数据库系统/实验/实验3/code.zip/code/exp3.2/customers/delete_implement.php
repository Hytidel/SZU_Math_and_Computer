<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>删除顾客</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $cid = $_GET["cid"];
        $sql = "DELETE FROM customers WHERE cid='$cid'";
        $res = mysqli_query($con, $sql);
        if ($res) {
            if (function_exists('date_default_timezone_set')) {
                date_default_timezone_set('UTC');
            }
            $time = date("y-m-d h:m:s");
            $key_value = '(' . $cid . ')';
            $key_value = mysqli_real_escape_string($con, $key_value);
            $sql = "INSERT INTO logs(who, time, table_name, operation, key_value) VALUES ('admin', '$time', 'customers', 'delete', '" . $key_value . "')";
            $res = mysqli_query($con, $sql);

            ?>
                <script language=javascript>
                    window.alert("删除成功!");
                </script>
            <?php

            header("Location: ./main.php");
            exit;
        }
        else {
            ?>
                <script language=javascript>
                    window.alert("删除失败!");
                    history.back(1);
                </script>
            <?php
        }

        mysqli_close($con);
    ?>
</body>
</html>