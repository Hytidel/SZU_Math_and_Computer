<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $cid = $_POST["cid"];
        $cname= $_POST["cname"];
        $city= $_POST["city"];
        $visits_made= $_POST["visits_made"];
        $last_visit_time= $_POST["last_visit_time"];

        if ($cid == null || $cname == null || $city == null || $visits_made == null || $last_visit_time == null) {
            ?>
                <script language=javascript>
                    window.alert("输入不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            $sql = "INSERT INTO customers VALUES ('$cid', '$cname', '$city', '$visits_made', '$last_visit_time')";
            $res = mysqli_query($con, $sql);
            if ($res) {
                if (function_exists('date_default_timezone_set')) {
                    date_default_timezone_set('UTC');
                }
                $time = date("y-m-d h:m:s");
                $key_value = '(' . $cid . ', ' . $cname . ', ' . $city . ', ' . $visits_made . ', ' . $last_visit_time . ')';
                $key_value = mysqli_real_escape_string($con, $key_value);
                $sql = "INSERT INTO logs(who, time, table_name, operation, key_value) VALUES ('admin', '$time', 'customers', 'insert', '" . $key_value . "')";
                $res = mysqli_query($con, $sql);

                ?>
                    <script language=javascript>
                        window.alert("插入成功!");
                    </script>
                <?php

                header("Location: ./main.php");
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("插入失败!");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>