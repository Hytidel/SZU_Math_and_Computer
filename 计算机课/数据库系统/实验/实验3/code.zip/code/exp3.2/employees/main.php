<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>雇员表</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin-top: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;

            font-size: 30px;
            color: #333;
        }

        .center {
            margin: 10px auto;
            text-align: center;
        }

        .center .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
        }

        table {
            margin: 0 auto;
            margin-top: 10px;
            border: 2px solid #333;
        }

        form {
            display: inline;
        }
    </style>
</head>
<body>
    <h1>雇员信息</h1>

    <div class="center">
        <form action="./add.html" method="post">
            <input class="button" type="submit" value="新增">
        </form>

        <br>

        <form action="" method="post">
            <input type="text" placeholder="查找关键词(不区分大小写)" name="word">
            <input class="button" type="submit" value="查找" name="search">
        </form>
    </div>

    <table width="800px">
        <tr>
            <th>eid</th>
            <th>ename</th>
            <th>city</th>
            <th>操作</th>
        </tr>

        <?php
            if (empty($_POST["search"])) {
                $sql = "SELECT * FROM employees ORDER BY eid";
            }
            else {
                $word = $_POST["word"];
                $sql = "SELECT * FROM employees WHERE 
                    eid LIKE '%$word%' OR 
                    ename LIKE '%$word%' OR 
                    city LIKE '%$word%'
                    ";
            }
            $res = mysqli_query($con, $sql);
            
            if (mysqli_num_rows($res)) {
                while ($line = mysqli_fetch_assoc($res)) {
                    $eid = $line["eid"];
                    $ename = $line["ename"];
                    $city = $line["city"];

                    echo "<tr>";
                    echo "<td>$eid</td>
                        <td>$ename</td>
                        <td>$city</td>
                        <td>
                            <form action='./modify.php?eid=$eid' method='post'>
                                <input class='button' type='submit' value='修改'>
                            </form>

                            <form action='./delete_implement.php?eid=$eid' method='post'>
                                <input class='button' type='submit' value='删除'>
                            </form>
                        </td>
                        ";
                    echo "</tr>";
                }
            }
            else {
                echo "no data";
            }

            mysqli_close($con);
        ?>
    </table>
</body>
</html>