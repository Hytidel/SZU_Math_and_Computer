<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改日志</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        .add {
            margin: 50px auto;
            padding-top: 40px;

            width: 300px;
            height: 450px;
            background-color: bisque;
            text-align: center;

            border-radius: 10px;

            box-shadow: 2px 5px 10px 1px rgba(0, 0, 0, 0.5);
        }

        .add h3 {
            margin-bottom: 12px;
            font-size: 18px;
            color: midnightblue;
        }

        .add input {
            width: 180px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;
            
            padding-left: 10px;
        }

        .add .button {
            width: 40px;
            height: 30px;
            font-size: 15px;
            line-height: 30px;

            padding-left: 0px;
        }

        a {
            margin-left: 10px;

            font-size: 20px;
            font-weight: 400;
            line-height: 40px;

            color: #333;

            text-decoration: none;
        }

        a:hover {
            color: blue;
        }
    </style>
</head>
<body>
    <a href="./main.php">返回</a>

    <?php 
        $logid = $_GET["logid"];
        $sql = "SELECT * FROM logs WHERE logid='$logid'";
        $res = mysqli_query($con, $sql);

        $line = mysqli_fetch_assoc($res);
        $who = $line["who"];
        $time = $line["time"];
        $table_name = $line["table_name"];
        $operation = $line["operation"];
        $key_value = $line["key_value"];
    ?>

    <div class="add">
        <form action="./modify_implement.php" method="post">
            <h3>修改日志</h3>
            <input type="text" readonly=true placeholder="请输入 logid" value="<?php echo $logid; ?>" name="logid">
            <br><br>
            <input type="text" placeholder="请输入 who" value="<?php echo $who; ?>" name="who">
            <br><br>
            <input type="text" placeholder="请输入 time" value="<?php echo $time; ?>" name="time">
            <br><br>
            <input type="text" placeholder="请输入 table_name" value="<?php echo $table_name; ?>" name="table_name">
            <br><br>
            <input type="text" placeholder="请输入 operation" value="<?php echo $operation; ?>" name="operation">
            <br><br>
            <input type="text" placeholder="请输入 key_value" value="<?php echo $key_value; ?>" name="key_value">
            <br><br>
            <input class="button" type="submit" value="确定" name="confirm">
        </form>
    </div>
</body>
</html>