<?php include "../conn.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改日志</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: #f1f1f1;
        }

        
    </style>
</head>
<body>
    <?php
        $logid = $_POST["logid"];
        $who= $_POST["who"];
        $time= $_POST["time"];
        $table_name= $_POST["table_name"];
        $operation= $_POST["operation"];
        $key_value = $_POST["key_value"];

        if ($logid == null || $who == null || $time == null || $table_name == null || $operation == null || $key_value == null) {
            ?>
                <script language=javascript>
                    window.alert("输入不能为空");
                    history.back(1);
                </script>
            <?php
        }
        else {
            $sql = "UPDATE logs SET who='$who', time='$time', table_name='$table_name', operation='$operation', 
                key_value='$key_value' WHERE logid='$logid'";
            $res = mysqli_query($con, $sql);
            if ($res) {
                ?>
                    <script language=javascript>
                        window.alert("修改成功!");
                    </script>
                <?php

                header("Location: ./main.php");
                exit;
            }
            else {
                ?>
                    <script language=javascript>
                        window.alert("修改失败!");
                        history.back(1);
                    </script>
                <?php
            }
        }

        mysqli_close($con);
    ?>
</body>
</html>