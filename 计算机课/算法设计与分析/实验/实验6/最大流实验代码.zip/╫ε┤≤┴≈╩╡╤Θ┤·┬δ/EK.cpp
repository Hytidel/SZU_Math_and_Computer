#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define CaseT int CaseT; cin >> CaseT; while(CaseT--)
#define endl '\n'
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
const int INF = 0x3f3f3f3f;

struct EKMaximumFlow {
    int n, m;  // 节点数、边数
    int S, T;  // 源点、汇点
    vector<int> head, edge, capa, nxt;  // capa[i]表示边i的容量
    int idx;  // 当前用到的边的编号
    vector<int> minCapa;  // minCapa[i]表示到节点i的所有边的容量的最小值
    vector<int> pre;  // pre[i]表示节点i的前驱边的编号
    vector<bool> vis;

    EKMaximumFlow(int _n, int _m, int _S, int _T) 
        :n(_n), m(_m), S(_S), T(_T), idx(0), 
        head(n + 5, -1), edge(2 * (m + 5)), capa(2 * (m + 5)), nxt(2 * (m + 5)), 
        minCapa(n + 5), pre(n + 5), vis(n + 5) {
        // build();
    }

    void add(int x, int y, int z) {  // 建边x -> y, 容量为z
        edge[idx] = y, capa[idx] = z, nxt[idx] = head[x], head[x] = idx++;  // 正向边
        edge[idx] = x, capa[idx] = 0, nxt[idx] = head[y], head[x = y] = idx++;  // 反向边, 流量初始为0
    }

    void build() {  // 构建流网络

    }

    bool bfs() {  // 返回是否找到增广路
        fill(all(vis), false);

        queue<int> que;
        que.push(S);
        vis[S] = true, minCapa[S] = INF;  // 初始时未经过边

        while (que.size()) {
            int u = que.front(); que.pop();
            for (int i = head[u]; ~i; i = nxt[i]) {
                int v = edge[i];
                if (!vis[v] && capa[i]) {  // 节点未遍历过且边还有容量
                    vis[v] = true;
                    minCapa[v] = min(minCapa[u], capa[i]);
                    pre[v] = i;  // 记录前驱边的编号

                    if (v == T) return true;  // 存在增广路
                    que.push(v);
                }
            }
        }
        return false;  // 不存在增广路
    }

    ll ek() {
        ll res = 0;
        while (bfs()) {  // 存在增广路
            res += minCapa[T];
            for (int i = T; i != S; i = edge[pre[i] ^ 1]) {  // 更新残量网络
                capa[pre[i]] -= minCapa[T];  // 正向边减容量
                capa[pre[i] ^ 1] += minCapa[T];  // 反向边加容量
            }
        }
        return res;
    }
};

void solve() {
    int n, m, a, b; cin >> n >> m;

    for (int a = 1; a <= 3; a++) {
        for (int b = 1; b <= 10; b++) {
            cout << "[a, b]" << ' ' << a << ' ' << b << endl;

            int S = n + m + 1, T = n + m + 2;
            EKMaximumFlow solver(n + m + 2, n * m + n + m, S, T);
            for (int i = 1; i <= n; i++)
                solver.add(S, i, b);  // 源点向评审节点连边
            for (int i = 1; i <= n; i++)
                solver.add(i, i + n, 1);  // 评审节点向论文节点连边
            for (int i = n + 1; i <= n + m; i++)
                solver.add(i, T, a);  // 论文节点向汇点连边
            cout << solver.ek() << endl;

            cout << endl;
        }
    }
}

int main() {
    cin.tie(0)->sync_with_stdio(false);
    // init();
    // CaseT
    solve();
    return 0;
}