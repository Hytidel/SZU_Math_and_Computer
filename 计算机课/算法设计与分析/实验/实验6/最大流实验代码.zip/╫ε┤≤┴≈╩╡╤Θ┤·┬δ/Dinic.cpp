#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define CaseT int CaseT; cin >> CaseT; while(CaseT--)
#define endl '\n'
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
const int INF = 0x3f3f3f3f;

struct DinicMaximumFlow {
    int n, m;  // 节点数、边数
    int S, T;  // 源点、汇点
    vector<int> head, edge, capa, nxt;  // capa[i]表示边i的容量
    int idx;  // 当前用到的边的编号
    vector<int> minCapa;  // minCapa[i]表示到节点i的所有边的容量的最小值
    vector<int> level;  // level[i]表示节点i在分层图中的层数
    vector<int> cur;  // cur[i]表示节点i的当前弧

    DinicMaximumFlow(int _n, int _m, int _S, int _T) 
        :n(_n), m(_m), S(_S), T(_T), idx(0), 
        head(n + 5, -1), edge(2 * (m + 5)), capa(2 * (m + 5)), nxt(2 * (m + 5)), 
        minCapa(n + 5), level(n + 5), cur(n + 5) {
        // build();
    }

    void add(int x, int y, int z) {  // 建边x -> y, 容量为z
        edge[idx] = y, capa[idx] = z, nxt[idx] = head[x], head[x] = idx++;  // 正向边
        edge[idx] = x, capa[idx] = 0, nxt[idx] = head[y], head[x = y] = idx++;  // 反向边, 流量初始为0
    }

    void build() {  // 构建流网络
        
    }

    bool bfs() {  // 返回是否找到增广路
        fill(all(level), -1);

        queue<int> que;
        que.push(S);
        level[S] = 0;  // 源点的层数为0
        cur[S] = head[S];  // 记录当前弧

        while (que.size()) {
            int u = que.front(); que.pop();
            for (int i = head[u]; ~i; i = nxt[i]) {
                int v = edge[i];
                if (level[v] == -1 && capa[i]) {  // 节点未遍历过且边还有容量
                    level[v] = level[u] + 1;
                    cur[v] = head[v];  // 更新当前弧

                    if (v == T) return true;  // 存在增广路
                    que.push(v);
                }
            }
        }
        return false;  // 不存在增广路
    }

    int find(int u, int lim) {  // 从节点u开始增广, 流量限制为lim
        if (u == T) return lim;  // 到达汇点

        int flow = 0;  // 总流量
        for (int i = cur[u]; ~i && flow <= lim; i = nxt[i]) {  // 从当前弧开始增广, 流量不超过限制
            cur[u] = i;  // 更新当前弧
            int v = edge[i];
            if (level[v] == level[u] + 1 && capa[i]) {  // 节点v在u的下一层, 且边还有容量
                ll tmp = find(v, min(capa[i], lim - flow));  // 递归增广v
                if (!tmp) level[v] = -1;  // 节点v无法到达汇点, 将其删去, 通过将层数置为-1实现

                capa[i] -= tmp, capa[i ^ 1] += tmp, flow += tmp;
            }
        }
        return flow;
    }

    ll dinic() {
        ll res = 0;
        for (ll flow; bfs(); ) {
            while (flow = find(S, INF))
                res += flow;
        }
        return res;
    }
};

void solve() {
    int n, m, S, T; cin >> n >> m >> S >> T;

    for (int a = 1; a <= 3; a++) {
        for (int b = 1; b <= 10; b++) {
            cout << "[a, b]" << ' ' << a << ' ' << b << endl;

            int S = n + m + 1, T = n + m + 2;
            DinicMaximumFlow solver(n + m + 2, n * m + n + m, S, T);
            for (int i = 1; i <= n; i++)
                solver.add(S, i, b);  // 源点向评审节点连边
            for (int i = 1; i <= n; i++)
                solver.add(i, i + n, 1);  // 评审节点向论文节点连边
            for (int i = n + 1; i <= n + m; i++)
                solver.add(i, T, a);  // 论文节点向汇点连边
            cout << solver.dinic() << endl;

            cout << endl;
        }
    }
}

int main() {
    cin.tie(0)->sync_with_stdio(false);
    // init();
    // CaseT
    solve();
    return 0;
}