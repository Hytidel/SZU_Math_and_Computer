#include <bits/stdc++.h>
using namespace std;

int n = 10;
int a[] = { 8, 6, 3, 7, 1, 0, 9, 4, 5, 2 };
string before = "Before sort the array is:\n";
string after = "After sort the array is:\n";

void swap(int& a, int& b) {
    int tmp = a;
    a = b;
    b = tmp;
}

void bubbleSort() {
    for (int i = 0; i < n; i++) {
        for (int j = i - 1; j >= 0; j--) 
            if (a[j] > a[j + 1]) swap(a[j], a[j + 1]);
    }
}

int main() {
    cout << before;
    for (int i = 0; i < n; i++) cout << a[i] << '\n';

    bubbleSort();

    cout << after;
    for (int i = 0; i < n; i++) cout << a[i] << '\n';
    return 0;
}