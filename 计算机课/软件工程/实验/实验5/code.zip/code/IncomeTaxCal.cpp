#include <bits/stdc++.h>
using namespace std;

struct Person {
    int children_Num;
    int is_KeepStu;
    bool HouseLoans;
    int is_RentHouse;
    bool SupportingElderly;
    int sibling_Num;

    Person(int _children_Num, int _is_KeepStu, bool _HouseLoan, 
        int _is_RentHouse, bool _SupportingElderly, int _sibling_Num)
        : children_Num(_children_Num), is_KeepStu(_is_KeepStu), HouseLoans(_HouseLoan), 
        is_RentHouse(_is_RentHouse), SupportingElderly(_SupportingElderly), sibling_Num(_sibling_Num) {}
};

struct incomeTaxCalculator {
    static int cal(Person person, int salary) {
        // 省略安全性检查

        //应纳税所得额 = 月度收入 - 5000 元(免征额) - 专项扣除(三险一金等) - 专项附加扣除 - 依法确定的其他扣除
        int res = salary - 5000;

        //子女教育: 每个子女每月 1000 元
        if (person.children_Num > 0) res -= person.children_Num * 1000;

        //继续教育: 在学历(学位)教育期间每月 400 元, 在取得相关证书的当年, 按照 3600 元定额扣除
        if (person.is_KeepStu == 1) res -= 400;
        else if (person.is_KeepStu == 2) res -= 3600;

        //住房贷款: 在实际发生贷款利息的年度按每月 1000 元扣除
        if (person.HouseLoans) res -= 1000;

        // 住房租金: 
        // 1. 直辖市、省会(首府)城市: 每月 1500 元
        // 2. 市辖区户籍人口超过 100 万的城市: 每月 1100 元
        // 3. 市辖区户籍人口不超过 100 万的城市: 每月 800 元
        if (person.is_RentHouse == 1) res -= 1500;
        else if (person.is_RentHouse == 2) res -= 1100;
        else if (person.is_RentHouse == 3) res -= 800;

        // 赡养老人: 每个月扣除 2000 元 / (兄弟姐妹个数 + 1) 
        if (person.SupportingElderly) res -= 2000 / (person.sibling_Num + 1);

        // 计算个人所得税: 个人所得税 = 应纳税所得额 * 税率
        double tax = res;
        if (res < 0) tax = 0;
        else if (res < 3000) tax = res * 0.03;  // 0 ~ 3000 元, 税率 3%
        else if (res < 12000) tax = 90 + (res - 3000) * 0.1;  // 3000 ~ 12000 元, 税率 10%
        else if (res < 25000) tax = 2290 + (res - 12000) * 0.2;  // 12000 ~ 25000 元, 税率 20%
        else if (res < 35000) tax = 4890 + (res - 25000) * 0.25;  // 25000 ~ 35000 元, 税率 25%
        else if (res < 55000) tax = 7390 + (res - 35000) * 0.3;  // 35000 ~ 55000 元, 税率 30%
        else if (res < 80000) tax = 13390 + (res - 55000) * 0.35;  // 55000 ~ 80000 元, 税率 35%
        else tax = 22140 + (res - 80000) * 0.45;  // > 80000 元, 税率 40%
        return (int)tax;
    }
};

int test(int children_Num, int is_KeepStu, bool HouseLoan, int is_RentHouse, bool SupportingElderly, int sibling_Num, int salary) {
    Person person(children_Num, is_KeepStu, HouseLoan, is_RentHouse, SupportingElderly, sibling_Num);
    return incomeTaxCalculator::cal(person, salary);
}

int main() {
    // 个人所得税
    // cout << test(0, 0, 0, 0, 0, 0, 3000) << '\n';  // test03
    // cout << test(0, 0, 0, 0, 0, 0, 6000) << '\n';  // test04
    // cout << test(0, 0, 0, 0, 0, 0, 15000) << '\n';  // test05
    // cout << test(0, 0, 0, 0, 0, 0, 20000) << '\n';  // test06
    // cout << test(0, 0, 0, 0, 0, 0, 30000) << '\n';  // test07
    // cout << test(0, 0, 0, 0, 0, 0, 40000) << '\n';  // test08
    // cout << test(0, 0, 0, 0, 0, 0, 60000) << '\n';  // test09
    // cout << test(0, 0, 0, 0, 0, 0, 100000) << '\n';  // test10

    // 有无孩子
    // cout << test(0, 0, 0, 0, 0, 0, 10000) << '\n';  // test01
    // cout << test(1, 0, 0, 0, 0, 0, 10000) << '\n';  // test02
    // cout << test(2, 0, 0, 0, 0, 0, 10000) << '\n';  // test03

    // 有无接受继续教育
    // cout << test(0, 0, 0, 0, 0, 0, 10000) << '\n';  // test01
    // cout << test(0, 1, 0, 0, 0, 0, 10000) << '\n';  // test02

    // 有无住房贷款
    // cout << test(0, 0, 0, 0, 0, 0, 10000) << '\n';  // test01
    // cout << test(0, 0, 1, 0, 0, 0, 10000) << '\n';  // test02

    // 有无租房
    // cout << test(0, 0, 0, 0, 0, 0, 10000) << '\n';  // test01
    // cout << test(0, 0, 0, 1, 0, 0, 10000) << '\n';  // test02
    // cout << test(0, 0, 0, 2, 0, 0, 10000) << '\n';  // test03
    // cout << test(0, 0, 0, 3, 0, 0, 10000) << '\n';  // test04

    // 有无赡养老人
    cout << test(0, 0, 0, 0, 0, 0, 10000) << '\n';  // test01
    cout << test(0, 0, 0, 0, 1, 0, 10000) << '\n';  // test02
    cout << test(0, 0, 0, 0, 1, 1, 10000) << '\n';  // test03
    cout << test(0, 0, 0, 0, 1, 2, 10000) << '\n';  // test04
}